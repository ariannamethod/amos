/* AMOS — Arianna Method Ontological Subjectivity. No runtime dependencies.
 * Same recurrent field and acquired readout as amos.c and ports/amos.py.
 * Usable as a browser global or a Node module. Never reads DOM or host time.
 */
'use strict';
function createAMOS(H=24) {
if(![24,28,40].includes(H))throw Error('Supported neural widths are 24, 28 and 40');
const F=2*H+6, G=8, L=4, K=32, E=64, MASK=(1n<<64n)-1n;
const zeros=n=>Array(n).fill(0), matrix=(n,m)=>Array.from({length:n},()=>zeros(m));
const clip=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
const sum=a=>a.reduce((s,x)=>s+x,0);
const argmax=a=>a.reduce((b,x,i)=>x>a[b]?i:b,0);
function mix64(x) {
  x=(BigInt(x)+0x9e3779b97f4a7c15n)&MASK;
  x=((x^(x>>30n))*0xbf58476d1ce4e5b9n)&MASK;
  x=((x^(x>>27n))*0x94d049bb133111ebn)&MASK;
  return x^(x>>31n);
}
class Random {
  constructor(state) { this.state=BigInt(state); }
  next() {
    let x=this.state; x^=x>>12n; x^=(x<<25n)&MASK; x^=x>>27n;
    this.state=x; return (x*0x2545f4914f6cdd1dn)&MASK;
  }
  uniform() { return Number(this.next()>>11n)*2**-53; }
  signed() { return 2*this.uniform()-1; }
  toJSON() { return {random64:this.state.toString(16).padStart(16,'0')}; }
}
class Glyphs {
  constructor(enabled=0) {
    Object.assign(this,{enabled,learning:1,anchored:0,anchor:zeros(2),prototypes:[],
      sequence:zeros(K),familiarity:zeros(L),duration:zeros(L),evidence:[],clock:0});
  }
  observe(signature) {
    const distance=this.prototypes.map(p=>sum(p.map((v,j)=>(signature[j]-v)**2/H)));
    let best=Math.min(...distance);
    if(this.learning && this.prototypes.length<G && best>.025) {
      this.prototypes.push(signature.slice());distance.push(0);best=0;
    }
    let mixture=distance.map(d=>Math.exp(-(d-best)/.008)), total=sum(mixture);
    if(total) mixture=mixture.map(p=>p/total);
    mixture.push(...zeros(G-mixture.length));
    const repeat=this.enabled===4 && this.duration[L-1] && best<=.025 &&
      argmax(mixture)===argmax(this.sequence.slice(-G));
    if(!repeat) {
      this.sequence=this.sequence.slice(G).concat(zeros(G));
      this.familiarity=this.familiarity.slice(1).concat(0);
      this.duration=this.duration.slice(1).concat(0);
    }
    this.duration[L-1]=Math.min(Number.MAX_SAFE_INTEGER,this.duration[L-1]+1);
    this.familiarity[L-1]=Math.exp(-best/.025);
    this.sequence.splice(K-G,G,...mixture);
  }
  similarity(a,b) {
    let d=0;
    if(this.enabled===2) {
      for(let i=0;i<G;i++) {
        let x=0;for(let t=0;t<L;t++) x+=a[t*G+i]-b[t*G+i];d+=x*x/(L*L);
      }
    } else for(let i=0;i<K;i++) {const x=a[i]-b[i];d+=x*x/L;}
    return Math.exp(-d/.08);
  }
  predict(action) {
    let familiarity=1, support=0, similarity=0, variance=0;
    for(const f of this.familiarity) familiarity*=f;
    familiarity=Math.sqrt(Math.sqrt(familiarity));
    const delta=zeros(3),weights=[];
    for(const e of this.evidence) {
      let match=familiarity*this.similarity(this.sequence,e.key);
      if(Math.abs(e.action-action)>.25) match=0;
      similarity=Math.max(similarity,match);
      const w=match*e.mass;weights.push(w);support+=w;
      for(let k=0;k<3;k++) delta[k]+=w*e.mean[k];
    }
    if(support>1e-12) {
      for(let k=0;k<3;k++) delta[k]/=support;
      this.evidence.forEach((e,i)=>{variance+=weights[i]*(e.variance[2]+(e.mean[2]-delta[2])**2)/support;});
    }
    return [delta,{similarity,support,uncertainty:Math.sqrt(variance+1/(1+support)),
      ignorance:1/Math.sqrt(1+support),noise:Math.sqrt(Math.max(0,variance))}];
  }
  learn(key,action,delta) {
    let best=0,chosen=-1;
    this.evidence.forEach((e,i)=>{
      const match=this.similarity(key,e.key);
      if(Math.abs(action-e.action)<=.25 && match>best) {best=match;chosen=i;}
    });
    if(best<.72) {
      const e={key:key.slice(),mean:zeros(3),variance:zeros(3),mass:0,action,age:0};
      if(this.evidence.length<E) {chosen=this.evidence.length;this.evidence.push(e);}
      else {chosen=this.evidence.reduce((b,x,i)=>x.age<this.evidence[b].age?i:b,0);this.evidence[chosen]=e;}
    }
    const e=this.evidence[chosen];e.mass=Math.min(32,e.mass+1);
    const alpha=1/Math.min(8,e.mass);
    for(let k=0;k<3;k++) {
      const d=delta[k]-e.mean[k];e.mean[k]+=alpha*d;e.variance[k]=(1-alpha)*(e.variance[k]+alpha*d*d);
    }
    e.age=++this.clock;
  }
}
class Embodiment {
  constructor() {this.weights=matrix(2,3);this.covariance=[matrix(3,3),matrix(3,3)];this.error=zeros(2);this.samples=0;}
  learn(o,next) {
    for(let c=0;c<2;c++) {
      const f=[1,o[2],(next[c]-o[c])**2],p=this.covariance[c],pf=zeros(3);
      if(!this.samples) for(let i=0;i<3;i++) p[i][i]=100;
      let prediction=0,denominator=1;
      for(let i=0;i<3;i++) {
        prediction+=this.weights[c][i]*f[i];
        for(let j=0;j<3;j++) pf[i]+=p[i][j]*f[j];
        denominator+=f[i]*pf[i];
      }
      const error=next[2]-prediction;this.error[c]+=error*error;
      for(let i=0;i<3;i++) this.weights[c][i]+=error*pf[i]/denominator;
      for(let i=0;i<3;i++) for(let j=i;j<3;j++) p[i][j]=p[j][i]=p[i][j]-pf[i]*pf[j]/denominator;
    }
    this.samples++;
  }
  channel() {
    const total=sum(this.error);
    if(this.samples<32 || total<1e-12 || Math.abs(this.error[0]-this.error[1])<.05*total) return -1;
    return this.error[1]<this.error[0]?1:0;
  }
}
class Subject {
  constructor(seed,mode=0,glyphs=0) {
    this.mode=mode;this.rng=new Random(mix64(BigInt(seed)^0x5355424a454354n)|1n);
    this.h=zeros(H);this.win=matrix(H,5);this.recurrent=matrix(H,H);
    for(let i=0;i<H;i++) {
      let total=0;
      for(let j=0;j<5;j++) this.win[i][j]=(j===4?.2:.8)*this.rng.signed();
      for(let j=0;j<H;j++) {this.recurrent[i][j]=this.rng.signed();total+=Math.abs(this.recurrent[i][j]);}
      for(let j=0;j<H;j++) this.recurrent[i][j]*=.75/total;
    }
    this.weights=matrix(3,F);this.covariance=matrix(F,F);
    for(let i=0;i<F;i++) this.covariance[i][i]=100;
    this.previous_action=0;this.updates=0;this.observation=zeros(3);
    this.glyph=new Glyphs(glyphs);this.body=new Embodiment();
  }
  observe(observation) {
    this.observation=observation.slice();const view=observation.slice(),g=this.glyph;
    if(g.enabled) {
      if(!g.anchored) {g.anchor=view.slice(0,2);g.anchored=1;}
      for(let j=0;j<2;j++) view[j]-=g.anchor[j];
      const norm=Math.max(.2,Math.hypot(view[0],view[1]));
      for(let j=0;j<2;j++) view[j]/=norm;
    }
    const next=zeros(H),signature=zeros(H);
    for(let i=0;i<H;i++) {
      let v=this.win[i][4];for(let j=0;j<3;j++) v+=this.win[i][j]*view[j];
      signature[i]=Math.tanh(v);
      if(this.mode===0) {
        v+=this.win[i][3]*this.previous_action;
        for(let j=0;j<H;j++) v+=this.recurrent[i][j]*this.h[j];
        next[i]=.5*this.h[i]+.5*Math.tanh(v);
      } else if(this.mode===1) next[i]=Math.tanh(v);
    }
    this.h=next;if(g.enabled) g.observe(signature);
  }
  features(action) {return [1,...this.observation,action,...this.h,...this.h.map(h=>action*h),action*action];}
  predict(action) {
    const f=this.features(action),p=this.observation.slice();
    for(let k=0;k<3;k++) for(let j=0;j<F;j++) p[k]+=this.weights[k][j]*f[j];
    if(this.glyph.enabled && this.glyph.enabled!==3) {
      const [delta,r]=this.glyph.predict(action),blend=r.similarity*r.support/(1+r.support);
      for(let k=0;k<3;k++) p[k]+=blend*(this.observation[k]+delta[k]-p[k]);
    }
    return p;
  }
  influence() {const lo=this.predict(-1),hi=this.predict(1);return [Math.abs(hi[0]-lo[0]),Math.abs(hi[1]-lo[1])];}
  action(target,exploration) {
    const influence=this.influence(),c=influence[1]>influence[0]?1:0;
    if(exploration>0 && this.rng.uniform()<exploration) return Number(this.rng.next()%3n)-1;
    let best=Infinity,chosen=0;
    for(const action of [0,-1,1]) {
      const p=this.predict(action),d=p[c]-target;
      let cost=d*d+.03*clip(p[2],0,1)+.0001*action*action;
      if(this.glyph.enabled) {
        cost=p[2]+.0001*action*action;
        if(this.glyph.enabled!==3 && this.glyph.learning && exploration>0)
          cost-=exploration*this.glyph.predict(action)[1].ignorance;
      }
      if(cost<best) {best=cost;chosen=action;}
    }
    return chosen;
  }
  regress(f,delta,precision=1) {
    if(!Number.isFinite(precision)||precision<=0)throw Error('Invalid observation precision');
    const p=this.covariance,pf=zeros(F);let denominator=.997/precision;
    for(let i=0;i<F;i++) {
      for(let j=0;j<F;j++) pf[i]+=p[i][j]*f[j];denominator+=f[i]*pf[i];
    }
    for(let k=0;k<3;k++) {
      let error=delta[k];for(let j=0;j<F;j++) error-=this.weights[k][j]*f[j];
      for(let j=0;j<F;j++) this.weights[k][j]+=error*pf[j]/denominator;
    }
    for(let i=0;i<F;i++) for(let j=i;j<F;j++) p[i][j]=p[j][i]=(p[i][j]-pf[i]*pf[j]/denominator)/.997;
    for(let i=0;i<F;i++) if(p[i][i]>1e8) {
      const scale=Math.sqrt(1e8/p[i][i]);
      for(let j=0;j<F;j++) p[i][j]*=scale;
      for(let j=0;j<F;j++) p[j][i]*=scale;
    }
    this.updates++;
  }
}
class World {
  constructor(seed,kind=0) {
    this.rng=new Random(mix64(BigInt(seed)^0x574f524c44n)|1n);
    this.controlled=Number(this.rng.next()&1n);this.polarity=(this.rng.next()&1n)?1:-1;
    this.pos=[.5*this.rng.signed(),.5*this.rng.signed()];this.velocity=zeros(2);this.load=0;
    this.target=.65;this.gain=1;this.tick=0;this.kind=kind;this.order=0;
    this.offset=zeros(2);this.jitter=0;this.cue_noise=zeros(2);
    if(kind) {this.target=0;this.jitter=.02;this.landmarks();}
  }
  landmarks() {this.order=(this.rng.next()&1n)?1:-1;this.cue_noise=[this.rng.signed(),this.rng.signed()];}
  observe() {
    const o=[...this.pos,this.load];
    if(this.kind) {
      const phase=this.tick%6;
      for(let k=0;k<2;k++) {
        let v=0;
        if(phase===1 || phase===2) {
          const first=this.order>0?0:1,cue=phase===1?first:1-first;
          v=(k===cue?.8:0)+this.jitter*this.cue_noise[k];
        }
        o[k]=this.offset[k]+this.gain*v;
      }
    }
    return o;
  }
  step(action) {
    action=clip(action,-1,1);
    if(this.kind) {
      const phase=this.tick%6;
      if(phase===3) this.load=action*this.order*this.polarity>.5?.05:.95;
      else if(phase===4) this.load*=.5;
      else if(phase===5) {this.load=0;this.landmarks();}
    } else {
      const c=this.controlled,other=1-c;
      this.velocity[c]=.65*this.velocity[c]+.35*this.polarity*(1-.5*this.load)*action;
      this.velocity[other]=.8*this.velocity[other]+.2*this.rng.signed();
      for(const k of [c,other]) this.pos[k]=clip(.94*this.pos[k]+.14*this.velocity[k],-1,1);
      this.load=.9*this.load+.1*this.velocity[c]*this.velocity[c];
    }
    this.tick++;
  }
}
class Amos {
  constructor(seed=1,kind=0,glyphs=4,mode=0) {
    this.seed=BigInt(seed);this.birth=mix64(this.seed^0x414d4f532d424952n);
    this.world=new World(this.seed,kind);this.subject=new Subject(this.seed,mode,kind?glyphs:0);this.memory=[];
  }
  step(action=null,learn=true,exploration=.25) {
    const w=this.world,s=this.subject;
    if(s.glyph.enabled) s.glyph.learning=learn?1:0;
    const o=w.observe();s.observe(o);
    action=action===null?s.action(w.target,exploration):clip(action,-1,1);
    const predicted=s.predict(action),influence=s.influence(),features=s.features(action);
    const recognition=s.glyph.predict(action)[1],sequence=s.glyph.sequence.slice();
    w.step(action);const next=w.observe();
    const t={tick:w.tick,observation:o,next,action,predicted,influence,features,sequence,recognition};
    if(learn) {
      const delta=next.map((x,k)=>x-o[k]);s.regress(features,delta);s.body.learn(o,next);
      if(s.glyph.enabled) s.glyph.learn(sequence,action,delta);
    }
    s.previous_action=action;this.memory.push(t);if(this.memory.length>128) this.memory.shift();return t;
  }
  scar(future) {
    const a=this.subject,b=future.subject,eq=(x,y)=>JSON.stringify(x)===JSON.stringify(y);
    if(this.birth!==future.birth || this.seed!==future.seed || a.mode!==b.mode ||
       !eq(a.win,b.win) || !eq(a.recurrent,b.recurrent) || this.world.tick>=future.world.tick ||
       a.glyph.enabled!==b.glyph.enabled || !eq(a.glyph.prototypes,b.glyph.prototypes.slice(0,a.glyph.prototypes.length)))
      throw Error('Incompatible temporal origin or neural/glyph basis');
    const rows=future.memory.filter(t=>this.world.tick<t.tick && t.tick<=future.world.tick);
    if(!rows.length) throw Error('No retained future experience');
    if(a.glyph.enabled) a.glyph.prototypes=b.glyph.prototypes.map(p=>p.slice());
    for(const t of rows) {
      const delta=t.next.map((x,k)=>x-t.observation[k]);a.regress(t.features,delta);
      if(a.glyph.enabled) a.glyph.learn(t.sequence,t.action,delta);
    }
  }
  dumps() {
    return JSON.stringify({format:'AMOS-JSON-1',amos:this},(k,v)=>typeof v==='bigint'?v.toString(16).padStart(16,'0'):v);
  }
  static loads(text) {
    const d=JSON.parse(text);
    if(d.format!=='AMOS-JSON-1') throw Error('Unsupported snapshot format');
    const width=d.amos?.subject?.h?.length;
    if([24,28,40].includes(width)&&width!==H)return createAMOS(width).Amos.loads(text);
    const keys=(x,names)=>{if(!x || typeof x!=='object' || Array.isArray(x) || Object.keys(x).sort().join('|')!==[...names].sort().join('|')) throw Error('Unexpected snapshot fields');};
    keys(d,['format','amos']);const data=d.amos;
    keys(data,['seed','birth','world','subject','memory']);
    if(!/^[0-9a-f]{16}$/.test(data.seed)||!/^[0-9a-f]{16}$/.test(data.birth)) throw Error('Invalid hexadecimal origin');
    const a=new Amos(BigInt('0x'+data.seed));
    keys(data.world,Object.keys(a.world));keys(data.subject,Object.keys(a.subject));
    keys(data.subject.glyph,Object.keys(a.subject.glyph));keys(data.subject.body,Object.keys(a.subject.body));
    for(const rng of [data.world.rng,data.subject.rng]) {
      keys(rng,['random64']);if(!/^[0-9a-f]{16}$/.test(rng.random64))throw Error('Invalid random state');
    }
    a.birth=BigInt('0x'+data.birth);
    if(a.birth!==mix64(a.seed^0x414d4f532d424952n)) throw Error('Invalid birth origin');
    Object.assign(a.world,data.world);a.world.rng=new Random(BigInt('0x'+data.world.rng.random64));
    Object.assign(a.subject,data.subject);a.subject.rng=new Random(BigInt('0x'+data.subject.rng.random64));
    a.subject.glyph=Object.assign(new Glyphs(),data.subject.glyph);
    a.subject.body=Object.assign(new Embodiment(),data.subject.body);a.memory=data.memory;
    validate(a);return a;
  }
  clone() {return Amos.loads(this.dumps());}
}
function validate(a) {
  const s=a.subject,w=a.world,g=s.glyph;
  const shape=(x,...dims)=>dims.length?Array.isArray(x) && x.length===dims[0] && x.every(v=>shape(v,...dims.slice(1))):typeof x==='number' && Number.isFinite(x) && Math.abs(x)<=1e30;
  if(!(a.seed>=0n && a.seed<=MASK && w.rng.state>0n && w.rng.state<=MASK && s.rng.state>0n && s.rng.state<=MASK &&
    [0,1,2].includes(s.mode) && [0,1].includes(w.kind) && [0,1].includes(w.controlled) && [-1,1].includes(w.polarity) && w.load>=0 && w.load<=1 && w.gain>0 &&
    [0,1,2,3,4].includes(g.enabled) && [0,1].includes(g.learning) && [0,1].includes(g.anchored) &&
    shape(s.h,H) && shape(s.win,H,5) && shape(s.recurrent,H,H) && shape(s.weights,3,F) && shape(s.covariance,F,F) &&
    shape(s.observation,3) && shape(g.sequence,K) && shape(g.familiarity,L) && shape(g.anchor,2) &&
    g.prototypes.length<=G && g.prototypes.every(p=>shape(p,H)) && g.evidence.length<=E &&
    g.duration.length===L && g.duration.every(x=>Number.isSafeInteger(x) && x>=0) &&
    shape(s.body.weights,2,3) && shape(s.body.covariance,2,3,3) && shape(s.body.error,2) && a.memory.length<=128)) throw Error('Invalid snapshot structure');
  const counter=x=>Number.isSafeInteger(x)&&x>=0;
  if(!(counter(w.tick)&&counter(s.updates)&&counter(g.clock)&&counter(s.body.samples)&&s.body.error.every(x=>x>=0)&&
    shape(w.pos,2)&&shape(w.velocity,2)&&shape(w.offset,2)&&shape(w.cue_noise,2)&&
    [w.load,w.target,w.polarity,w.gain,w.jitter,s.previous_action].every(x=>shape(x))&&w.jitter>=0&&Math.abs(s.previous_action)<=1&&
    (!w.kind||[-1,1].includes(w.order))&&[...g.sequence,...g.familiarity].every(x=>x>=0&&x<=1)))throw Error('Invalid snapshot values');
  let previous=0;
  for(const t of a.memory) {
    if(!(Object.keys(t).sort().join('|')==='action|features|influence|next|observation|predicted|recognition|sequence|tick' && counter(t.tick) && shape(t.predicted,3) && shape(t.influence,2) && Object.keys(t.recognition).sort().join('|')==='ignorance|noise|similarity|support|uncertainty' && Object.values(t.recognition).every(x=>shape(x)&&x>=0) && previous<t.tick && t.tick<=w.tick && Math.abs(t.action)<=1 && shape(t.observation,3) && shape(t.next,3) && shape(t.features,F) && shape(t.sequence,K))) throw Error('Invalid retained transition');
    previous=t.tick;
  }
  for(const e of g.evidence) if(!(Object.keys(e).sort().join('|')==='action|age|key|mass|mean|variance' && counter(e.age) && shape(e.mass) && shape(e.action) && e.key.every(x=>x>=0&&x<=1) && shape(e.key,K) && shape(e.mean,3) && shape(e.variance,3) && e.variance.every(x=>x>=0) && e.mass>=1 && e.mass<=32 && Math.abs(e.action)<=1 && e.age>0 && e.age<=g.clock)) throw Error('Invalid association');
}
return {Amos,World,Subject,Glyphs,Embodiment,Random,mix64,validate,H,F,G,L,K,E,withWidth:createAMOS};
}
const AMOS=createAMOS();
if(typeof module!=='undefined') module.exports=AMOS;


const LALO = (() => {
const organs = {};
// LALO source organ: ledger.js
organs["ledger.js"] = (() => {
// LALO's first organ: explicit observations, two clocks, unbroken lineage.
// No ambient clock, I/O, framework, or numerical backend.

function text(value, name, limit = 512) {
  if (typeof value !== 'string' || !value.trim() || value.length > limit)
    throw new TypeError(`${name} must be nonblank text of at most ${limit} code units`);
  return value;
}

function time(value, name) {
  if (!Number.isSafeInteger(value))
    throw new TypeError(`${name} must be an integer Unix timestamp in milliseconds`);
  return value;
}

function scalar(value) {
  if (value === null || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string' && value.length <= 4096) return value;
  throw new TypeError('value must be null, boolean, finite number, or text up to 4096 code units');
}

/**
 * An in-memory journal with an explicit record budget. A fact's world interval
 * is [validFrom, validTo); null validTo means open-ended. recordedAt is when
 * LALO learned the assertion, not when the source observed the world.
 *
 * Corrections replace an entire assertion at their recordedAt. They never edit
 * the earlier row. Independent assertions coexist, including disagreements.
 */
class FactLedger {
  #records = new Map();
  #replacedBy = new Map();
  #capacity;
  #latest = -Infinity;

  constructor({ capacity = 1024 } = {}) {
    if (!Number.isSafeInteger(capacity) || capacity < 1)
      throw new RangeError('capacity must be a positive safe integer');
    this.#capacity = capacity;
  }

  get size() { return this.#records.size; }

  /** Append one assertion. All validation finishes before journal mutation. */
  add(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input))
      throw new TypeError('fact must be an object');
    const fact = Object.freeze({
      id: text(input.id, 'id'),
      subject: text(input.subject, 'subject'),
      predicate: text(input.predicate, 'predicate'),
      value: scalar(input.value),
      source: text(input.source, 'source', 4096),
      validFrom: time(input.validFrom, 'validFrom'),
      validTo: input.validTo === null ? null : time(input.validTo, 'validTo'),
      recordedAt: time(input.recordedAt, 'recordedAt'),
      supersedes: input.supersedes == null ? null : text(input.supersedes, 'supersedes'),
    });
    if (fact.validTo !== null && fact.validTo <= fact.validFrom)
      throw new RangeError('validTo must be after validFrom');
    if (this.#records.has(fact.id)) throw new Error(`duplicate fact: ${fact.id}`);
    if (fact.recordedAt < this.#latest)
      throw new RangeError('recordedAt must follow journal order; backdate validFrom for late observations');
    if (fact.supersedes !== null) {
      const previous = this.#records.get(fact.supersedes);
      if (!previous) throw new Error(`unknown predecessor: ${fact.supersedes}`);
      if (this.#replacedBy.has(previous.id))
        throw new Error('correct the latest revision; independent claims need their own lineage');
      if (fact.subject !== previous.subject || fact.predicate !== previous.predicate)
        throw new Error('a correction must retain its subject and predicate');
      // AMOS extension: append position orders corrections within one receipt millisecond.
      if (fact.recordedAt < previous.recordedAt)
        throw new RangeError('a correction must not precede its predecessor');
    }
    if (this.size >= this.#capacity)
      throw new RangeError('journal capacity reached; history before choosing another storage budget');
    this.#records.set(fact.id, fact);
    if (fact.supersedes !== null) this.#replacedBy.set(fact.supersedes, fact.id);
    this.#latest = fact.recordedAt;
    return fact;
  }

  /** Return claims valid at world time, using only knowledge available then. */
  asOf({ validAt, knownAt, subject, predicate }) {
    time(validAt, 'validAt');
    time(knownAt, 'knownAt');
    if (subject !== undefined) text(subject, 'subject');
    if (predicate !== undefined) text(predicate, 'predicate');
    return this.entries().filter(fact => {
      const replacement = this.#records.get(this.#replacedBy.get(fact.id));
      return fact.recordedAt <= knownAt
        && !(replacement && replacement.recordedAt <= knownAt)
        && fact.validFrom <= validAt
        && (fact.validTo === null || validAt < fact.validTo)
        && (subject === undefined || fact.subject === subject)
        && (predicate === undefined || fact.predicate === predicate);
    });
  }

  /** Original assertion through the requested revision, in chronological order. */
  lineage(id) {
    let fact = this.#records.get(id);
    if (!fact) throw new Error(`unknown fact: ${id}`);
    const chain = [];
    while (fact) {
      chain.push(fact);
      fact = this.#records.get(fact.supersedes);
    }
    return chain.reverse();
  }

  /** Detached array of immutable scalar records; includes replaced assertions. */
  entries() { return [...this.#records.values()]; }
}

return {FactLedger};
})();
// LALO source organ: journal.js
organs["journal.js"] = (() => {
const { FactLedger } = organs["ledger.js"];

const FORMAT = 'lalo/journal';
function encodeJournal(ledger, { maxBytes = 2_000_000 } = {}) {
  const text = JSON.stringify({ format: FORMAT, version: 1, records: ledger.entries() });
  checkSize(text, maxBytes);
  return text;
}
function checkSize(text, maxBytes) {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1) throw new RangeError('invalid byte budget');
  if (typeof text !== 'string') throw new TypeError('journal must be JSON text');
  if (text.length > maxBytes || new TextEncoder().encode(text).length > maxBytes)
    throw new RangeError('journal exceeds byte budget');
}
function decodeJournal(text, { capacity = 1024, maxBytes = 2_000_000 } = {}) {
  checkSize(text, maxBytes);
  const data = JSON.parse(text);
  if (!data || data.format !== FORMAT || data.version !== 1 || !Array.isArray(data.records))
    throw new TypeError('unsupported journal format or version');
  const ledger = new FactLedger({ capacity });
  if (data.records.length > capacity) throw new RangeError('journal exceeds record budget');
  for (const record of data.records) ledger.add(record);
  return ledger;
}

return {encodeJournal,decodeJournal};
})();
// LALO source organ: hypothesis.js
organs["hypothesis.js"] = (() => {
// A named, inspectable rule over the two-clock journal.
const RULE = 'unanimous-boolean/v1';
const MAGNITUDE_RULE = 'magnitude-at-least/v1';

function magnitudeHypothesis(ledger, { subject, validAt, knownAt, threshold = 3 }) {
  if (typeof threshold !== 'number' || !Number.isFinite(threshold)) throw new TypeError('threshold must be finite');
  const claims = ledger.asOf({ subject, predicate: 'magnitude', validAt, knownAt });
  if (claims.some(f => f.value !== null && (typeof f.value !== 'number' || !Number.isFinite(f.value))))
    throw new TypeError('magnitude-at-least requires numeric or explicit null premises');
  const supporting = claims.filter(f => f.value !== null && f.value >= threshold);
  const opposing = claims.filter(f => f.value !== null && f.value < threshold);
  const unknown = claims.filter(f => f.value === null);
  const state = supporting.length && opposing.length ? 'contested'
    : !claims.length || unknown.length ? 'unsettled' : supporting.length ? 'supported' : 'contradicted';
  return { rule: MAGNITUDE_RULE, subject, predicate: 'magnitude', threshold, validAt, knownAt,
    state, supporting, opposing, unknown, premises: claims.map(f => f.id),
    validFrom: claims.length ? Math.max(...claims.map(f => f.validFrom)) : null,
    validTo: claims.reduce((end, f) => f.validTo === null ? end
      : end === null ? f.validTo : Math.min(end, f.validTo), null) };
}

function hypothesis(ledger, { subject, predicate, expected = true, validAt, knownAt }) {
  if (typeof expected !== 'boolean') throw new TypeError('expected must be boolean');
  const claims = ledger.asOf({ subject, predicate, validAt, knownAt });
  if (claims.some(f => typeof f.value !== 'boolean'))
    throw new TypeError('unanimous-boolean requires boolean premises');
  const supporting = claims.filter(f => f.value === expected);
  const opposing = claims.filter(f => f.value !== expected);
  const state = !claims.length ? 'unsettled' : !opposing.length ? 'supported'
    : !supporting.length ? 'contradicted' : 'contested';
  return {
    rule: RULE, subject, predicate, expected, validAt, knownAt, state,
    supporting, opposing, premises: claims.map(f => f.id),
    validFrom: claims.length ? Math.max(...claims.map(f => f.validFrom)) : null,
    validTo: claims.length ? claims.reduce((end, f) => f.validTo === null ? end
      : end === null ? f.validTo : Math.min(end, f.validTo), null) : null,
  };
}

// A projection is rebuilt from receipts; future knowledge cannot enter its layers.
function worldView(ledger, query) {
  const current = hypothesis(ledger, query);
  const history = ledger.entries().filter(f => f.recordedAt <= query.knownAt
    && f.subject === query.subject && f.predicate === query.predicate);
  const replaced = new Set(history.map(f => f.supersedes).filter(Boolean));
  const active = new Set(current.premises);
  const times = [...new Set(history.map(f => f.recordedAt))];
  return {
    current,
    records: history.map(f => ({ fact: f, state: active.has(f.id)
      ? f.value === current.expected ? 'supporting' : 'opposing'
      : replaced.has(f.id) ? 'superseded' : 'outside interval' })),
    layers: times.map(knownAt => hypothesis(ledger, { ...query, knownAt })),
    corrections: history.filter(f => f.supersedes).map(f => ({ from: f.supersedes, to: f.id })),
  };
}

return {RULE,MAGNITUDE_RULE,magnitudeHypothesis,hypothesis,worldView};
})();
// LALO source organ: tools.js
organs["tools.js"] = (() => {
const { encodeJournal, decodeJournal } = organs["journal.js"];
const { hypothesis, magnitudeHypothesis, RULE, MAGNITUDE_RULE } = organs["hypothesis.js"];

const TOOL_BUDGET = Object.freeze({ capacity: 1024, maxBytes: 2_000_000,
  maxResultBytes: 65_536, maxPage: 64, maxArgumentBytes: 32_768 });
const timestamp = description => ({ type: 'integer', minimum: Number.MIN_SAFE_INTEGER, maximum: Number.MAX_SAFE_INTEGER, description });
const name = description => ({ type: 'string', description: `${description} Nonblank; at most 512 UTF-16 code units.` });
const clocks = { knownAt: timestamp('Knowledge cutoff, integer Unix milliseconds; no receipt after this instant is visible.'),
  validAt: timestamp('World instant, integer Unix milliseconds; intervals are [validFrom, validTo).') };
const paging = { offset: { type: 'integer', minimum: 0, maximum: 1024, default: 0, description: 'Resume at nextOffset with the same arguments and session.' },
  limit: { type: 'integer', minimum: 1, maximum: 64, default: 32, description: 'Maximum rows; the byte budget may return fewer. Follow nextOffset.' } };
const filters = { subject: name('Exact subject.'), predicate: name('Exact predicate.'),
  source: { type: 'string', description: 'Exact source. Nonblank; at most 4096 UTF-16 code units.' } };
const define = (name, description, properties, required = []) => ({ name, description,
  parameters: { type: 'object', properties, required, additionalProperties: false } });
// Only flat primitive arguments: also accepted by the existing WOLFE schema subset.
const definitions = [
  define('lalo_status', 'Read fixed session metadata and budgets. Receipt bounds describe the complete loaded snapshot.', {}),
  define('lalo_subjects', 'Discover subjects known at a receipt cutoff, with receipt counts and world-time bounds. Includes historical assertions.',
    { knownAt: clocks.knownAt, prefix: name('Subject prefix.'), ...paging }, ['knownAt']),
  define('lalo_facts', 'Read active facts through both clocks, retaining source and predecessor IDs.',
    { ...clocks, ...filters, ...paging }, ['knownAt', 'validAt']),
  define('lalo_history', 'Read the append-only receipt history up to knownAt, including superseded assertions and their world intervals.',
    { knownAt: clocks.knownAt, ...filters, ...paging }, ['knownAt']),
  define('lalo_lineage', 'Follow a known receipt from its original assertion to the requested revision. Future and unknown IDs return NOT_FOUND.',
    { id: name('Receipt ID.'), knownAt: clocks.knownAt, ...paging }, ['id', 'knownAt']),
  define('lalo_reading', 'Evaluate a named rule over ALL active premises. Page through its evidence; the conclusion always uses the complete premise set. Boolean uses expected (default true); magnitude uses threshold (default 3) and predicate magnitude.',
    { ...clocks, subject: filters.subject, predicate: filters.predicate,
      rule: { type: 'string', enum: [RULE, MAGNITUDE_RULE] }, expected: { type: 'boolean' }, threshold: { type: 'number' }, ...paging },
    ['knownAt', 'validAt', 'subject', 'predicate', 'rule']),
];
const listTools = () => JSON.parse(JSON.stringify(definitions));
const bytes = value => new TextEncoder().encode(JSON.stringify(value)).byteLength;
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value)
  && [Object.prototype, null].includes(Object.getPrototypeOf(value));
class ToolError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}
function invalid(message) { throw new ToolError('INVALID_ARGUMENTS', message); }
function argumentsFor(tool, input) {
  if (!object(input)) invalid('arguments must be an object');
  const schema = tool.parameters, args = {};
  for (const key of Object.keys(input)) if (!Object.hasOwn(schema.properties, key)) invalid(`Unknown argument: ${key.slice(0, 80)}`);
  for (const key of schema.required) if (!Object.hasOwn(input, key)) invalid(`Missing argument: ${key}`);
  for (const [key, spec] of Object.entries(schema.properties)) {
    const value = Object.hasOwn(input, key) ? input[key] : spec.default;
    if (value === undefined && !Object.hasOwn(input, key)) continue;
    if (spec.type === 'integer' ? !Number.isSafeInteger(value)
      : spec.type === 'number' ? typeof value !== 'number' || !Number.isFinite(value)
      : typeof value !== spec.type) invalid(`${key} must be ${spec.type}`);
    if (typeof value === 'string' && (!value.trim() || value.length > (key === 'source' ? 4096 : 512)))
      invalid(`${key} is empty or exceeds its text budget`);
    if (spec.minimum !== undefined && value < spec.minimum || spec.maximum !== undefined && value > spec.maximum)
      invalid(`${key} is outside its declared bounds`);
    if (spec.enum && !spec.enum.includes(value)) invalid(`${key} is not a supported value`);
    args[key] = value;
  }
  if (bytes(args) > TOOL_BUDGET.maxArgumentBytes) invalid('arguments exceed their byte budget');
  return args;
}

// Each host owns a fixed snapshot, so pagination and repeated calls cannot drift.
// AMOS extension: explicit session budgets; upstream defaults remain unchanged.
function createToolHost(world, { maxResultBytes = TOOL_BUDGET.maxResultBytes,
  capacity = TOOL_BUDGET.capacity, maxBytes = TOOL_BUDGET.maxBytes } = {}) {
  if (!Number.isSafeInteger(capacity) || capacity < 1 || capacity > 16384 ||
    !Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > 32_000_000)
    throw new RangeError('invalid session journal budget');
  const sessionDefinitions = listTools();
  for (const tool of sessionDefinitions) if (tool.parameters.properties.offset)
    tool.parameters.properties.offset.maximum = capacity;
  if (!Number.isSafeInteger(maxResultBytes) || maxResultBytes < 1024 || maxResultBytes > TOOL_BUDGET.maxResultBytes)
    throw new RangeError('result byte budget must be between 1024 and 65536');
  const ledger = decodeJournal(encodeJournal(world, { maxBytes }), { capacity, maxBytes }), all = ledger.entries();
  const known = at => all.filter(f => f.recordedAt <= at);
  const match = (f, a) => ['subject', 'predicate', 'source'].every(k => a[k] === undefined || f[k] === a[k]);
  function page(rows, args, extra = {}) {
    if (args.offset > rows.length) invalid('offset exceeds this result; keep the query and session unchanged');
    const data = { ...extra, items: [], total: rows.length, offset: args.offset, nextOffset: null, complete: false };
    const result = { ok: true, data };
    for (let i = args.offset; i < Math.min(rows.length, args.offset + args.limit); i++) {
      data.items.push(rows[i]);
      // Reserve the actual continuation fields when measuring the whole envelope.
      data.nextOffset = capacity; data.complete = false;
      if (bytes(result) > maxResultBytes) { data.items.pop(); break; }
    }
    const end = args.offset + data.items.length;
    data.complete = end === rows.length; data.nextOffset = data.complete ? null : end;
    if (!data.items.length && !data.complete) throw new ToolError('RESULT_BUDGET', 'One result row exceeds the byte budget; request a larger host budget');
    return result;
  }
  function execute(tool, a) {
    if (tool === 'lalo_status') return { ok: true, data: { snapshot: 'fixed for this host session', records: all.length,
      firstReceipt: all[0]?.recordedAt ?? null, latestReceipt: all.at(-1)?.recordedAt ?? null,
      limits: { ...TOOL_BUDGET, capacity, maxBytes, maxResultBytes } } };
    if (tool === 'lalo_subjects') {
      const subjects = new Map();
      for (const f of known(a.knownAt)) {
        if (a.prefix !== undefined && !f.subject.startsWith(a.prefix)) continue;
        const s = subjects.get(f.subject) || { subject: f.subject, receipts: 0, firstReceipt: f.recordedAt,
          latestReceipt: f.recordedAt, validFromMin: f.validFrom, validFromMax: f.validFrom };
        s.receipts++; s.latestReceipt = f.recordedAt;
        s.validFromMin = Math.min(s.validFromMin, f.validFrom); s.validFromMax = Math.max(s.validFromMax, f.validFrom);
        subjects.set(f.subject, s);
      }
      const rows = [...subjects.values()].sort((x, y) => x.subject < y.subject ? -1 : x.subject > y.subject ? 1 : 0);
      return page(rows, a, { knownAt: a.knownAt });
    }
    if (tool === 'lalo_facts') return page(ledger.asOf(a).filter(f => match(f, a)), a, { validAt: a.validAt, knownAt: a.knownAt });
    if (tool === 'lalo_history') return page(known(a.knownAt).filter(f => match(f, a)), a, { knownAt: a.knownAt });
    if (tool === 'lalo_lineage') {
      if (!known(a.knownAt).some(f => f.id === a.id)) throw new ToolError('NOT_FOUND', 'Receipt is not known at this cutoff');
      return page(ledger.lineage(a.id), a, { id: a.id, knownAt: a.knownAt });
    }
    if (a.rule === RULE && a.threshold !== undefined) invalid('threshold belongs to magnitude-at-least/v1');
    if (a.rule === MAGNITUDE_RULE && (a.expected !== undefined || a.predicate !== 'magnitude'))
      invalid('magnitude-at-least/v1 requires predicate magnitude and uses threshold, not expected');
    let reading;
    try { reading = a.rule === RULE ? hypothesis(ledger, a) : magnitudeHypothesis(ledger, a); }
    catch (error) { throw new ToolError('INVALID_PREMISES', error.message); }
    const { supporting, opposing, unknown = [], premises, ...summary } = reading;
    const roles = new Map([...supporting.map(f => [f.id, 'supporting']), ...opposing.map(f => [f.id, 'opposing']), ...unknown.map(f => [f.id, 'unknown'])]);
    const byID = new Map(all.map(f => [f.id, f]));
    return page(premises.map(id => ({ role: roles.get(id), fact: byID.get(id) })), a,
      { reading: { ...summary, premiseCount: premises.length, counts: { supporting: supporting.length, opposing: opposing.length, unknown: unknown.length } } });
  }
  return Object.freeze({ list: () => JSON.parse(JSON.stringify(sessionDefinitions)), call(name, input = {}) {
    try {
      const tool = sessionDefinitions.find(t => t.name === name);
      if (!tool) throw new ToolError('UNKNOWN_TOOL', 'Tool is not registered');
      const args = argumentsFor(tool, input), result = execute(name, args);
      if (bytes(result) > maxResultBytes) throw new ToolError('RESULT_BUDGET', 'Result exceeds the host byte budget');
      return JSON.parse(JSON.stringify(result));
    } catch (error) {
      return { ok: false, error: { code: error?.code || 'TOOL_FAILURE', message: String(error?.message || 'Tool call failed').slice(0, 400) } };
    }
  } });
}

return {TOOL_BUDGET,listTools,createToolHost};
})();
// LALO source organ: sources/usgs.js
organs["sources/usgs.js"] = (() => {
const { encodeJournal, decodeJournal } = organs["journal.js"];

const USGS_FEED = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson';
const fields = ['magnitude', 'magnitude_type', 'longitude', 'latitude', 'depth_km', 'place', 'event_type', 'source_updated_at'];
function integer(value, name) {
  if (!Number.isSafeInteger(value)) throw new TypeError(`${name} must be an integer timestamp`);
  return value;
}
function number(value, name) {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new TypeError(`${name} must be finite`);
  return value;
}
function text(value, name) {
  if (value !== null && (typeof value !== 'string' || value.length > 4096))
    throw new TypeError(`${name} must be text or explicit null`);
  return value;
}
function event(feature) {
  if (feature?.type !== 'Feature' || typeof feature.id !== 'string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(feature.id))
    throw new TypeError('invalid USGS feature ID');
  const p = feature.properties, g = feature.geometry;
  if (!p || g?.type !== 'Point' || !Array.isArray(g.coordinates) || g.coordinates.length !== 3)
    throw new TypeError('invalid USGS properties or point');
  const time = integer(p.time, 'event time'), updated = integer(p.updated, 'source update');
  if (!Number.isSafeInteger(time + 1)) throw new RangeError('event time is out of range');
  const [lon, lat, depth] = g.coordinates.map((v, i) => number(v, ['longitude', 'latitude', 'depth'][i]));
  if (Math.abs(lon) > 180 || Math.abs(lat) > 90) throw new RangeError('invalid coordinates');
  return { id: feature.id, time, updated, values: [
    p.mag === null ? null : number(p.mag, 'magnitude'), text(p.magType, 'magnitude type'),
    lon, lat, depth, text(p.place, 'place'), text(p.type, 'event type'), updated,
  ] };
}

// The standalone source field accepts complete adapter journals, including every old version.
function validateUSGSJournal(ledger) {
  const rows = ledger.entries(), heads = new Map();
  if (rows.length % fields.length) throw new Error('incomplete USGS journal version');
  for (let offset = 0; offset < rows.length; offset += fields.length) {
    const group = rows.slice(offset, offset + fields.length), first = group[0];
    const values = group.map(f => f.value), id = first.subject.slice(5), updated = values[7];
    const e = event({ type: 'Feature', id, geometry: { type: 'Point', coordinates: values.slice(2, 5) },
      properties: { mag: values[0], magType: values[1], place: values[5], type: values[6], time: first.validFrom, updated } });
    const subject = `usgs:${e.id}`, source = `https://earthquake.usgs.gov/earthquakes/eventpage/${e.id}`;
    const previous = heads.get(subject);
    if (previous !== undefined && updated <= previous) throw new Error('USGS source versions must advance');
    for (let i = 0; i < fields.length; i++) {
      const f = group[i], predicate = fields[i];
      if (f.subject !== subject || f.source !== source || f.predicate !== predicate
        || f.id !== `${subject}:${updated}:${predicate}` || f.recordedAt !== first.recordedAt
        || f.validFrom !== e.time || f.validTo !== e.time + 1
        || f.supersedes !== (previous === undefined ? null : `${subject}:${previous}:${predicate}`))
        throw new Error('USGS journal contains an inconsistent event version');
    }
    heads.set(subject, updated);
  }
  return ledger;
}

// A whole poll is staged on a new ledger. On failure the caller retains its prior journal.
function ingestUSGS(ledger, feed, { receivedAt, capacity = 1024, maxBytes = 2_000_000, maxEvents = 500 } = {}) {
  integer(receivedAt, 'receipt time');
  if (!Number.isSafeInteger(maxEvents) || maxEvents < 1) throw new RangeError('invalid event budget');
  if (feed?.type !== 'FeatureCollection' || !Array.isArray(feed.features))
    throw new TypeError('USGS feed must be a FeatureCollection');
  if (feed.features.length > maxEvents) throw new RangeError('USGS feed exceeds event budget');
  const events = feed.features.map(event);
  if (new Set(events.map(e => e.id)).size !== events.length) throw new Error('duplicate event in USGS feed');
  const candidate = decodeJournal(encodeJournal(ledger, { maxBytes }), { capacity, maxBytes });
  const existing = new Map(candidate.entries().map(f => [f.id, f]));
  const latest = new Map();
  for (const fact of candidate.entries()) {
    if (fact.subject.startsWith('usgs:') && fact.predicate === 'source_updated_at') latest.set(fact.subject, fact);
  }
  const summary = { events: events.length, added: 0, revised: 0, unchanged: 0, stale: 0 };
  for (const e of events) {
    const subject = `usgs:${e.id}`, source = `https://earthquake.usgs.gov/earthquakes/eventpage/${e.id}`;
    const previous = latest.get(subject);
    if (previous) {
      if (!Number.isSafeInteger(previous.value) || previous.source !== source)
        throw new Error('invalid prior USGS source revision');
      for (const field of fields) {
        const old = existing.get(`${subject}:${previous.value}:${field}`);
        if (!old || old.subject !== subject || old.predicate !== field || old.source !== source)
          throw new Error('incomplete prior USGS event revision');
      }
      if (e.updated < previous.value) { summary.stale++; continue; }
    }
    if (previous?.value === e.updated) {
      for (let i = 0; i < fields.length; i++) {
        const old = existing.get(`${subject}:${e.updated}:${fields[i]}`);
        if (old.value !== e.values[i] || old.validFrom !== e.time || old.validTo !== e.time + 1)
          throw new Error('USGS changed an event without changing its source version');
      }
      summary.unchanged++; continue;
    }
    for (let i = 0; i < fields.length; i++) {
      const predicate = fields[i];
      candidate.add({ id: `${subject}:${e.updated}:${predicate}`, subject, predicate,
        value: e.values[i], source, validFrom: e.time, validTo: e.time + 1, recordedAt: receivedAt,
        supersedes: previous ? `${subject}:${previous.value}:${predicate}` : null });
    }
    summary[previous ? 'revised' : 'added']++;
  }
  return { ledger: candidate, summary };
}

return {USGS_FEED,validateUSGSJournal,ingestUSGS};
})();
// LALO source organ: sources/geolocation.js
organs["sources/geolocation.js"] = (() => {
const { encodeJournal, decodeJournal } = organs["journal.js"];

const LOCATION_BUDGET = Object.freeze({ capacity: 768, maxBytes: 512_000 });
const LOCATION_SUBJECT = 'device:this-browser';
const LOCATION_SOURCE = 'browser:geolocation';
const fields = ['latitude', 'longitude', 'accuracy'];

function measurement(position) {
  const { latitude, longitude, accuracy } = position?.coords || {};
  if (!Number.isFinite(latitude) || Math.abs(latitude) > 90
    || !Number.isFinite(longitude) || Math.abs(longitude) > 180
    || !Number.isFinite(accuracy) || accuracy < 0)
    throw new TypeError('Location requires valid latitude, longitude and accuracy in metres');
  if (!Number.isSafeInteger(position.timestamp) || position.timestamp < 0
    || position.timestamp >= Number.MAX_SAFE_INTEGER)
    throw new TypeError('Location timestamp must be integer Unix milliseconds');
  return { latitude, longitude, accuracy };
}

// One fix is three scalar receipts at one observed instant, never an assertion
// that the device remains there. A later fix appends; it does not correct a trip.
function appendLocation(ledger, position, { id, receivedAt, ...budget } = {}) {
  const values = measurement(position);
  if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,96}$/.test(id))
    throw new TypeError('Location id must be 1–96 letters, digits, underscores or hyphens');
  const limits = { ...LOCATION_BUDGET, ...budget };
  const next = decodeJournal(encodeJournal(ledger, limits), limits);
  locationSamples(next);
  for (const predicate of fields) next.add({
    id: `location:${id}:${predicate}`, subject: LOCATION_SUBJECT, predicate,
    value: values[predicate], source: LOCATION_SOURCE,
    validFrom: position.timestamp, validTo: position.timestamp + 1, recordedAt: receivedAt,
  });
  encodeJournal(next, limits);
  return next;
}

function locationSamples(ledger) {
  const records = ledger.entries(), samples = [];
  if (records.length % 3) throw new Error('Incomplete location receipt group');
  for (let i = 0; i < records.length; i += 3) {
    const group = records.slice(i, i + 3), first = group[0];
    const prefix = first.id.match(/^location:([A-Za-z0-9_-]{1,96}):latitude$/)?.[1];
    if (!prefix || group.some((f, j) => f.id !== `location:${prefix}:${fields[j]}`
      || f.predicate !== fields[j] || f.subject !== LOCATION_SUBJECT || f.source !== LOCATION_SOURCE
      || f.validFrom !== first.validFrom || f.validTo !== first.validFrom + 1
      || f.recordedAt !== first.recordedAt || f.supersedes !== null))
      throw new Error('Invalid location receipt group');
    const coords = Object.fromEntries(group.map(f => [f.predicate, f.value]));
    measurement({ coords, timestamp: first.validFrom });
    samples.push({ ...coords, observedAt: first.validFrom, receivedAt: first.recordedAt,
      id: first.id, records: group });
  }
  return samples;
}

return {LOCATION_BUDGET,LOCATION_SUBJECT,LOCATION_SOURCE,appendLocation,locationSamples};
})();
return Object.assign({}, ...Object.values(organs));
})();

/* Semantic alphabet and word map from actually.life/l.c
 * Oleg Ataeff & Claude (Arianna Method). GPL-3.0.
 * Source: ariannamethod/actually.life @ 2bf11b3f2fab36e1a8cd8a917438ca2423f65ee8.
 * Extracted without changing the 88 names or English mappings. */
const LIFE_SEMANTIC = {
  "names": [
    "water",
    "fire",
    "earth",
    "stone",
    "tree",
    "sky",
    "light",
    "dark",
    "cold",
    "person",
    "man",
    "woman",
    "child",
    "old",
    "spirit",
    "AI",
    "animal",
    "body",
    "food",
    "sleep",
    "pain",
    "strength",
    "joy",
    "grief",
    "love",
    "fear",
    "anger",
    "longing",
    "tired",
    "stress",
    "go",
    "make",
    "break",
    "see",
    "speak",
    "hear",
    "seek",
    "give",
    "want",
    "miss",
    "agree",
    "home",
    "outside",
    "work",
    "internet",
    "bond",
    "conflict",
    "know",
    "idea",
    "think",
    "dream",
    "remember",
    "lie",
    "path",
    "up",
    "down",
    "far",
    "back",
    "before",
    "now",
    "after",
    "never",
    "always",
    "not",
    "many",
    "much",
    "and",
    "one",
    "question",
    "how",
    "cause",
    "me",
    "you",
    "other",
    "money",
    "change",
    "write",
    "choose",
    "help",
    "have",
    "free",
    "death",
    "music",
    "good",
    "small",
    "same",
    "BE",
    "wait"
  ],
  "pairs": [
    [
      "sun",
      "light"
    ],
    [
      "sunrise",
      "light"
    ],
    [
      "dawn",
      "light"
    ],
    [
      "morning",
      "light"
    ],
    [
      "bright",
      "light"
    ],
    [
      "shine",
      "light"
    ],
    [
      "night",
      "dark"
    ],
    [
      "shadow",
      "dark"
    ],
    [
      "darkness",
      "dark"
    ],
    [
      "evening",
      "dark"
    ],
    [
      "midnight",
      "dark"
    ],
    [
      "rain",
      "water"
    ],
    [
      "river",
      "water"
    ],
    [
      "sea",
      "water"
    ],
    [
      "ocean",
      "water"
    ],
    [
      "lake",
      "water"
    ],
    [
      "swim",
      "water"
    ],
    [
      "fire",
      "fire"
    ],
    [
      "flame",
      "fire"
    ],
    [
      "burn",
      "fire"
    ],
    [
      "cook",
      "fire"
    ],
    [
      "hot",
      "fire"
    ],
    [
      "warm",
      "fire"
    ],
    [
      "ground",
      "earth"
    ],
    [
      "soil",
      "earth"
    ],
    [
      "land",
      "earth"
    ],
    [
      "field",
      "earth"
    ],
    [
      "garden",
      "earth"
    ],
    [
      "farm",
      "earth"
    ],
    [
      "rock",
      "stone"
    ],
    [
      "mountain",
      "stone"
    ],
    [
      "hill",
      "stone"
    ],
    [
      "castle",
      "stone"
    ],
    [
      "wall",
      "stone"
    ],
    [
      "building",
      "stone"
    ],
    [
      "tree",
      "tree"
    ],
    [
      "forest",
      "tree"
    ],
    [
      "wood",
      "tree"
    ],
    [
      "leaf",
      "tree"
    ],
    [
      "flower",
      "tree"
    ],
    [
      "grass",
      "tree"
    ],
    [
      "sky",
      "sky"
    ],
    [
      "cloud",
      "sky"
    ],
    [
      "wind",
      "sky"
    ],
    [
      "storm",
      "sky"
    ],
    [
      "air",
      "sky"
    ],
    [
      "cold",
      "cold"
    ],
    [
      "ice",
      "cold"
    ],
    [
      "snow",
      "cold"
    ],
    [
      "frost",
      "cold"
    ],
    [
      "winter",
      "cold"
    ],
    [
      "freeze",
      "cold"
    ],
    [
      "people",
      "person"
    ],
    [
      "human",
      "person"
    ],
    [
      "someone",
      "person"
    ],
    [
      "everyone",
      "person"
    ],
    [
      "they",
      "person"
    ],
    [
      "he",
      "man"
    ],
    [
      "him",
      "man"
    ],
    [
      "boy",
      "man"
    ],
    [
      "guy",
      "man"
    ],
    [
      "father",
      "man"
    ],
    [
      "dad",
      "man"
    ],
    [
      "husband",
      "man"
    ],
    [
      "brother",
      "man"
    ],
    [
      "son",
      "man"
    ],
    [
      "king",
      "man"
    ],
    [
      "she",
      "woman"
    ],
    [
      "her",
      "woman"
    ],
    [
      "girl",
      "woman"
    ],
    [
      "mother",
      "woman"
    ],
    [
      "mom",
      "woman"
    ],
    [
      "wife",
      "woman"
    ],
    [
      "sister",
      "woman"
    ],
    [
      "daughter",
      "woman"
    ],
    [
      "queen",
      "woman"
    ],
    [
      "child",
      "child"
    ],
    [
      "kid",
      "child"
    ],
    [
      "baby",
      "child"
    ],
    [
      "children",
      "child"
    ],
    [
      "kids",
      "child"
    ],
    [
      "young",
      "child"
    ],
    [
      "little",
      "child"
    ],
    [
      "old",
      "old"
    ],
    [
      "elderly",
      "old"
    ],
    [
      "ancient",
      "old"
    ],
    [
      "grandfather",
      "old"
    ],
    [
      "grandmother",
      "old"
    ],
    [
      "grandpa",
      "old"
    ],
    [
      "grandma",
      "old"
    ],
    [
      "god",
      "spirit"
    ],
    [
      "prayer",
      "spirit"
    ],
    [
      "church",
      "spirit"
    ],
    [
      "soul",
      "spirit"
    ],
    [
      "angel",
      "spirit"
    ],
    [
      "holy",
      "spirit"
    ],
    [
      "computer",
      "AI"
    ],
    [
      "robot",
      "AI"
    ],
    [
      "machine",
      "AI"
    ],
    [
      "software",
      "AI"
    ],
    [
      "technology",
      "AI"
    ],
    [
      "digital",
      "AI"
    ],
    [
      "dog",
      "animal"
    ],
    [
      "cat",
      "animal"
    ],
    [
      "bird",
      "animal"
    ],
    [
      "horse",
      "animal"
    ],
    [
      "fish",
      "animal"
    ],
    [
      "chicken",
      "animal"
    ],
    [
      "rooster",
      "animal"
    ],
    [
      "hand",
      "body"
    ],
    [
      "head",
      "body"
    ],
    [
      "face",
      "body"
    ],
    [
      "heart",
      "body"
    ],
    [
      "eye",
      "body"
    ],
    [
      "arm",
      "body"
    ],
    [
      "eat",
      "food"
    ],
    [
      "meal",
      "food"
    ],
    [
      "bread",
      "food"
    ],
    [
      "coffee",
      "food"
    ],
    [
      "tea",
      "food"
    ],
    [
      "cake",
      "food"
    ],
    [
      "soup",
      "food"
    ],
    [
      "beer",
      "food"
    ],
    [
      "wine",
      "food"
    ],
    [
      "hungry",
      "food"
    ],
    [
      "dinner",
      "food"
    ],
    [
      "breakfast",
      "food"
    ],
    [
      "lunch",
      "food"
    ],
    [
      "sleep",
      "sleep"
    ],
    [
      "bed",
      "sleep"
    ],
    [
      "rest",
      "sleep"
    ],
    [
      "nap",
      "sleep"
    ],
    [
      "pillow",
      "sleep"
    ],
    [
      "awake",
      "sleep"
    ],
    [
      "wake",
      "sleep"
    ],
    [
      "hurt",
      "pain"
    ],
    [
      "sick",
      "pain"
    ],
    [
      "doctor",
      "pain"
    ],
    [
      "hospital",
      "pain"
    ],
    [
      "medicine",
      "pain"
    ],
    [
      "wound",
      "pain"
    ],
    [
      "fever",
      "pain"
    ],
    [
      "strong",
      "strength"
    ],
    [
      "power",
      "strength"
    ],
    [
      "run",
      "strength"
    ],
    [
      "exercise",
      "strength"
    ],
    [
      "fight",
      "strength"
    ],
    [
      "sport",
      "strength"
    ],
    [
      "happy",
      "joy"
    ],
    [
      "smile",
      "joy"
    ],
    [
      "laugh",
      "joy"
    ],
    [
      "celebrate",
      "joy"
    ],
    [
      "dance",
      "joy"
    ],
    [
      "fun",
      "joy"
    ],
    [
      "enjoy",
      "joy"
    ],
    [
      "sad",
      "grief"
    ],
    [
      "cry",
      "grief"
    ],
    [
      "mourn",
      "grief"
    ],
    [
      "sorrow",
      "grief"
    ],
    [
      "funeral",
      "grief"
    ],
    [
      "tears",
      "grief"
    ],
    [
      "love",
      "love"
    ],
    [
      "kiss",
      "love"
    ],
    [
      "hug",
      "love"
    ],
    [
      "romance",
      "love"
    ],
    [
      "wedding",
      "love"
    ],
    [
      "marry",
      "love"
    ],
    [
      "afraid",
      "fear"
    ],
    [
      "scared",
      "fear"
    ],
    [
      "panic",
      "fear"
    ],
    [
      "worry",
      "fear"
    ],
    [
      "nightmare",
      "fear"
    ],
    [
      "danger",
      "fear"
    ],
    [
      "angry",
      "anger"
    ],
    [
      "mad",
      "anger"
    ],
    [
      "rage",
      "anger"
    ],
    [
      "hate",
      "anger"
    ],
    [
      "yell",
      "anger"
    ],
    [
      "shout",
      "anger"
    ],
    [
      "miss",
      "longing"
    ],
    [
      "yearn",
      "longing"
    ],
    [
      "homesick",
      "longing"
    ],
    [
      "nostalgia",
      "longing"
    ],
    [
      "tired",
      "tired"
    ],
    [
      "exhausted",
      "tired"
    ],
    [
      "weary",
      "tired"
    ],
    [
      "sleepy",
      "tired"
    ],
    [
      "bored",
      "tired"
    ],
    [
      "stress",
      "stress"
    ],
    [
      "pressure",
      "stress"
    ],
    [
      "overwhelm",
      "stress"
    ],
    [
      "busy",
      "stress"
    ],
    [
      "rush",
      "stress"
    ],
    [
      "go",
      "go"
    ],
    [
      "walk",
      "go"
    ],
    [
      "move",
      "go"
    ],
    [
      "travel",
      "go"
    ],
    [
      "drive",
      "go"
    ],
    [
      "leave",
      "go"
    ],
    [
      "arrive",
      "go"
    ],
    [
      "come",
      "go"
    ],
    [
      "ran",
      "go"
    ],
    [
      "went",
      "go"
    ],
    [
      "walked",
      "go"
    ],
    [
      "make",
      "make"
    ],
    [
      "build",
      "make"
    ],
    [
      "create",
      "make"
    ],
    [
      "produce",
      "make"
    ],
    [
      "craft",
      "make"
    ],
    [
      "break",
      "break"
    ],
    [
      "destroy",
      "break"
    ],
    [
      "smash",
      "break"
    ],
    [
      "crash",
      "break"
    ],
    [
      "tear",
      "break"
    ],
    [
      "see",
      "see"
    ],
    [
      "look",
      "see"
    ],
    [
      "watch",
      "see"
    ],
    [
      "read",
      "see"
    ],
    [
      "notice",
      "see"
    ],
    [
      "found",
      "see"
    ],
    [
      "saw",
      "see"
    ],
    [
      "speak",
      "speak"
    ],
    [
      "say",
      "speak"
    ],
    [
      "tell",
      "speak"
    ],
    [
      "talk",
      "speak"
    ],
    [
      "call",
      "speak"
    ],
    [
      "sing",
      "speak"
    ],
    [
      "said",
      "speak"
    ],
    [
      "told",
      "speak"
    ],
    [
      "hear",
      "hear"
    ],
    [
      "listen",
      "hear"
    ],
    [
      "sound",
      "hear"
    ],
    [
      "music",
      "hear"
    ],
    [
      "song",
      "hear"
    ],
    [
      "seek",
      "seek"
    ],
    [
      "search",
      "seek"
    ],
    [
      "hunt",
      "seek"
    ],
    [
      "explore",
      "seek"
    ],
    [
      "give",
      "give"
    ],
    [
      "share",
      "give"
    ],
    [
      "offer",
      "give"
    ],
    [
      "send",
      "give"
    ],
    [
      "gave",
      "give"
    ],
    [
      "want",
      "want"
    ],
    [
      "wish",
      "want"
    ],
    [
      "desire",
      "want"
    ],
    [
      "need",
      "want"
    ],
    [
      "hope",
      "want"
    ],
    [
      "miss",
      "miss"
    ],
    [
      "lost",
      "miss"
    ],
    [
      "gone",
      "miss"
    ],
    [
      "absent",
      "miss"
    ],
    [
      "lonely",
      "miss"
    ],
    [
      "agree",
      "agree"
    ],
    [
      "yes",
      "agree"
    ],
    [
      "accept",
      "agree"
    ],
    [
      "nod",
      "agree"
    ],
    [
      "peace",
      "agree"
    ],
    [
      "home",
      "home"
    ],
    [
      "house",
      "home"
    ],
    [
      "room",
      "home"
    ],
    [
      "door",
      "home"
    ],
    [
      "kitchen",
      "home"
    ],
    [
      "window",
      "home"
    ],
    [
      "roof",
      "home"
    ],
    [
      "outside",
      "outside"
    ],
    [
      "nature",
      "outside"
    ],
    [
      "park",
      "outside"
    ],
    [
      "beach",
      "outside"
    ],
    [
      "city",
      "outside"
    ],
    [
      "market",
      "outside"
    ],
    [
      "shop",
      "outside"
    ],
    [
      "street",
      "outside"
    ],
    [
      "work",
      "work"
    ],
    [
      "job",
      "work"
    ],
    [
      "office",
      "work"
    ],
    [
      "business",
      "work"
    ],
    [
      "career",
      "work"
    ],
    [
      "internet",
      "internet"
    ],
    [
      "online",
      "internet"
    ],
    [
      "email",
      "internet"
    ],
    [
      "phone",
      "internet"
    ],
    [
      "website",
      "internet"
    ],
    [
      "friend",
      "bond"
    ],
    [
      "family",
      "bond"
    ],
    [
      "together",
      "bond"
    ],
    [
      "team",
      "bond"
    ],
    [
      "community",
      "bond"
    ],
    [
      "war",
      "conflict"
    ],
    [
      "battle",
      "conflict"
    ],
    [
      "attack",
      "conflict"
    ],
    [
      "argue",
      "conflict"
    ],
    [
      "enemy",
      "conflict"
    ],
    [
      "know",
      "know"
    ],
    [
      "learn",
      "know"
    ],
    [
      "study",
      "know"
    ],
    [
      "school",
      "know"
    ],
    [
      "book",
      "know"
    ],
    [
      "understand",
      "know"
    ],
    [
      "knew",
      "know"
    ],
    [
      "taught",
      "know"
    ],
    [
      "idea",
      "idea"
    ],
    [
      "plan",
      "idea"
    ],
    [
      "concept",
      "idea"
    ],
    [
      "solution",
      "idea"
    ],
    [
      "invention",
      "idea"
    ],
    [
      "think",
      "think"
    ],
    [
      "thought",
      "think"
    ],
    [
      "consider",
      "think"
    ],
    [
      "wonder",
      "think"
    ],
    [
      "mind",
      "think"
    ],
    [
      "decide",
      "think"
    ],
    [
      "dream",
      "dream"
    ],
    [
      "imagine",
      "dream"
    ],
    [
      "fantasy",
      "dream"
    ],
    [
      "story",
      "dream"
    ],
    [
      "wish",
      "dream"
    ],
    [
      "remember",
      "remember"
    ],
    [
      "memory",
      "remember"
    ],
    [
      "past",
      "remember"
    ],
    [
      "history",
      "remember"
    ],
    [
      "forgot",
      "remember"
    ],
    [
      "lie",
      "lie"
    ],
    [
      "cheat",
      "lie"
    ],
    [
      "fake",
      "lie"
    ],
    [
      "trick",
      "lie"
    ],
    [
      "pretend",
      "lie"
    ],
    [
      "road",
      "path"
    ],
    [
      "street",
      "path"
    ],
    [
      "way",
      "path"
    ],
    [
      "direction",
      "path"
    ],
    [
      "trail",
      "path"
    ],
    [
      "up",
      "up"
    ],
    [
      "rise",
      "up"
    ],
    [
      "climb",
      "up"
    ],
    [
      "above",
      "up"
    ],
    [
      "high",
      "up"
    ],
    [
      "tall",
      "up"
    ],
    [
      "top",
      "up"
    ],
    [
      "down",
      "down"
    ],
    [
      "fall",
      "down"
    ],
    [
      "drop",
      "down"
    ],
    [
      "below",
      "down"
    ],
    [
      "low",
      "down"
    ],
    [
      "fell",
      "down"
    ],
    [
      "far",
      "far"
    ],
    [
      "distant",
      "far"
    ],
    [
      "away",
      "far"
    ],
    [
      "abroad",
      "far"
    ],
    [
      "remote",
      "far"
    ],
    [
      "back",
      "back"
    ],
    [
      "return",
      "back"
    ],
    [
      "behind",
      "back"
    ],
    [
      "again",
      "back"
    ],
    [
      "before",
      "before"
    ],
    [
      "earlier",
      "before"
    ],
    [
      "yesterday",
      "before"
    ],
    [
      "once",
      "before"
    ],
    [
      "ago",
      "before"
    ],
    [
      "now",
      "now"
    ],
    [
      "today",
      "now"
    ],
    [
      "moment",
      "now"
    ],
    [
      "current",
      "now"
    ],
    [
      "after",
      "after"
    ],
    [
      "later",
      "after"
    ],
    [
      "tomorrow",
      "after"
    ],
    [
      "soon",
      "after"
    ],
    [
      "next",
      "after"
    ],
    [
      "then",
      "after"
    ],
    [
      "never",
      "never"
    ],
    [
      "no",
      "never"
    ],
    [
      "nothing",
      "never"
    ],
    [
      "nobody",
      "never"
    ],
    [
      "stop",
      "never"
    ],
    [
      "always",
      "always"
    ],
    [
      "forever",
      "always"
    ],
    [
      "every",
      "always"
    ],
    [
      "daily",
      "always"
    ],
    [
      "constant",
      "always"
    ],
    [
      "not",
      "not"
    ],
    [
      "don't",
      "not"
    ],
    [
      "can't",
      "not"
    ],
    [
      "won't",
      "not"
    ],
    [
      "bad",
      "not"
    ],
    [
      "wrong",
      "not"
    ],
    [
      "many",
      "many"
    ],
    [
      "much",
      "many"
    ],
    [
      "lots",
      "many"
    ],
    [
      "several",
      "many"
    ],
    [
      "huge",
      "many"
    ],
    [
      "thousand",
      "many"
    ],
    [
      "very",
      "much"
    ],
    [
      "really",
      "much"
    ],
    [
      "extremely",
      "much"
    ],
    [
      "quite",
      "much"
    ],
    [
      "and",
      "and"
    ],
    [
      "also",
      "and"
    ],
    [
      "with",
      "and"
    ],
    [
      "both",
      "and"
    ],
    [
      "plus",
      "and"
    ],
    [
      "one",
      "one"
    ],
    [
      "single",
      "one"
    ],
    [
      "alone",
      "one"
    ],
    [
      "only",
      "one"
    ],
    [
      "first",
      "one"
    ],
    [
      "question",
      "question"
    ],
    [
      "ask",
      "question"
    ],
    [
      "why",
      "question"
    ],
    [
      "what",
      "question"
    ],
    [
      "curious",
      "question"
    ],
    [
      "how",
      "how"
    ],
    [
      "method",
      "how"
    ],
    [
      "way",
      "how"
    ],
    [
      "step",
      "how"
    ],
    [
      "because",
      "cause"
    ],
    [
      "reason",
      "cause"
    ],
    [
      "therefore",
      "cause"
    ],
    [
      "result",
      "cause"
    ],
    [
      "i",
      "me"
    ],
    [
      "my",
      "me"
    ],
    [
      "myself",
      "me"
    ],
    [
      "you",
      "you"
    ],
    [
      "your",
      "you"
    ],
    [
      "yourself",
      "you"
    ],
    [
      "other",
      "other"
    ],
    [
      "another",
      "other"
    ],
    [
      "different",
      "other"
    ],
    [
      "new",
      "other"
    ],
    [
      "strange",
      "other"
    ],
    [
      "money",
      "money"
    ],
    [
      "dollar",
      "money"
    ],
    [
      "pay",
      "money"
    ],
    [
      "buy",
      "money"
    ],
    [
      "sell",
      "money"
    ],
    [
      "rich",
      "money"
    ],
    [
      "poor",
      "money"
    ],
    [
      "price",
      "money"
    ],
    [
      "change",
      "change"
    ],
    [
      "transform",
      "change"
    ],
    [
      "grow",
      "change"
    ],
    [
      "develop",
      "change"
    ],
    [
      "evolve",
      "change"
    ],
    [
      "write",
      "write"
    ],
    [
      "pen",
      "write"
    ],
    [
      "paper",
      "write"
    ],
    [
      "letter",
      "write"
    ],
    [
      "note",
      "write"
    ],
    [
      "wrote",
      "write"
    ],
    [
      "poem",
      "write"
    ],
    [
      "code",
      "write"
    ],
    [
      "choose",
      "choose"
    ],
    [
      "pick",
      "choose"
    ],
    [
      "decide",
      "choose"
    ],
    [
      "select",
      "choose"
    ],
    [
      "vote",
      "choose"
    ],
    [
      "help",
      "help"
    ],
    [
      "assist",
      "help"
    ],
    [
      "support",
      "help"
    ],
    [
      "save",
      "help"
    ],
    [
      "protect",
      "help"
    ],
    [
      "have",
      "have"
    ],
    [
      "own",
      "have"
    ],
    [
      "keep",
      "have"
    ],
    [
      "hold",
      "have"
    ],
    [
      "got",
      "have"
    ],
    [
      "had",
      "have"
    ],
    [
      "free",
      "free"
    ],
    [
      "freedom",
      "free"
    ],
    [
      "liberty",
      "free"
    ],
    [
      "escape",
      "free"
    ],
    [
      "open",
      "free"
    ],
    [
      "death",
      "death"
    ],
    [
      "die",
      "death"
    ],
    [
      "dead",
      "death"
    ],
    [
      "kill",
      "death"
    ],
    [
      "grave",
      "death"
    ],
    [
      "died",
      "death"
    ],
    [
      "music",
      "music"
    ],
    [
      "song",
      "music"
    ],
    [
      "melody",
      "music"
    ],
    [
      "guitar",
      "music"
    ],
    [
      "piano",
      "music"
    ],
    [
      "drum",
      "music"
    ],
    [
      "sang",
      "music"
    ],
    [
      "singing",
      "music"
    ],
    [
      "good",
      "good"
    ],
    [
      "great",
      "good"
    ],
    [
      "nice",
      "good"
    ],
    [
      "kind",
      "good"
    ],
    [
      "beautiful",
      "good"
    ],
    [
      "wonderful",
      "good"
    ],
    [
      "fine",
      "good"
    ],
    [
      "small",
      "small"
    ],
    [
      "tiny",
      "small"
    ],
    [
      "little",
      "small"
    ],
    [
      "short",
      "small"
    ],
    [
      "few",
      "small"
    ],
    [
      "same",
      "same"
    ],
    [
      "equal",
      "same"
    ],
    [
      "similar",
      "same"
    ],
    [
      "identical",
      "same"
    ],
    [
      "be",
      "BE"
    ],
    [
      "is",
      "BE"
    ],
    [
      "am",
      "BE"
    ],
    [
      "are",
      "BE"
    ],
    [
      "was",
      "BE"
    ],
    [
      "were",
      "BE"
    ],
    [
      "being",
      "BE"
    ],
    [
      "become",
      "BE"
    ],
    [
      "feel",
      "BE"
    ],
    [
      "wait",
      "wait"
    ],
    [
      "patience",
      "wait"
    ],
    [
      "pause",
      "wait"
    ],
    [
      "delay",
      "wait"
    ],
    [
      "stay",
      "wait"
    ]
  ]
};


/* Six lexical entrances to the same 88 seed representations.
 * Captions are presentation; stable glyph IDs carry acquired experience.
 * Klaus and Brodsky inform the multilingual organ; no corpus is imported. */
const LANGUAGES = (() => {
  'use strict';
  const policy='amos/semantic-six-v2',previousPolicy='amos/semantic-six-v1',codes=['en','he','ru','fr','de','es'];
  const labels={en:'English',he:'עברית',ru:'Русский',fr:'Français',de:'Deutsch',es:'Español'};
  // name | Hebrew | Russian | French | German | Spanish. First word = caption.
  const rows=`water|מים גשם ים נהר|вода воды воду дождь|eau pluie mer rivière|Wasser Regen Meer Fluss|agua lluvia mar río
fire|אש להבה|огонь пламя|feu flamme|Feuer Flamme|fuego llama
earth|אדמה ארץ רעידה|земля землю землетрясение|terre séisme tremblement|Erde Erdbeben|tierra terremoto
stone|אבן סלע|камень камни|pierre roche|Stein Fels|piedra roca
tree|עץ עצים יער|дерево лес|arbre forêt|Baum Wald|árbol bosque
sky|שמיים שמים רוח|небо ветер|ciel vent|Himmel Wind|cielo viento
light|אור שמש|свет солнце|lumière soleil|Licht Sonne|luz sol
dark|חושך לילה|тьма ночь|obscurité nuit|Dunkelheit Nacht|oscuridad noche
cold|קור קר שלג|холод холодно снег|froid neige|Kälte kalt Schnee|frío nieve
person|אדם אנשים|человек люди|personne humain|Mensch Menschen|persona gente
man|גבר אבא|мужчина отец|homme père|Mann Vater|hombre padre
woman|אישה אשה אמא|женщина мать|femme mère|Frau Mutter|mujer madre
child|ילד ילדה ילדים|ребёнок дети|enfant enfants|Kind Kinder|niño niña niños
old|זקן ישן|старый старость|vieux vieille|alt Alter|viejo vieja
spirit|נשמה נפש|дух душа|esprit âme|Geist Seele|espíritu alma
AI|בינה מחשב|ИИ машина|IA ordinateur|KI Computer|IA computadora
animal|חיה חתול כלב|животное кот собака|animal chat chien|Tier Katze Hund|animal gato perro
body|גוף לב|тело сердце|corps cœur|Körper Herz|cuerpo corazón
food|אוכל לחם|еда голод|nourriture pain faim|Nahrung Essen Hunger|comida pan hambre
sleep|שינה לישון|сон спать|sommeil dormir|Schlaf schlafen|dormir sueño
pain|כאב כואב|боль больно|douleur souffrance|Schmerz Schmerzen|dolor sufrimiento
strength|כוח חזק|сила сильный|force fort|Kraft stark|fuerza fuerte
joy|שמחה שמח|радость радостно|joie heureux|Freude froh|alegría alegre
grief|אבל עצב|горе печаль|deuil tristesse|Trauer Kummer|duelo tristeza
love|אהבה אוהב אוהבת|любовь люблю|amour aime aimer|Liebe lieben|amor amar quiero
fear|פחד מפחד|страх боюсь|peur crainte|Angst Furcht|miedo temor
anger|כעס זעם|гнев злость|colère rage|Wut Zorn|ira rabia
longing|געגוע געגועים|тоска скучаю|nostalgie manque|Sehnsucht Heimweh|añoranza nostalgia
tired|עייף עייפה|устал усталость|fatigue fatigué|müde Müdigkeit|cansancio cansado
stress|לחץ מתח|стресс напряжение|stress tension|Stress Anspannung|estrés tensión
go|ללכת הולך|идти иду|aller marche|gehen gehe|ir voy
make|לעשות יוצר|делать создаю|faire créer|machen schaffen|hacer crear
break|לשבור שבר|ломать сломано|casser briser|brechen kaputt|romper roto
see|לראות רואה|видеть вижу|voir vois|sehen sehe|ver veo
speak|לדבר מדבר|говорить говорю|parler parle|sprechen rede|hablar hablo
hear|לשמוע שומע|слышать слышу|entendre écoute|hören höre|oír escuchar
seek|לחפש מחפש|искать ищу|chercher cherche|suchen suche|buscar busco
give|לתת נותן|дать дай|donner donne|geben gib|dar dame
want|לרצות רוצה|хотеть хочу|vouloir veux|wollen will|querer deseo
miss|לחסור חסר|скучать|manquer absent|vermissen fehlt|extrañar extraño
agree|להסכים מסכים כן|согласен да|accord oui|zustimmen ja|acuerdo sí
home|בית הביתה|дом дома|maison foyer|Haus Zuhause|casa hogar
outside|בחוץ חוץ|снаружи улица|dehors extérieur|draußen außen|fuera exterior
work|עבודה לעבוד|работа работать|travail travailler|Arbeit arbeiten|trabajo trabajar
internet|אינטרנט רשת|интернет сеть|internet réseau|Internet Netzwerk|internet red
bond|קשר חיבור תהודה|связь резонанс|lien résonance|Bindung Resonanz|vínculo resonancia
conflict|סכסוך מלחמה|конфликт война|conflit guerre|Konflikt Krieg|conflicto guerra
know|לדעת יודע עובדה|знать знаю факт|savoir sais fait|wissen weiß Tatsache|saber sé hecho
idea|רעיון מחשבה|идея мысль|idée pensée|Idee Gedanke|idea pensamiento
think|לחשוב חושב תודעה|думать думаю сознание|penser pense conscience|denken denke Bewusstsein|pensar pienso conciencia
dream|חלום חולם|мечта снится|rêve rêver|Traum träumen|soñar ensueño
remember|לזכור זוכר זיכרון|помнить помню память|souvenir mémoire|erinnern Erinnerung|recordar recuerdo memoria
lie|שקר לשקר|ложь лгать|mensonge mentir|Lüge lügen|mentira mentir
path|דרך שביל|путь дорога|chemin route|Weg Pfad|camino sendero
up|למעלה מעלה|вверх|haut monter|oben aufwärts|arriba subir
down|למטה מטה|вниз|bas descendre|unten abwärts|abajo bajar
far|רחוק מרחק|далеко расстояние|loin distance|fern Entfernung|lejos distancia
back|חזרה אחורה|назад вернись|retour arrière|zurück Rückkehr|volver atrás
before|לפני קודם|раньше прежде|avant auparavant|vorher zuvor|antes anteriormente
now|עכשיו כעת|сейчас теперь|maintenant présent|jetzt nun|ahora presente
after|אחרי לאחר|потом после|après ensuite|danach nachher|después luego
never|מעולם|никогда|jamais|niemals nie|nunca jamás
always|תמיד|всегда|toujours|immer stets|siempre
not|לא אין|не нет|non pas|nicht nein|no nada
many|רבים רבות|многие много|plusieurs nombreux|viele zahlreich|muchos muchas
much|הרבה מאוד|очень|beaucoup très|viel sehr|mucho muy
and|וגם|и|et|und|y
one|אחד אחת|один одна|un une|eins eine|uno una
question|שאלה למה|вопрос почему|question pourquoi|Frage warum|pregunta porqué
how|איך כיצד|как|comment|wie|cómo
cause|סיבה בגלל|причина потому|cause parce|Ursache weil|causa porque
me|אני אותי לי|я меня мне|moi je|ich mich|yo mí
you|אתה את אותך|ты тебя тебе|toi tu vous|du dich|tú usted
other|אחר אחרת|другой другие|autre autres|andere anderer|otro otra
money|כסף|деньги|argent monnaie|Geld Münze|dinero moneda
change|שינוי משתנה|изменение меняется|changement changer|Änderung ändern|cambio cambiar
write|לכתוב כותב מילים|писать пишу слова|écrire écris mots|schreiben schreibe Wörter|escribir escribo palabras
choose|לבחור בוחר|выбирать выбираю|choisir choix|wählen Wahl|elegir elección
help|עזרה לעזור|помощь помоги|aide aider|Hilfe helfen|ayuda ayudar
have|יש|иметь имею|avoir possède|haben habe|tener tengo
free|חופשי חירות|свободен свобода|libre liberté|frei Freiheit|libre libertad
death|מוות מת|смерть умер|mort mourir|Tod sterben|muerte morir
music|מוזיקה שיר קצב|музыка песня|musique chanson|Musik Lied|música canción
good|טוב טובה|хороший хорошо|bon bien|gut gute|bueno bien
small|קטן קטנה|маленький мало|petit petite|klein kleine|pequeño pequeña
same|זהה דומה|одинаковый тот|même identique|gleich derselbe|mismo igual
BE|להיות קיים|быть существую|être existe|sein existieren|ser existir
wait|לחכות מחכה|ждать жду|attendre attends|warten warte|esperar espero`.split('\n').map(row=>row.split('|'));
  if(rows.length!==88||rows.some((r,i)=>r[0]!==LIFE_SEMANTIC.names[i]||r.length!==6))throw Error('Incomplete six-language alphabet');
  const normalize=w=>w.normalize('NFKC').toLowerCase().replaceAll('ё','е').replace(/\p{M}/gu,'');
  const words=text=>(text.match(/[\p{L}\p{N}][\p{L}\p{N}\p{M}]*/gu)||[]).slice(0,128);
  const grams=w=>{const s='^'+normalize(w)+'$';return Array.from({length:Math.max(1,s.length-2)},(_,i)=>s.slice(i,i+3));};
  const packs=Object.fromEntries(codes.map(code=>[code,{dictionary:new Map(),grams:new Map(),captions:[]} ]));
  function add(code,word,id){const pack=packs[code],w=normalize(word);pack.dictionary.set(w,id);
    for(const gram of grams(w)){if(!pack.grams.has(gram))pack.grams.set(gram,Array(88).fill(0));pack.grams.get(gram)[id]++;}}
  for(const [i,row] of rows.entries()){add('en',row[0],i);packs.en.captions[i]=row[0];for(let l=1;l<6;l++){
    const entries=row[l].split(' ');packs[codes[l]].captions[i]=entries[0];for(const word of entries)add(codes[l],word,i);}}
  for(const [word,name] of LIFE_SEMANTIC.pairs)add('en',word,LIFE_SEMANTIC.names.indexOf(name));
  const stops={en:'a an the is are was were of to for in on at with from as it its this that these those by',
    he:'של הוא היא הם הן עם על אל מן',ru:'это этот эта то те на в во с со к ко у по за из от для о об же бы ли ну блять короче',
    fr:'le la les de des du au aux dans sur avec pour il elle ils elles ce cette ces',
    de:'der die das ein einer eines einem einen dem den des im am mit von zu zum zur auf für es sie er',
    es:'el la los las de del al en con por para es son está esto esta ese esa'};
  const stopSets=Object.fromEntries(codes.map(c=>[c,new Set(stops[c].split(' ').map(normalize))]));
  function detect(text){const tokens=words(text).map(normalize),scores=Object.fromEntries(codes.map(c=>[c,0]));
    for(const w of tokens)for(const c of codes){if(packs[c].dictionary.has(w))scores[c]+=2;if(stopSets[c].has(w))scores[c]++;}
    // Script evidence belongs to this input; it never assigns a state to a language.
    scores.he+=tokens.filter(w=>/\p{Script=Hebrew}/u.test(w)).length*3;
    scores.ru+=tokens.filter(w=>/\p{Script=Cyrillic}/u.test(w)).length*3;
    const language=codes.reduce((a,c)=>scores[c]>scores[a]?c:a,'en');return {language,scores};
  }
  const canonical=new Map(LIFE_SEMANTIC.names.map((name,id)=>[normalize(name),id]));
  function tokenize(text,language='auto',version=2){
    if(language!=='auto'&&!codes.includes(language))throw Error('Unsupported address language');
    const detected=detect(text),code=language==='auto'?detected.language:language,pack=packs[code],tokens=[];
    for(const word of words(text)){const w=normalize(word);if(stopSets[code].has(w))continue;
      let id=version===2&&code==='en'&&canonical.has(w)?canonical.get(w):pack.dictionary.get(w),via='lexicon';
      // A mixed-language word can enter through its own exact dictionary.
      if(id===undefined)for(const other of codes){if(packs[other].dictionary.has(w)){id=version===2&&other==='en'&&canonical.has(w)?canonical.get(w):packs[other].dictionary.get(w);break;}}
      if(id===undefined){const votes=Array(88).fill(0);for(const gram of grams(w)){const row=pack.grams.get(gram);if(row)for(let i=0;i<88;i++)votes[i]+=row[i];}
        const best=Math.max(...votes);if(best){id=votes.indexOf(best);via='orthographic';}else{let h=2166136261;for(const c of w)h=Math.imul(h^c.codePointAt(0),16777619);id=(h>>>0)%88;via='hash';}}
      tokens.push({word,id,via});}
    return {ids:tokens.map(t=>t.id),tokens,language:code,policy:version===1?previousPolicy:policy};
  }
  function caption(id,language='en',symbols=[],depth=0){
    if(!codes.includes(language))throw Error('Unsupported glyph caption language');
    if(id<88)return packs[language].captions[id];if(depth>64||!symbols[id-88])return '?';
    return symbols[id-88].map(g=>g>=88?'('+caption(g,language,symbols,depth+1)+')':caption(g,language,symbols,depth+1)).join('+');
  }
  function extend(code,entries){for(const [name,aliases] of Object.entries(entries))for(const word of aliases.split(' '))add(code,word,LIFE_SEMANTIC.names.indexOf(name));}
  function localizeName(name,language='en'){
    if(!codes.includes(language))throw Error('Unsupported glyph caption language');
    return name.replace(/[A-Za-z]+/g,word=>{const id=LIFE_SEMANTIC.names.indexOf(word);return id<0?word:packs[language].captions[id];});
  }
  return {policy,previousPolicy,codes,labels,tokenize,tokenizePrevious:(text,language='auto')=>tokenize(text,language,1),detect,caption,localizeName,extend};
})();


/* AMOS-2 expression organ. The 88-glyph alphabet, orthographic mouth,
 * online co-occurrence field and recursive symbol birth descend from
 * actually.life/l.c (Oleg Ataeff & Claude, GPL-3.0). The neural association
 * and resonance bridge below are specific to this AMOS world. */
const VOICE = (() => {
  'use strict';
  const BASE = 88, MAX = 152, GROWTH = 14;
  const russian = {
    water:'вода воды воду дождь море океан река', fire:'огонь огня горит пламя жар',
    earth:'земля земли землю землетрясение землетрясения мир', stone:'камень камни гора скала',
    tree:'дерево деревья лес',sky:'небо ветер воздух облако облака погода',light:'свет солнце день',dark:'тьма темнота ночь',cold:'холод холодно лёд снег',
    person:'человек люди кто',man:'мужчина отец',woman:'женщина мать',child:'ребёнок ребенок дети',old:'старый старость',spirit:'дух душа',AI:'ии машина компьютер',animal:'животное кот собака',
    body:'тело рука руки сердце',food:'еда есть голод',sleep:'сон спать спи отдых',pain:'боль больно рана',strength:'сила сильный',
    joy:'радость радостно',grief:'печаль горе грустно',love:'любовь люблю любить',fear:'страх боюсь страшно',anger:'злость гнев',longing:'тоска скучаю',tired:'устал усталость',stress:'стресс напряжение',
    go:'идти иду движение движется',make:'делать делаю создаю',break:'ломать сломано',see:'вижу видеть смотри',speak:'говорю говорить скажи',hear:'слышу слышишь слушай',seek:'ищу искать',give:'дай даю',want:'хочу хочешь',miss:'скучать',agree:'согласен согласна да',
    home:'дом дома',outside:'снаружи улица',work:'работа работать',internet:'интернет сеть',bond:'связь связи резонанс резонирует',conflict:'конфликт война',
    know:'знаю знать факт факты',idea:'идея мысль',think:'думаю думать сознание',dream:'мечта снится',remember:'помню помнить помнишь память',lie:'ложь лгать',
    path:'путь дорога',up:'вверх',down:'вниз',far:'далеко расстояние',back:'назад вернись',before:'раньше прежде',now:'сейчас здесь',after:'потом после',never:'никогда',always:'всегда',
    not:'не нет',many:'много многие',much:'очень',and:'и',one:'один одна',question:'вопрос почему',how:'как',cause:'причина потому',
    me:'я меня мне мной моё мое',you:'ты тебя тебе тобой твой',other:'другой другие',money:'деньги',change:'изменение изменение меняется меняешься',write:'пишу написать написал слово слова',choose:'выбор выбираю',help:'помощь помоги',have:'имею',free:'свобода свободен',death:'смерть',music:'музыка песня ритм',good:'хорошо хороший',small:'мало маленький',same:'тот одинаковый',BE:'будь быть существую существовать',wait:'жди ждать жду'
  };
  const normalize = w => w.normalize('NFKC').toLowerCase().replaceAll('ё','е');
  const stop = new Set(('a an the is are was were of to for in on at with from as it its this that these those by '+
    'это этот эта то те на в во с со к ко у по за из от для о об же бы ли ну блять короче').split(' '));
  const dictionary = new Map(), grams = new Map();
  const gramsof = word => { const s='^'+normalize(word)+'$';return Array.from({length:Math.max(1,s.length-2)},(_,i)=>s.slice(i,i+3)); };
  const add = (word,id) => {
    dictionary.set(normalize(word),id);
    for(const gram of gramsof(word)) {
      if(!grams.has(gram)) grams.set(gram,Array(BASE).fill(0));
      grams.get(gram)[id]++;
    }
  };
  LIFE_SEMANTIC.names.forEach(add);
  for(const [word,name] of LIFE_SEMANTIC.pairs) add(word,LIFE_SEMANTIC.names.indexOf(name));
  for(const [name,words] of Object.entries(russian)) for(const word of words.split(' ')) add(word,LIFE_SEMANTIC.names.indexOf(name));
  const hash = text => {let n=2166136261;for(const c of text) n=Math.imul(n^c.codePointAt(0),16777619);return n>>>0;};
  function tokenize(text) {
    const words=(text.match(/[\p{L}\p{N}]+/gu)||[]).slice(0,128), tokens=[];
    for(const word of words) {
      const w=normalize(word);if(stop.has(w)) continue;
      let id=dictionary.get(w),via='lexicon';
      if(id===undefined) {
        const votes=Array(BASE).fill(0);
        for(const g of gramsof(w)) {const row=grams.get(g);if(row)for(let i=0;i<BASE;i++)votes[i]+=row[i];}
        const max=Math.max(...votes);id=max?votes.indexOf(max):hash(w)%BASE;via=max?'orthographic':'hash';
      }
      tokens.push({word,id,via});
    }
    return {ids:tokens.map(t=>t.id),tokens};
  }
  const blank = () => Array(MAX).fill(0);
  const norm = a => Math.sqrt(a.reduce((s,v)=>s+v*v,0));
  const cosine = (a,b) => {const d=norm(a)*norm(b);return d?a.reduce((s,v,i)=>s+v*b[i],0)/d:0;};
  class GlyphVoice {
    constructor(seed=17,width=24) {
      if(![24,28,40].includes(width))throw Error('Invalid voice neural width');
      this.symbols=[];this.uni=blank();this.bi=Array.from({length:MAX},blank);this.cooc=Array.from({length:MAX},blank);
      this.neural=Array.from({length:MAX},()=>Array(width).fill(0));
      this.prototypes=Array.from({length:8},blank);this.recent=[];this.last=[];this.utterances=0;
      this.rng=new AMOS.Random(AMOS.mix64(BigInt(seed)^0x564f494345n)|1n);
    }
    name(id,depth=0) {
      if(id<BASE)return LIFE_SEMANTIC.names[id];
      if(depth>64)return '?';
      const pair=this.symbols[id-BASE];if(!pair)return '?';
      const parts=pair.map(v=>v>=BASE?'('+this.name(v,depth+1)+')':this.name(v));return parts.join('+');
    }
    resonance(ids) {
      if(!ids.length)return 0;
      const high=Math.max(...this.uni);if(!high)return 0;
      return ids.reduce((s,id)=>s+this.uni[id]/high,0)/ids.length;
    }
    ingest(ids,h,mixture,plasticity=1) {
      let compressed=ids.slice();
      for(let n=0;n<this.symbols.length;n++){
        const [a,b]=this.symbols[n],next=[];
        for(let i=0;i<compressed.length;i++){
          if(compressed[i]===a&&compressed[i+1]===b){next.push(BASE+n);i++;}else next.push(compressed[i]);
        }
        compressed=next;
      }
      const eaten=ids.concat(compressed.filter(id=>id>=BASE));
      for(const id of eaten) {
        this.uni[id]++;
        for(let j=0;j<this.neural[id].length;j++)this.neural[id][j]=(1-.06*plasticity)*this.neural[id][j]+.06*plasticity*h[j];
        for(let k=0;k<8;k++)this.prototypes[k][id]+=(mixture[k]||0);
      }
      for(let i=1;i<ids.length;i++){this.bi[ids[i-1]][ids[i]]++;this.cooc[ids[i-1]][ids[i]]++;}
      if(compressed.some(id=>id>=BASE))for(let i=1;i<compressed.length;i++){
        if(compressed[i-1]>=BASE||compressed[i]>=BASE){
          this.bi[compressed[i-1]][compressed[i]]++;this.cooc[compressed[i-1]][compressed[i]]++;
        }
      }
      this.recent=this.recent.concat(compressed).slice(-24);
    }
    consolidate() {
      if(this.symbols.length>=64)return null;
      let best=GROWTH-1,pair=null;const high=BASE+this.symbols.length;
      for(let a=0;a<high;a++)for(let b=0;b<high;b++) {
        if(this.cooc[a][b]>best&&!this.symbols.some(p=>p[0]===a&&p[1]===b)){best=this.cooc[a][b];pair=[a,b];}
      }
      if(!pair)return null;
      const id=BASE+this.symbols.length;this.symbols.push(pair);
      this.uni[id]=(this.uni[pair[0]]+this.uni[pair[1]])/2;
      this.neural[id]=this.neural[pair[0]].map((x,i)=>(x+this.neural[pair[1]][i])/2);
      for(let k=0;k<8;k++)this.prototypes[k][id]=(this.prototypes[k][pair[0]]+this.prototypes[k][pair[1]])/2;
      for(let g=0;g<id;g++) {
        this.bi[g][id]=(this.bi[g][pair[0]]+this.bi[g][pair[1]])/2;
        this.bi[id][g]=(this.bi[pair[0]][g]+this.bi[pair[1]][g])/2;
      }
      return {id,pair,support:best,name:this.name(id)};
    }
    express(h,mixture,arousal=0,temperatureScale=1) {
      const born=this.consolidate();if(!this.recent.length)return {ids:[],words:[],born,contributions:[]};
      const ids=[],contributions=[];let previous=this.recent.at(-1);
      const temperature=(.52+.28*Math.min(1,arousal))*temperatureScale,high=BASE+this.symbols.length;
      for(let n=0;n<5;n++) {
        const scores=Array(high).fill(-1e6),pieces=[];
        for(let id=0;id<high;id++)if(this.uni[id]>0) {
          const association=5*cosine(this.neural[id],h);
          const recognition=mixture.reduce((s,p,k)=>s+p*Math.log1p(this.prototypes[k][id]),0);
          const succession=.8*Math.log(.05+this.bi[previous][id]);
          const score=.2*Math.log1p(this.uni[id])+association+recognition+succession-(ids.filter(x=>x===id).length*1.8);
          scores[id]=score;pieces[id]={association,recognition,succession};
        }
        const max=Math.max(...scores),weights=scores.map(v=>v<-1e5?0:Math.exp((v-max)/temperature));
        let remaining=this.rng.uniform()*weights.reduce((s,v)=>s+v,0),chosen=previous;
        for(let id=0;id<high;id++){remaining-=weights[id];if(remaining<=0&&weights[id]){chosen=id;break;}}
        ids.push(chosen);contributions.push({id:chosen,...pieces[chosen]});previous=chosen;
      }
      this.last=ids;this.utterances++;
      return {ids,words:ids.map(id=>this.name(id)),born,contributions};
    }
    grow(width) {
      const old=this.neural[0].length;if(width<old||![24,28,40].includes(width))throw Error('Invalid voice growth');
      this.neural=this.neural.map(row=>row.concat(Array(width-old).fill(0)));return this;
    }
    dump() {return {...this,rng:this.rng.state.toString(16)};}
    static load(data) {
      const width=data?.neural?.[0]?.length;
      const valid=(a,rows,cols)=>Array.isArray(a)&&a.length===rows&&a.every(v=>cols?valid(v,cols):typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<1e12);
      if(!data||!Array.isArray(data.symbols)||data.symbols.length>64||
        !data.symbols.every((p,i)=>Array.isArray(p)&&p.length===2&&p.every(v=>Number.isInteger(v)&&v>=0&&v<BASE+i))||
        !valid(data.uni,MAX)||!valid(data.bi,MAX,MAX)||!valid(data.cooc,MAX,MAX)||(![24,28,40].includes(width)||!valid(data.neural,MAX,width))||!valid(data.prototypes,8,MAX)||
        !Array.isArray(data.recent)||data.recent.length>24||!Array.isArray(data.last)||data.last.length>5||
        ![...data.recent,...data.last].every(v=>Number.isInteger(v)&&v>=0&&v<BASE+data.symbols.length)||
        !Number.isSafeInteger(data.utterances)||data.utterances<0||!/^[0-9a-f]{1,16}$/.test(data.rng))throw Error('Invalid expression state');
      if(data.uni.some(v=>v<0)||data.bi.some(row=>row.some(v=>v<0))||data.cooc.some(row=>row.some(v=>v<0))||data.prototypes.some(row=>row.some(v=>v<0)))throw Error('Negative expression count');
      const voice=new GlyphVoice(17,width);Object.assign(voice,data);voice.rng=new AMOS.Random(BigInt('0x'+data.rng));
      if(!voice.rng.state)throw Error('Invalid expression random stream');return voice;
    }
  }
  // Keep the original membrane for immutable historical read validation.
  LANGUAGES.extend('ru',russian);
  return {GlyphVoice,tokenize:LANGUAGES.tokenize,tokenizePrevious:LANGUAGES.tokenizePrevious,tokenizeLegacy:tokenize,BASE,MAX,names:LIFE_SEMANTIC.names,cosine};
})();


/* Acquired relations, carried by the standalone heart. Geometry and clocks
 * are derived from source receipts; familiarity and transition expectation
 * are learned from encountered relations. No timers, I/O or presentation. */
const RELATIONS = (() => {
  'use strict';
  const LIMIT=16, WINDOW=64, clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const copy=x=>JSON.parse(JSON.stringify(x));
  const signedLog=x=>Math.sign(x)*Math.log1p(Math.abs(x))/Math.log1p(86400000);
  const rows=()=>Array.from({length:LIMIT},()=>Array(LIMIT).fill(0));
  const vector=a=>Array.isArray(a)&&a.length===6&&a.every(v=>Number.isFinite(v)&&Math.abs(v)<=1);
  function distance(a,b) {
    const rad=Math.PI/180,dl=(b[0]-a[0])*rad,dn=(b[1]-a[1])*rad;
    const h=Math.sin(dl/2)**2+Math.cos(a[0]*rad)*Math.cos(b[0]*rad)*Math.sin(dn/2)**2;
    return 12742*Math.asin(Math.sqrt(clamp(h,0,1)));
  }
  function context(event,ledger) {
    const facts=event.factIds.map(id=>ledger.entries().find(f=>f.id===id));
    const values=Object.fromEntries(facts.map(f=>[f.predicate,f.value]));
    const geo=Number.isFinite(values.latitude)&&Math.abs(values.latitude)<=90&&Number.isFinite(values.longitude)&&Math.abs(values.longitude)<=180?[values.latitude,values.longitude]:null;
    return {id:event.id,kind:event.kind,subject:event.subject,source:event.source,at:event.observedAt,receivedAt:event.receivedAt,
      anchor:event.factIds[0],geo,glyphs:[...new Set(event.detail.contentGlyphs??event.glyphs)],
      magnitude:typeof values.magnitude==='number'?values.magnitude:null,
      revised:!!event.detail.archivedVersion||facts.some(f=>f.supersedes!==null),part:Number.isSafeInteger(values.part)?values.part:null,
      document:typeof values.name==='string'?`${values.name}:${values.modified_at??''}`:null};
  }
  class RelationField {
    constructor(){this.patterns=[];this.transitions=rows();this.recent=[];this.lastPattern=null;this.seen=0;}
    observe(event,ledger) {
      const c=context(event,ledger),previous=this.recent.at(-1),same=this.recent.findLast(x=>x.kind===c.kind);
      const priorVersion=this.recent.findLast(x=>x.subject===c.subject&&x.source===c.source);
      const device=this.recent.findLast(x=>x.kind==='device'&&x.geo);
      const spatial=(c.geo&&same?.geo)?distance(same.geo,c.geo):null;
      const deviceDistance=c.geo&&device?.geo?distance(device.geo,c.geo):null;
      const gap=same?c.at-same.at:null;
      const oldGlyphs=new Set(previous?.glyphs??[]),all=new Set([...oldGlyphs,...c.glyphs]);
      const overlap=previous&&all.size?c.glyphs.filter(g=>oldGlyphs.has(g)).length/all.size:0;
      const revisionDelta=c.revised&&c.magnitude!==null&&priorVersion?.magnitude!==null&&priorVersion?.magnitude!==undefined?c.magnitude-priorVersion.magnitude:null;
      const fragmentGap=c.document&&same?.document===c.document&&c.part!==null&&same.part!==null?c.part-same.part:null;
      const features=[gap===null?0:clamp(signedLog(gap),-1,1),spatial===null?0:Math.exp(-spatial/500),
        previous?(previous.kind===c.kind?1:-1):0,overlap,
        revisionDelta!==null?Math.tanh(revisionDelta):fragmentGap!==null?Math.tanh(fragmentGap/2):0,
        deviceDistance===null?0:Math.exp(-deviceDistance/500)];
      const d=this.patterns.map(p=>p.center.reduce((s,v,i)=>s+(v-features[i])**2,0)/6);
      const nearest=d.length?d.indexOf(Math.min(...d)):-1;
      const familiarity=nearest<0?0:Math.exp(-d[nearest]/.08);
      const known=nearest>=0&&d[nearest]<=.08;
      const transitionRow=this.lastPattern===null?null:this.transitions[this.lastPattern];
      const transitionMass=transitionRow?transitionRow.reduce((s,n)=>s+n,0):0;
      const transitionSupport=known&&transitionRow?transitionRow[nearest]:0;
      const expectation=transitionMass?transitionSupport/transitionMass:0;
      const priorSupport=known?this.patterns[nearest].mass:0;
      // The acquired channel reads the state BEFORE the current relation is learned.
      const drive=[features[0],features[1],features[2],features[3],features[4],features[5],familiarity,expectation];
      const active=!!previous,projection=[0,0];
      if(active)for(let i=0;i<drive.length;i++){
        projection[0]+=drive[i]*Math.cos((i+1)*2.3999632297)/drive.length;
        projection[1]+=drive[i]*Math.sin((i+1)*2.3999632297)/drive.length;
      }
      let chosen=nearest;
      if(!known&&this.patterns.length<LIMIT){chosen=this.patterns.length;this.patterns.push({center:features.slice(),mass:0});}
      const pattern=this.patterns[chosen];pattern.mass++;
      const alpha=1/Math.min(64,pattern.mass);
      pattern.center=pattern.center.map((v,i)=>v+alpha*(features[i]-v));
      if(this.lastPattern!==null)this.transitions[this.lastPattern][chosen]++;
      this.lastPattern=chosen;this.seen++;this.recent.push(c);if(this.recent.length>WINDOW)this.recent.shift();
      const anchors=[c.anchor,same?.anchor,device?.anchor,previous?.anchor,priorVersion?.anchor].filter(Boolean);
      const evidence=[...new Set(anchors)];
      return {policy:'amos/relations-v1',pattern:chosen,priorSupport,familiarity,expectation,transitionSupport,transitionMass,
        gapMs:gap,spatialKm:spatial,deviceKm:deviceDistance,glyphOverlap:overlap,revisionDelta,fragmentGap,
        features,projection,rawSensory:event.sensory.slice(),
        sensory:event.sensory.map((v,i)=>clamp(v+.35*projection[i],-1,1)),
        evidence,context:c.id,previous:previous?.id??null,patterns:this.patterns.length};
    }
    dump(){return copy(this);}
    static load(d,ledger){
      if(!d||!Number.isSafeInteger(d.seen)||d.seen<0||!Array.isArray(d.patterns)||d.patterns.length>LIMIT||
        !d.patterns.every(p=>p&&vector(p.center)&&Number.isSafeInteger(p.mass)&&p.mass>0)||
        !Array.isArray(d.transitions)||d.transitions.length!==LIMIT||!d.transitions.every(r=>Array.isArray(r)&&r.length===LIMIT&&r.every(n=>Number.isSafeInteger(n)&&n>=0))||
        !Number.isSafeInteger(d.recentBirth??0)||(d.recentBirth??0)<0||(d.recentBirth??0)>d.seen||
        !Array.isArray(d.recent)||d.recent.length>WINDOW||d.recent.length!==Math.min(WINDOW,d.seen-(d.recentBirth??0))||
        !d.recent.every(c=>c&&typeof c.id==='string'&&typeof c.kind==='string'&&typeof c.subject==='string'&&typeof c.source==='string'&&Number.isSafeInteger(c.at)&&Number.isSafeInteger(c.receivedAt)&&
          ledger.entries().some(f=>f.id===c.anchor&&f.subject===c.subject&&f.source===c.source&&f.recordedAt===c.receivedAt)&&
          (c.geo===null||Array.isArray(c.geo)&&c.geo.length===2&&c.geo.every(Number.isFinite)&&Math.abs(c.geo[0])<=90&&Math.abs(c.geo[1])<=180)&&
          Array.isArray(c.glyphs)&&c.glyphs.length<=132&&c.glyphs.every(g=>Number.isSafeInteger(g)&&g>=0&&g<88))||
        (d.seen===0?d.lastPattern!==null:!Number.isSafeInteger(d.lastPattern)||d.lastPattern<0||d.lastPattern>=d.patterns.length)||
        d.patterns.reduce((s,p)=>s+p.mass,0)!==d.seen||d.transitions.flat().reduce((s,n)=>s+n,0)!==Math.max(0,d.seen-1))throw Error('Invalid acquired relation field');
      return Object.assign(new RelationField(),copy(d));
    }
  }
  return {RelationField,distance,context,LIMIT,WINDOW};
})();


/* A read has content. Project actual returned receipts through the same
 * semantic membrane, retaining exact append-only journal indices as premises. */
const PERCEPTION = (() => {
  'use strict';
  const hash=text=>{let n=2166136261;for(const c of text)n=Math.imul(n^c.codePointAt(0),16777619);return n>>>0;};
  function read(result,ledger,tool,args,knownThrough,semanticVersion=3) {
    if(![1,2,3].includes(semanticVersion))throw Error('Unknown read membrane');
    const tokenize=semanticVersion===1?VOICE.tokenizeLegacy:semanticVersion===2?VOICE.tokenizePrevious:VOICE.tokenize;
    if(knownThrough!==undefined&&(!Number.isSafeInteger(knownThrough)||knownThrough<0||knownThrough>ledger.size))throw Error('Invalid read boundary');
    if(!result?.ok||!Array.isArray(result.data?.items))throw Error('Invalid tool reading');
    const rows=ledger.entries(),premises=[],glyphs=[],sensory=[0,0];
    for(const fact of result.data.items){
      const index=rows.findIndex(f=>f.id===fact.id);
      if(index<0||(knownThrough!==undefined&&index>=knownThrough)||fact.recordedAt>args.knownAt||JSON.stringify(rows[index])!==JSON.stringify(fact))throw Error('Tool reading differs from its source receipt');
      premises.push(index);
      if(fact.source==='amos:transition/v1'&&fact.predicate.startsWith('transition_')){
        const own=JSON.parse(fact.value);if(own.policy!=='amos/transition-v1'||!Number.isFinite(own.error)||!Array.isArray(own.observed)||own.observed.length!==3)throw Error('Invalid remembered transition');
        sensory[0]+=Math.tanh(own.error*4);sensory[1]+=Math.tanh((own.control?.effect??own.observed[2])*4);
        glyphs.push(...tokenize('me change cause remember').ids.slice(0,Math.max(0,128-glyphs.length)));continue;
      }
      if(fact.source==='amos:links/v1'&&fact.predicate==='encounter_links'){
        const own=JSON.parse(fact.value);if(own.policy!=='amos/encounter-links-v1'||!Array.isArray(own.sensory)||own.sensory.length!==2)throw Error('Invalid remembered association');
        sensory[0]+=own.sensory[0];sensory[1]+=own.sensory[1];glyphs.push(...own.matched.slice(0,Math.max(0,128-glyphs.length)));continue;
      }
      if(fact.source==='amos:tool-read/v1'&&fact.predicate==='tool_reading'){
        const own=JSON.parse(fact.value);if(!['amos/read-indices-v1','amos/read-indices-v2','amos/read-indices-v3'].includes(own.policy)||!Array.isArray(own.sensory)||own.sensory.length!==2)throw Error('Invalid remembered reading');
        sensory[0]+=own.sensory[0];sensory[1]+=own.sensory[1];glyphs.push(...own.glyphs.slice(0,Math.max(0,128-glyphs.length)));continue;
      }
      if(fact.source==='amos:attention/v1'&&fact.predicate==='fact_selection'){
        const own=JSON.parse(fact.value);if(own.policy!=='amos/acquired-attention-v1'||!Number.isFinite(own.selected?.score))throw Error('Invalid remembered choice');
        sensory[0]+=Math.tanh(own.selected.score);sensory[1]+=own.selected.novelty;
        glyphs.push(...tokenize('me choose remember').ids.slice(0,Math.max(0,128-glyphs.length)));continue;
      }
      if(fact.source==='amos:experience/v1'&&fact.predicate==='self_memory'){
        const own=JSON.parse(fact.value);if(own.policy!=='amos/carried-self-v1'||!Number.isFinite(own.error)||!Array.isArray(own.observed)||own.observed.length!==4)throw Error('Invalid carried self observation');
        sensory[0]+=Math.tanh(own.error*4);sensory[1]+=Math.tanh(own.observed[2]*4);
        glyphs.push(...tokenize('me think change remember').ids.slice(0,Math.max(0,128-glyphs.length)));continue;
      }
      if(fact.source==='amos:self/v1'&&fact.predicate==='self_reflection'){
        const own=JSON.parse(fact.value);
        if(own.policy!=='amos/self-sonar-v1'||!Number.isFinite(own.error)||!Array.isArray(own.observed)||own.observed.length!==4)throw Error('Invalid somatic self observation');
        sensory[0]+=Math.tanh(own.error*4);sensory[1]+=Math.tanh(own.observed[2]*4);
        glyphs.push(...tokenize('me think change remember').ids.slice(0,Math.max(0,128-glyphs.length)));continue;
      }
      const words=fact.predicate.replaceAll('_',' ')+(typeof fact.value==='string'?' '+fact.value:'');
      const parsed=tokenize(words),vector=[0,0];
      glyphs.push(...parsed.ids.slice(0,Math.max(0,128-glyphs.length)));
      for(const g of parsed.ids){vector[0]+=Math.cos(g*2.3999632297);vector[1]+=Math.sin(g*2.3999632297);}
      if(parsed.ids.length){vector[0]/=parsed.ids.length;vector[1]/=parsed.ids.length;}
      if(typeof fact.value==='number'||typeof fact.value==='boolean'){
        const value=typeof fact.value==='boolean'?(fact.value?1:-1):Math.tanh(Math.sign(fact.value)*Math.log1p(Math.abs(fact.value))/6);
        const angle=(hash(fact.predicate)%4096)*Math.PI*2/4096;
        vector[0]=(vector[0]+value*Math.cos(angle))/2;vector[1]=(vector[1]+value*Math.sin(angle))/2;
      }
      sensory[0]+=vector[0];sensory[1]+=vector[1];
    }
    if(premises.length){sensory[0]/=premises.length;sensory[1]/=premises.length;}
    const reading={policy:`amos/read-indices-v${semanticVersion}`,tool,arguments:args,premises,glyphs,sensory,
      total:result.data.total,complete:result.data.complete,nextOffset:result.data.nextOffset};
    if(knownThrough!==undefined)reading.knownThrough=knownThrough;
    if(result.data.scope)reading.scope=JSON.parse(JSON.stringify(result.data.scope));return reading;
  }
  return {read};
})();


/* Acquired attention and predictions of the subject's own response to a read.
 * All inputs are explicit; no host clock, I/O, RNG or presentation state. */
const COGNITION = (() => {
  'use strict';
  const copy=x=>JSON.parse(JSON.stringify(x)),clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const rms=a=>Math.sqrt(a.reduce((s,v)=>s+v*v,0)/Math.max(1,a.length));
  const mean=a=>a.reduce((s,v)=>s+v,0)/Math.max(1,a.length);
  const finite=a=>Array.isArray(a)&&a.every(v=>Number.isFinite(v)&&Math.abs(v)<1e6);
  function category(event){
    return event.kind==='message'||event.kind==='llm'&&event.detail.acquisition==='bridge'?'interaction':
      event.kind==='inference'?'derived-reading':'source-report';
  }
  function registration(event,ledger,version=2){
    const all=ledger.entries();
    const base={policy:'amos/registration-v1',category:category(event),subject:event.subject,source:event.source,
      worldAt:event.observedAt,receivedAt:event.receivedAt,acquiredVia:event.detail.acquisition??'adapter',origin:event.detail.origin??null,premises:event.factIds.map(id=>all.findIndex(f=>f.id===id))};
    if(version===1)return base;
    delete base.source;base.policy='amos/registration-v2';base.sensory=event.sensory.slice();base.glyphs=[...new Set(event.detail.contentGlyphs??event.glyphs)];return base;
  }
  function link(event,history,voice,ledger){
    const incoming=[...new Set(event.detail.contentGlyphs??event.glyphs)],window=history.slice(-64),all=ledger.entries();
    const contexts=window.map(t=>({trace:t,glyphs:[...new Set(t.event.detail.contentGlyphs??t.event.glyphs)]}));
    const weight=g=>1+Math.log((1+contexts.length)/(1+contexts.filter(c=>c.glyphs.includes(g)).length));
    const matches=contexts.map(({trace,glyphs})=>{
      const shared=incoming.filter(g=>glyphs.includes(g)),union=[...new Set([...incoming,...glyphs])];
      const similarity=shared.reduce((s,g)=>s+weight(g),0)/Math.max(1,union.reduce((s,g)=>s+weight(g),0));
      return {tick:trace.tick,id:trace.event.id,anchor:all.findIndex(f=>f.id===trace.event.factIds[0]),
        registration:all.findIndex(f=>f.id===trace.event.registrationReceipt),shared,similarity,sensory:trace.event.sensory.slice()};
    }).filter(m=>m.shared.length).sort((a,b)=>b.similarity-a.similarity||b.tick-a.tick).slice(0,3).map(({shared,...m})=>({...m,sharedSample:shared.slice(0,12),sharedCount:shared.length}));
    const matched=incoming.filter(g=>contexts.some(c=>c.glyphs.includes(g))),strength=matches[0]?.similarity??0,sensory=[0,0];
    const mass=matches.reduce((s,m)=>s+m.similarity,0);
    if(mass)for(const m of matches)for(let i=0;i<2;i++)sensory[i]+=strength*m.similarity*m.sensory[i]/mass;
    const evidence=matched.map(g=>{const c=contexts.find(c=>c.glyphs.includes(g));return [g,all.findIndex(f=>f.id===c.trace.event.factIds[0]),all.findIndex(f=>f.id===c.trace.event.registrationReceipt)];});
    return {policy:'amos/encounter-links-v1',evidence,considered:window.length,incoming,known:incoming.filter(g=>voice.uni[g]>0),
      novel:incoming.filter(g=>voice.uni[g]===0),matched,unmatched:incoming.filter(g=>!matched.includes(g)),matches,strength,sensory};
  }
  function measure(before,after,worldObservation,readObservation){
    return [mean(after),rms(after),rms(after.map((v,i)=>v-before[i])),rms(readObservation.slice(0,2).map((v,i)=>v-worldObservation[i]))];
  }
  class FactMind {
    constructor(width=40){
      this.width=width;this.weights=Array.from({length:4},()=>Array(width+6).fill(0));
      this.updates=0;this.kinds=[];this.focus=[];this.lastError=0;this.errorMean=0;this.lastSelf=null;
    }
    forecast(h,action,load,resonance,familiarity,surprise){
      const features=[1,...h,action,load,resonance,familiarity,Math.tanh(surprise)];
      const expected=this.weights.map((row,k)=>clamp(row.reduce((s,v,i)=>s+v*features[i],0),k===0?-1:0,k===0?1:2));
      return {features,expected,updatesBefore:this.updates};
    }
    learn(prediction,observed,event,worldSurprise){
      const delta=observed.map((v,k)=>v-prediction.expected[k]),error=rms(delta);
      const rate=.18/(1+prediction.features.reduce((s,v)=>s+v*v,0));
      this.weights=this.weights.map((row,k)=>row.map((v,i)=>v+rate*delta[k]*prediction.features[i]));
      this.updates++;this.focus=[...new Set(event.detail.contentGlyphs??event.glyphs)];this.lastError=error;this.errorMean+=.08*(error-this.errorMean);
      let stats=this.kinds.find(x=>x.kind===event.kind);
      if(!stats){if(this.kinds.length===32)this.kinds.sort((a,b)=>a.last-b.last).shift();stats={kind:event.kind,count:0,impact:0,last:0};this.kinds.push(stats);}
      stats.count++;stats.last=this.updates;
      const impact=Math.tanh(.5*worldSurprise+.5*observed[2]+error);
      stats.impact+=(impact-stats.impact)/Math.min(16,stats.count);
      return error;
    }
    rank(queue,voice,ledger,preferred,count,selectedId,controls={novelty:1}){
      const all=ledger.entries(),replaced=new Set(all.map(f=>f.supersedes));
      const ranked=queue.map((event,index)=>{
        const stats=this.kinds.find(x=>x.kind===event.kind),prior=stats?.impact??0;
        const glyphs=event.detail.contentGlyphs??event.glyphs,contextRelevance=glyphs.filter(g=>this.focus.includes(g)).length/Math.max(1,glyphs.length);
        const novelty=1-voice.resonance(event.detail.contentGlyphs??event.glyphs);
        const revision=event.detail.archivedVersion||event.factIds.some(id=>all.find(f=>f.id===id)?.supersedes!==null)?1:0;
        const stale=event.factIds.every(id=>replaced.has(id));
        const waiting=Math.max(0,count-(event.acceptedAtCount??0));
        const uncertainty=1/Math.sqrt(1+(stats?.count??0));
        const selfNeed=this.updates?this.lastError/(.05+this.errorMean):0;
        const evidenceNeed=Math.min(1,selfNeed)*revision;
        const score=.35*prior+.2*controls.novelty*novelty+.15*uncertainty+.2*revision+.08*Math.log1p(waiting)+
          .08*evidenceNeed+.1*contextRelevance+(event.kind===preferred?.08:0)-(stale?.1:0);
        return {id:event.id,index,score,priorImpact:prior,novelty,revision,waiting,uncertainty,evidenceNeed,contextRelevance,stale};
      }).sort((a,b)=>b.score-a.score||a.index-b.index);
      const explicit=ranked.find(x=>x.id===selectedId),chosen=explicit??ranked[0];
      return chosen?{policy:'amos/acquired-attention-v1',mode:explicit?'explicit':'acquired',selected:chosen,
        candidates:ranked.length,noveltyGain:controls.novelty,alternatives:ranked.filter(x=>x.id!==chosen.id).slice(0,3)}:null;
    }
    readScope(action){
      return this.lastSelf!==null&&this.updates>=2&&action<0&&this.lastError>this.errorMean?'self':'world';
    }
    dump(){return copy(this);}
    static load(d,width=40){
      if(d&&d.focus===undefined)d={...d,focus:[]};
      if(!d||!Array.isArray(d.focus)||d.focus.length>88||!d.focus.every(g=>Number.isSafeInteger(g)&&g>=0&&g<88)||d.width!==width||!Array.isArray(d.weights)||d.weights.length!==4||
        !d.weights.every(r=>finite(r)&&r.length===width+6)||!Number.isSafeInteger(d.updates)||d.updates<0||
        !Array.isArray(d.kinds)||d.kinds.length>32||new Set(d.kinds.map(k=>k.kind)).size!==d.kinds.length||
        !d.kinds.every(k=>typeof k.kind==='string'&&Number.isSafeInteger(k.count)&&k.count>0&&Number.isFinite(k.impact)&&k.impact>=0&&k.impact<=1&&Number.isSafeInteger(k.last)&&k.last>0&&k.last<=d.updates)||
        !Number.isFinite(d.lastError)||d.lastError<0||!Number.isFinite(d.errorMean)||d.errorMean<0||
        !(d.lastSelf===null||typeof d.lastSelf==='string'))throw Error('Invalid acquired self model');
      return Object.assign(new FactMind(width),copy(d));
    }
  }
  return {FactMind,category,registration,link,measure,rms};
})();


/* AMOS somatic loop, adapted from klaus.c 6fad88329538f0a820d5266796d456c9133559c6.
 * Arianna Method / Oleg Ataeff. GPL-3.0; license embedded in Amos-2.html.
 * Six chambers, 24 coupled phases, slow scars, Hebbian residue, coefficient
 * modulation and bounded re-inhale. The semantic input is AMOS's glyph membrane. */
const SONAR = (() => {
  'use strict';
  const names=['FEAR','LOVE','RAGE','VOID','FLOW','COMPLEX'];
  const coupling=[[0,-.3,.5,.4,-.2,.1],[-.3,0,-.4,-.5,.5,.2],[.5,-.3,0,.2,-.3,.3],
    [.4,-.5,.3,0,-.3,.4],[-.2,.4,-.2,-.3,0,.3],[.1,.2,.3,.4,.3,0]];
  const frequencies=[[.3,.4,.8,.1,.5,.35],[1.2,.6,1.5,.2,.7,.55],[.6,.5,.9,.15,.6,.45],[.9,.3,1.1,.08,.4,.65]];
  const intra=[[0,.3,.2,.1],[.3,0,.15,-.1],[.2,.15,0,.1],[.1,-.1,.1,0]];
  const anchors=['fear pain death stress','love bond help joy','anger conflict break','grief longing never dark',
    'music go free agree','think question idea how cause know'];
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),copy=x=>JSON.parse(JSON.stringify(x));
  const vector=a=>Array.isArray(a)&&a.length===6&&a.every(x=>Number.isFinite(x)&&x>=0&&x<=1);
  function semantic(ids,symbols=[]){
    const cache=new Map();
    function meaning(id){
      if(!Number.isSafeInteger(id)||id<0||id>=88+symbols.length)throw Error('Unknown returned representation');
      if(cache.has(id))return cache.get(id);
      let out;
      if(id<88)out=anchors.map(words=>Number(words.split(' ').includes(VOICE.names[id])));
      else{const pair=symbols[id-88];if(!Array.isArray(pair)||pair.length!==2||!pair.every(p=>Number.isSafeInteger(p)&&p>=0&&p<id))throw Error('Invalid returned compound');
        const a=meaning(pair[0]),b=meaning(pair[1]);out=a.map((v,c)=>(v+b[c])/2);}
      cache.set(id,out);return out;
    }
    const out=Array(6).fill(0);for(const id of ids){const v=meaning(id);for(let c=0;c<6;c++)out[c]+=v[c]/Math.max(1,ids.length);}return out;
  }
  class SomaticSonar {
    constructor(){
      this.act=[0,.15,0,0,.1,0];this.soma=Array(6).fill(0);this.scar=Array(6).fill(0);
      this.phases=Array.from({length:6},(_,c)=>Array.from({length:4},(_,s)=>c*Math.PI/3+s*Math.PI/12));
      this.hebb=Array.from({length:6},()=>Array(6).fill(0));this.memory=[];this.coherence=0;this.phaseLock=0;
      this.deepTicks=0;this.turns=0;
    }
    crossfire(){
      for(let t=0;t<4;t++){
        const old=copy(this.phases),acts=this.act.slice(),drive=Array(6).fill(0);
        for(let c=0;c<6;c++)for(let s=0;s<4;s++){
          let velocity=frequencies[s][c];
          for(let j=0;j<4;j++)velocity+=intra[s][j]*Math.sin(old[c][j]-old[c][s]);
          for(let d=0;d<6;d++)if(d!==c)velocity+=.03*coupling[c][d]*Math.sin(old[d].reduce((a,b)=>a+b,0)/4-old[c][s]);
          this.phases[c][s]=((old[c][s]+.1*velocity)%(2*Math.PI)+2*Math.PI)%(2*Math.PI);
          // Klaus couples phase velocity back into activation; a saved phase
          // must change the body's next response, rather than just its display.
          drive[c]+=.003*Math.sin(velocity)/4;
        }
        this.act=acts.map((v,c)=>clamp(.97*v+.03*coupling[c].reduce((sum,w,d)=>sum+w*acts[d],0)+drive[c]));
      }
    }
    inhale(ids,{surprise=0,resonance=0,familiarity=0,revision=0,selfError=0,unmatched=0}={}){
      this.crossfire();const input=semantic(ids),memory=Array(6).fill(0);let mass=0;
      for(let i=0;i<this.memory.length;i++){const w=.85**(this.memory.length-1-i);mass+=w;for(let c=0;c<6;c++)memory[c]+=w*this.memory[i][c];}
      if(mass)for(let c=0;c<6;c++)memory[c]/=mass;
      const body=[Math.tanh(surprise)*.35,resonance*.25,revision*.12,(1-familiarity)*.08,
        familiarity*.2,Math.tanh(selfError)*.3+revision*.2+.15*unmatched];
      this.act=this.act.map((v,c)=>{
        const echo=this.hebb[c].reduce((s,w,j)=>s+w*input[j],0)/6;
        return clamp(.35*v+.3*input[c]+.15*memory[c]+.1*this.soma[c]+body[c]+.08*echo+.05*this.scar[c]);
      });
      this.scar=this.scar.map((v,c)=>clamp(.985*v+(this.act[c]>.75?.04*this.act[c]:0)));
      this.refresh();return input;
    }
    refresh(){
      const total=this.act.reduce((s,v)=>s+v,0),entropy=total?this.act.reduce((s,v)=>v?s-(v/total)*Math.log(v/total):s,0):0;
      this.coherence=clamp(1-entropy/Math.log(6));this.phaseLock=.85*this.phaseLock+.15*this.coherence;
      if(this.coherence>.35)this.deepTicks=5;else if(this.deepTicks)this.deepTicks--;
    }
    gate(){return clamp(.5+1.35*(.5*this.coherence+.34*this.phaseLock-.42+.06*this.deepTicks/5));}
    coefficients(){
      const [fear,love,rage,void_,flow,complex]=this.act;
      return {perception:clamp(1+.12*flow-.08*fear+.04*complex,.8,1.2),
        plasticity:clamp(1+.3*love-.2*rage+.1*flow,.5,2),
        recall:clamp(1+.4*void_+.2*complex-.1*love,.5,2),
        exploration:clamp(.18+.12*complex+.08*flow-.1*fear,.03,.4),
        temperature:clamp(1+.5*flow-.3*fear,.5,2),novelty:1+.3*complex-.2*fear};
    }
    reinhale(ids,symbols=[]){
      const meta=semantic(ids,symbols),before=this.act.slice();
      this.act=this.act.map((v,c)=>clamp(.85*v+.15*(.6*meta[c]+.4*this.soma[c])));
      this.refresh();return {before,after:this.act.slice(),gate:this.gate(),projection:this.projection()};
    }
    projection(){
      const xy=[0,0];for(let c=0;c<6;c++){xy[0]+=this.act[c]*Math.cos((c+1)*2.3999632297)/6;xy[1]+=this.act[c]*Math.sin((c+1)*2.3999632297)/6;}return xy;
    }
    settle(input){
      for(let c=0;c<6;c++)for(let d=0;d<6;d++)this.hebb[c][d]=clamp(.999*this.hebb[c][d]+.05*this.act[c]*input[d]);
      this.soma=this.soma.map((v,c)=>.92*v+.08*this.act[c]);
      this.memory.push(this.act.slice());if(this.memory.length>32)this.memory.shift();this.turns++;
    }
    dump(){return copy(this);}
    static load(d){
      if(!d||![d.act,d.soma,d.scar].every(vector)||!Array.isArray(d.phases)||d.phases.length!==6||
        !d.phases.every(row=>Array.isArray(row)&&row.length===4&&row.every(v=>Number.isFinite(v)&&v>=0&&v<2*Math.PI))||
        !Array.isArray(d.hebb)||d.hebb.length!==6||!d.hebb.every(vector)||!Array.isArray(d.memory)||d.memory.length>32||!d.memory.every(vector)||
        !Number.isSafeInteger(d.turns)||d.turns<0||![d.coherence,d.phaseLock].every(v=>Number.isFinite(v)&&v>=0&&v<=1)||
        !Number.isSafeInteger(d.deepTicks)||d.deepTicks<0||d.deepTicks>5||d.memory.length!==Math.min(32,d.turns))throw Error('Invalid somatic sonar');
      return Object.assign(new SomaticSonar(),copy(d));
    }
  }
  return {SomaticSonar,names,semantic};
})();


/* Predictions and interventions over the subject's actual state transitions.
 * NETTA.SONAR informs the trace-driven view; this organ learns AMOS's own body.
 * No clock, presentation, source acquisition or random draw occurs here. */
const TRANSITIONS = (() => {
  'use strict';
  const phases=['world','read','return'],copy=x=>JSON.parse(JSON.stringify(x));
  const rms=a=>Math.sqrt(a.reduce((s,v)=>s+v*v,0)/Math.max(1,a.length));
  const mean=a=>a.reduce((s,v)=>s+v,0)/Math.max(1,a.length);
  const close=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-12*Math.max(1,Math.abs(a),Math.abs(b));
  const vector=(a,n)=>Array.isArray(a)&&a.length===n&&a.every(v=>Number.isFinite(v)&&Math.abs(v)<1e6);
  const same=(a,b)=>Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>close(v,b[i]));
  const measure=(before,after)=>[mean(after),rms(after),rms(after.map((v,i)=>v-before[i]))];
  const features=(before,observation,action,signal)=>[1,...before,...observation,action,Math.tanh(signal)];
  class TransitionMind {
    constructor(width=40){
      this.width=width;this.heads=Object.fromEntries(phases.map(phase=>[phase,{weights:Array.from({length:3},()=>Array(width+6).fill(0)),updates:0,errorMean:0,lastError:0}]));
      this.last=[];this.lastProbe=-2;
    }
    forecast(phase,before,observation,action,signal){
      const head=this.heads[phase],f=features(before,observation,action,signal);
      const expected=head.weights.map((row,k)=>Math.max(k===0?-2:0,Math.min(k===0?2:3,row.reduce((s,v,i)=>s+v*f[i],0))));
      return {phase,before:before.slice(),observation:observation.slice(),action,signal,expected,updatesBefore:head.updates};
    }
    learn(prediction,after,premises,control=null){
      const head=this.heads[prediction.phase],observed=measure(prediction.before,after),delta=observed.map((v,i)=>v-prediction.expected[i]),error=rms(delta);
      const f=features(prediction.before,prediction.observation,prediction.action,prediction.signal),rate=.18/(1+f.reduce((s,v)=>s+v*v,0));
      const baseline=head.errorMean;
      head.weights=head.weights.map((row,k)=>row.map((v,i)=>v+rate*delta[k]*f[i]));
      head.updates++;head.lastError=error;head.errorMean+=.08*(error-head.errorMean);
      return {policy:'amos/transition-v1',...copy(prediction),after:after.slice(),observed,error,baseline,premises:premises.slice(),control:control?{
        observation:control.observation.slice(),after:control.after.slice(),steps:control.steps,
        effect:rms(after.map((v,i)=>v-control.after[i]))}:null};
    }
    remember(records,receipts,tick,ledger,probe){
      const rows=ledger.entries();this.last=records.map((r,i)=>({phase:r.phase,id:receipts[i],tick,error:r.error,
        premise:rows.findIndex(f=>f.id===receipts[i]),sourcePremise:r.premises[0]??null}));
      if(probe)this.lastProbe=this.heads.world.updates;
    }
    plan(ledger,knownAt){
      const age=this.heads.world.updates;if(age<3||age-this.lastProbe<2)return null;
      const candidates=this.last.filter(r=>r.error>.04&&r.error>1.25*this.heads[r.phase].errorMean)
        .sort((a,b)=>b.error/(.02+this.heads[b.phase].errorMean)-a.error/(.02+this.heads[a.phase].errorMean));
      const previous=candidates[0];if(!previous)return null;
      const rows=ledger.entries(),anchor=rows[previous.phase==='world'?previous.sourcePremise:previous.premise];if(!anchor)return null;
      const target=previous.phase==='world'?rows.findLast(f=>f.subject===anchor.subject&&f.predicate===anchor.predicate&&f.source===anchor.source&&f.recordedAt<=knownAt):anchor;
      return {policy:'amos/transition-probe-v1',phase:previous.phase,fromTick:previous.tick,error:previous.error,
        baseline:this.heads[previous.phase].errorMean,premise:rows.findIndex(f=>f.id===target.id),scope:previous.phase==='world'?'world':'self',
        tool:'lalo_lineage',arguments:{id:target.id,knownAt,offset:ledger.lineage(target.id).length-1,limit:1}};
    }
    dump(){return copy(this);}
    static load(d,width=40){
      if(!d||d.width!==width||!d.heads||Object.keys(d.heads).length!==3||!phases.every(p=>{
        const h=d.heads[p];return h&&Array.isArray(h.weights)&&h.weights.length===3&&h.weights.every(row=>vector(row,width+6))&&
          Number.isSafeInteger(h.updates)&&h.updates>=0&&Number.isFinite(h.errorMean)&&h.errorMean>=0&&Number.isFinite(h.lastError)&&h.lastError>=0;
      })||!Array.isArray(d.last)||![0,3].includes(d.last.length)||!Number.isSafeInteger(d.lastProbe)||d.lastProbe< -2||d.lastProbe>d.heads.world.updates||
        !d.last.every((r,i)=>r.phase===phases[i]&&typeof r.id==='string'&&Number.isSafeInteger(r.tick)&&r.tick>0&&Number.isSafeInteger(r.premise)&&r.premise>=0&&Number.isFinite(r.error)&&r.error>=0&&
          (r.sourcePremise===null||Number.isSafeInteger(r.sourcePremise)&&r.sourcePremise>=0)))throw Error('Invalid acquired transition model');
      return Object.assign(new TransitionMind(width),copy(d));
    }
  }
  function validate(trace,ledger,width=40,birth){
    const records=trace.transitions,rows=ledger.entries(),legacy=trace.receiptState==='legacy-full-journal'&&trace.event.legacyCompletion===true;
    if(!Array.isArray(records)||records.length!==3||!Array.isArray(trace.transitionReceipts)||trace.transitionReceipts.length!==3||
      !Array.isArray(trace.trajectory)||trace.trajectory.length!==3+trace.selfReflection.passes.length)throw Error('Invalid transition trace');
    const states=[trace.before,trace.worldAfter,trace.readAfter,trace.after];
    for(let i=0;i<3;i++){
      const r=records[i],index=rows.findIndex(f=>f.id===trace.transitionReceipts[i]),receipt=rows[index];
      if(r?.policy!=='amos/transition-v1'||r.phase!==phases[i]||!vector(r.before,width)||!vector(r.after,width)||
        !same(r.before,states[i])||!same(r.after,states[i+1])||!vector(r.observation,3)||![-1,0,1].includes(r.action)||!Number.isFinite(r.signal)||
        !same(r.observation,i===0?trace.observed:trace.readObservation)||i>0&&r.action!==trace.action||
        !vector(r.expected,3)||!same(r.observed,measure(r.before,r.after))||!close(r.error,rms(r.observed.map((v,k)=>v-r.expected[k])))||
        !Number.isFinite(r.baseline)||r.baseline<0||!Number.isSafeInteger(r.updatesBefore)||r.updatesBefore<0||
        (birth!==undefined&&trace.tick>birth&&r.updatesBefore!==trace.tick-birth-1)||
        !Array.isArray(r.premises)||!r.premises.every(n=>Number.isSafeInteger(n)&&n>=0&&!!rows[n]&&(legacy||n<index)&&rows[n].recordedAt<=trace.encounterAt)||
        (!legacy&&(!receipt||receipt.source!=='amos:transition/v1'||receipt.value!==JSON.stringify(r))))throw Error('Transition differs from its state or premises');
      if(i===0&&r.control!==null||i>0&&(!r.control||!vector(r.control.after,width)||!same(r.control.observation,i===1?trace.observed:trace.readObservation)||
        r.control.steps!==(i===1?1:trace.selfReflection.passes.length)||!close(r.control.effect,rms(r.after.map((v,k)=>v-r.control.after[k])))))throw Error('Invalid controlled transition');
    }
    const labels=['before','world','read',...trace.selfReflection.passes.map((p,i)=>'return-'+(i+1))];
    const anchors=[trace.before,trace.worldAfter,trace.readAfter];
    if(!trace.trajectory.every((node,i)=>node.name===labels[i]&&vector(node.h,width)&&(i>=3||same(node.h,anchors[i])))||
      !same(trace.trajectory.at(-1).h,trace.after))throw Error('Trajectory differs from the acquired states');
    for(let i=3;i<trace.trajectory.length;i++)if(!close(rms(trace.trajectory[i].h.map((v,k)=>v-trace.trajectory[i-1].h[k])),trace.selfReflection.passes[i-3].shift))throw Error('Return trajectory differs from its measured shift');
    const probe=trace.investigation;
    if(trace.selection.investigation!==undefined&&JSON.stringify(trace.selection.investigation)!==JSON.stringify(probe))throw Error('Investigation differs from its archived attention decision');
    if(probe!==null&&(!probe||probe.policy!=='amos/transition-probe-v1'||!phases.includes(probe.phase)||!Number.isSafeInteger(probe.fromTick)||probe.fromTick>=trace.tick||
      !Number.isSafeInteger(probe.premise)||!rows[probe.premise]||rows[probe.premise].id!==probe.arguments?.id||
      probe.scope!==(probe.phase==='world'?'world':'self')||probe.tool!==trace.tool.name||JSON.stringify(probe.arguments)!==JSON.stringify(trace.tool.arguments)||!records[1].premises.includes(probe.premise)))throw Error('Invalid self investigation');
  }
  return {TransitionMind,phases,measure,validate,rms};
})();


/* LALO → AMOS → expression. Portable, event-driven; clocks enter explicitly.
 * The AMOS Subject is the existing JS body, with its own predictor and RNG.
 * No presentation frame, fetch failure or repeated feed advances this life. */
const AMOS2 = (() => {
  'use strict';
  const CAPACITY=4096, MAX_QUEUE=128, MAX_HISTORY=128, MAX_SNAPSHOT=24_000_000, MAX_JOURNAL=8_000_000, ENCOUNTER_RECEIPTS=9, RESERVE_BYTES=32000;
  const bounded=(n,a,b)=>Math.max(a,Math.min(b,n));
  const clone=value=>JSON.parse(JSON.stringify(value));
  const magnitude=a=>Math.sqrt(a.reduce((s,v)=>s+v*v,0)/Math.max(1,a.length));
  const integer=n=>Number.isSafeInteger(n);
  const bytes=s=>new TextEncoder().encode(s).length;
  const finiteArray=(a,n)=>Array.isArray(a)&&a.length===n&&a.every(v=>typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<1e12);
  // Recomputed libm projections may differ by a few ulps across JS engines.
  // Stored receipts remain byte-exact; loading never rewrites acquired numbers.
  const close=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-12*Math.max(1,Math.abs(a),Math.abs(b));
  const closeArray=(a,b)=>Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>close(v,b[i]));
  const sameReading=(a,b)=>!!b&&closeArray(a.sensory,b.sensory)&&JSON.stringify({...a,sensory:null})===JSON.stringify({...b,sensory:null});
  const BODY=AMOS.withWidth(40);
  // An encounter is mid-transaction: its new memory tick is not committed yet.
  // Copy only the live subject for interventions; never change its world clock.
  function copySubject(subject){
    const data=clone(subject),out=Object.assign(Object.create(BODY.Subject.prototype),data);
    out.rng=new BODY.Random(BigInt('0x'+data.rng.random64));
    out.glyph=Object.assign(Object.create(BODY.Glyphs.prototype),data.glyph);
    out.body=Object.assign(Object.create(BODY.Embodiment.prototype),data.body);return out;
  }
  const encode=ledger=>LALO.encodeJournal(ledger,{maxBytes:MAX_JOURNAL});
  const decode=text=>LALO.decodeJournal(text,{capacity:CAPACITY,maxBytes:MAX_JOURNAL});
  const scope=chapter=>chapter?.number>1?{policy:'amos/current-chapter-v1',chapter:chapter.number,fromCount:chapter.fromCount,archive:chapter.archive}:null;
  const makeHost=(ledger,chapter)=>{const host=LALO.createToolHost(ledger,{capacity:CAPACITY,maxBytes:MAX_JOURNAL});return {call:(name,args)=>{
    const result=host.call(name,args),boundary=scope(chapter);return result.ok&&boundary?{...result,data:{...result.data,scope:boundary}}:result;
  }};};
  const featureMap=(i,width)=>i<5+width?i:i<5+2*width?i+BODY.H-width:BODY.F-1;
  const growFeatures=(a,width)=>{const next=Array(BODY.F).fill(0);a.forEach((v,i)=>next[featureMap(i,width)]=v);return next;};
  function growModel(text) {
    const old=AMOS.Amos.loads(text),width=old.subject.h.length;if(width===BODY.H)return old;
    const extra=BODY.H-width,pad=()=>Array(extra).fill(0),d=JSON.parse(old.dumps()),a=d.amos,s=a.subject;
    const fresh=JSON.parse(new BODY.Amos(BigInt('0x'+a.seed),a.world.kind,s.glyph.enabled,s.mode).dumps()).amos.subject;
    const weights=Array.from({length:3},(_,k)=>growFeatures(s.weights[k],width));
    const covariance=Array.from({length:BODY.F},(_,i)=>Array.from({length:BODY.F},(_,j)=>i===j?100:0));
    for(let i=0;i<2*width+6;i++)for(let j=0;j<2*width+6;j++)covariance[featureMap(i,width)][featureMap(j,width)]=s.covariance[i][j];
    s.h=s.h.concat(pad());s.win=s.win.concat(fresh.win.slice(width));
    s.recurrent=s.recurrent.map(row=>row.concat(pad())).concat(fresh.recurrent.slice(width));
    s.weights=weights;s.covariance=covariance;s.glyph.prototypes=s.glyph.prototypes.map(row=>row.concat(pad()));
    a.memory=a.memory.map(t=>({...t,features:growFeatures(t.features,width)}));
    return BODY.Amos.loads(JSON.stringify(d));
  }
  // Only a current head from the same source can be an unchanged observation.
  function currentVersion(ledger,subject,source) {
    const all=ledger.entries(),last=all.findLast(f=>f.subject===subject&&f.source===source);
    if(!last)return [];
    const prefix=last.id.slice(0,last.id.lastIndexOf(':')+1),replaced=new Set(all.map(f=>f.supersedes));
    return all.filter(f=>f.subject===subject&&f.source===source&&f.id.startsWith(prefix)&&!replaced.has(f.id));
  }
  const unchanged=(facts,values,from,to)=>facts.length===Object.keys(values).length&&facts.every(f=>Object.hasOwn(values,f.predicate)&&f.value===values[f.predicate]&&f.validFrom===from&&f.validTo===to);
  const gid=name=>VOICE.names.indexOf(name);
  const ids=names=>names.map(gid);
  const latestReceipt=ledger=>ledger.entries().at(-1)?.recordedAt??0;
  const worldKind=kind=>typeof kind==='string'&&/^[a-z][a-z0-9-]{0,31}$/.test(kind);
  const fingerprint=text=>{let n=14695981039346656037n;for(const c of text)n=BigInt.asUintN(64,(n^BigInt(c.codePointAt(0)))*1099511628211n);return n.toString(16);};
  const versionDigest=(values,from,to)=>fingerprint(JSON.stringify([from,to,Object.entries(values).sort(([a],[b])=>a<b?-1:a>b?1:0)]));
  const archivedVersion=(life,subject,source)=>life.sourceMemory.find(m=>m.subject===subject&&m.source===source);
  function sourceMemories(life,archive){
    const out=life.sourceMemory.slice(),groups=new Map();
    for(const f of life.ledger.entries())if(!f.source.startsWith('amos:')&&f.source!=='local:human')groups.set(JSON.stringify([f.subject,f.source]),[f.subject,f.source]);
    for(const [subject,source] of groups.values()){
      const facts=currentVersion(life.ledger,subject,source);if(!facts.length)continue;
      const values=Object.fromEntries(facts.map(f=>[f.predicate,f.value])),first=facts[0],old=out.findIndex(m=>m.subject===subject&&m.source===source);
      if(old>=0)out.splice(old,1);out.push({subject,source,digest:versionDigest(values,first.validFrom,first.validTo),fromFact:first.id,archive,
        revision:Number.isSafeInteger(values.source_updated_at)?values.source_updated_at:null});
    }
    return out.slice(-128);
  }
  function prefixLedger(ledger,count){
    if(count===undefined)return ledger;
    const rows=ledger.entries();if(!integer(count)||count<0||count>rows.length)throw Error('Invalid knowledge boundary');
    const out=new LALO.FactLedger({capacity:CAPACITY});for(const f of rows.slice(0,count))out.add(f);return out;
  }
  function inference(query,ledger) {
    const known=prefixLedger(ledger,query.knownThrough);
    return query.rule===LALO.RULE?LALO.hypothesis(known,query):LALO.magnitudeHypothesis(known,query);
  }
  function validateEvaluation(fact,ledger){
    const d=JSON.parse(fact.value),all=ledger.entries(),index=all.findIndex(f=>f.id===fact.id);
    if(d?.policy!=='amos/named-evaluation-v1'||!integer(d.query?.knownThrough)||d.query.knownThrough<0||d.query.knownThrough>index||
      !integer(d.query.knownAt)||d.query.knownAt>fact.recordedAt||![LALO.RULE,LALO.MAGNITUDE_RULE].includes(d.query.rule))throw Error('Invalid recorded evaluation');
    const result=inference(d.query,ledger);
    if(result.state!==d.state||JSON.stringify(result.premises.map(id=>all.findIndex(f=>f.id===id)))!==JSON.stringify(d.premises))throw Error('Evaluation differs from its knowledge boundary');
    return d;
  }
  function validateInference(event,ledger){
    const d=event.detail.derivation;
    if(event.source!=='amos:inference/v1'||!d||![LALO.RULE,LALO.MAGNITUDE_RULE].includes(d.query?.rule)||
      !integer(d.query.knownAt)||d.query.knownAt>event.receivedAt||d.query.validAt!==event.observedAt||
      !Array.isArray(d.premises)||d.premises.length>128)throw Error('Invalid named inference');
    const result=inference(d.query,ledger),all=ledger.entries();
    if(JSON.stringify(result.premises.map(id=>all.findIndex(f=>f.id===id)))!==JSON.stringify(d.premises)||
      !event.factIds.some(id=>all.some(f=>f.id===id&&f.predicate==='state'&&f.value===result.state))||
      !event.factIds.some(id=>all.some(f=>f.id===id&&f.predicate==='premise_indices'&&f.value===JSON.stringify(d.premises))))throw Error('Inference differs from its premises');
    if(d.evaluationReceipt){const evaluation=all.find(f=>f.id===d.evaluationReceipt);
      if(!evaluation||evaluation.source!=='amos:evaluation/v1'||JSON.stringify(validateEvaluation(evaluation,ledger).query)!==JSON.stringify(d.query))throw Error('Missing inference evaluation');}
  }
  function validateReflection(t,ledger,voice){
    const r=t.selfReflection,all=ledger.entries(),legacy=t.receiptState==='legacy-full-journal'&&t.event.legacyCompletion===true;
    const expectedFeatures=[1,...t.worldAfter,t.action,t.load,t.resonance,t.relations.familiarity,Math.tanh(t.surprise)];
    if(!r||r.policy!=='amos/self-sonar-v1'||!finiteArray(r.forecast?.features,BODY.H+6)||!finiteArray(r.forecast?.expected,4)||
      JSON.stringify(r.forecast.features.slice(0,-1))!==JSON.stringify(expectedFeatures.slice(0,-1))||!close(r.forecast.features.at(-1),expectedFeatures.at(-1))||
      !integer(r.forecast.updatesBefore)||r.forecast.updatesBefore<0||!finiteArray(r.observed,4)||
      !finiteArray(t.readAfter,BODY.H)||!finiteArray(t.finalObservation,3)||!integer(t.encounterAt)||t.encounterAt<t.event.receivedAt||
      !closeArray(COGNITION.measure(t.worldAfter,t.after,t.observed,t.finalObservation),r.observed)||
      !close(COGNITION.rms(r.observed.map((v,k)=>v-r.forecast.expected[k])),r.error)||
      !['self','world'].includes(r.scope)||!finiteArray(r.before,6)||!finiteArray(r.after,6)||
      !r.controls||!Object.values(r.controls).every(v=>Number.isFinite(v)&&v>0)||
      !Array.isArray(r.passes)||!r.passes.length||r.passes.length>4||
      !r.passes.every((p,i)=>p.depth===i+1&&finiteArray(p.after,6)&&p.after.every(v=>v>=0&&v<=1)&&finiteArray(p.observation,3)&&
        Number.isFinite(p.shift)&&p.shift>=0&&Number.isFinite(p.gate)&&p.gate>=0&&p.gate<=1&&Array.isArray(p.draft)&&p.draft.length===5&&p.draft.every(integer))||
      JSON.stringify(r.passes.at(-1).observation)!==JSON.stringify(t.finalObservation)||
      r.registrationPremise!==all.findIndex(f=>f.id===t.event.registrationReceipt)||
      JSON.stringify(r.sourcePremises)!==JSON.stringify(t.event.factIds.map(id=>all.findIndex(f=>f.id===id)))||
      !t.selection||t.selection.selected?.id!==t.event.id||!['explicit','acquired'].includes(t.selection.mode)||
      !Array.isArray(t.selection.alternatives)||t.selection.alternatives.length>3||
      ![t.selection.selected,...t.selection.alternatives].every(c=>typeof c.id==='string'&&Number.isFinite(c.score)))throw Error('Invalid self-reflection or attention decision');
    if(r.returnPolicy!==undefined){
      if(r.returnPolicy!=='amos/glyph-return-v1')throw Error('Unknown representation return');
      for(const p of r.passes){const g=p.representations;
        if(!g||!integer(g.base)||g.base<0||g.base>voice.symbols.length||
          (g.born!==null&&(!Array.isArray(g.born)||g.born.length!==2||!g.born.every(id=>integer(id)&&id>=0&&id<88+g.base))))throw Error('Invalid returned representation inventory');
        SONAR.semantic(p.draft,voice.symbols.slice(0,g.base).concat(g.born?[g.born]:[]));
        const xy=[0,0];for(let c=0;c<6;c++){xy[0]+=p.after[c]*Math.cos((c+1)*2.3999632297)/6;xy[1]+=p.after[c]*Math.sin((c+1)*2.3999632297)/6;}
        if(!closeArray(p.observation,[...t.readObservation.slice(0,2).map((v,i)=>bounded(v+.1*xy[i],-1,1)),t.readObservation[2]]))throw Error('Representation return differs from its somatic projection');
      }
    }
    for(const [id,source,value] of [[t.selfReceipt,'amos:self/v1',r],[t.selectionReceipt,'amos:attention/v1',t.selection]]){
      const fact=all.find(f=>f.id===id);
      if(!legacy&&(!fact||fact.source!==source||fact.recordedAt!==t.encounterAt||fact.value!==JSON.stringify(value)))throw Error('Missing self-observation receipt');
    }
    if(t.policy==='amos/reflective-facts-v2'){
      const a=t.associations,receipt=all.find(f=>f.id===t.linkReceipt),incoming=[...new Set(t.event.detail.contentGlyphs??t.event.glyphs)];
      const ids=items=>Array.isArray(items)&&new Set(items).size===items.length&&items.every(g=>integer(g)&&incoming.includes(g));
      if(!a||a.policy!=='amos/encounter-links-v1'||JSON.stringify(a.incoming)!==JSON.stringify(incoming)||
        ![a.known,a.novel,a.matched,a.unmatched].every(ids)||
        !ids(a.known.concat(a.novel))||a.known.length+a.novel.length!==incoming.length||
        !ids(a.matched.concat(a.unmatched))||a.matched.length+a.unmatched.length!==incoming.length||
        !Array.isArray(a.matches)||a.matches.length>3||!finiteArray(a.sensory,2)||!Number.isFinite(a.strength)||a.strength<0||a.strength>1||
        !Array.isArray(a.evidence)||a.evidence.length!==a.matched.length||
        !a.evidence.every(([g,anchor,registration])=>a.matched.includes(g)&&integer(anchor)&&anchor>=0&&!!all[anchor]&&all[anchor].recordedAt<=t.encounterAt&&
          (registration===-1||integer(registration)&&!!all[registration]&&JSON.parse(all[registration].value).premises.includes(anchor)&&
            (JSON.parse(all[registration].value).policy!=='amos/registration-v2'||JSON.parse(all[registration].value).glyphs.includes(g))))||
        !a.matches.every(m=>integer(m.tick)&&m.tick<t.tick&&integer(m.anchor)&&!!all[m.anchor]&&finiteArray(m.sensory,2)&&Number.isFinite(m.similarity)&&m.similarity>0&&m.similarity<=1)||
        (!legacy&&(!receipt||receipt.source!=='amos:links/v1'||receipt.value!==JSON.stringify(a)||r.associationPremise!==all.findIndex(f=>f.id===t.linkReceipt))))throw Error('Invalid encounter association');
    }
  }
  function eventValid(e,ledger) {
    if(!e||typeof e.id!=='string'||!worldKind(e.kind)||
      !integer(e.observedAt)||!integer(e.receivedAt)||typeof e.title!=='string'||e.title.length>4096||
      typeof e.subject!=='string'||!e.subject||e.subject.length>512||typeof e.source!=='string'||
      typeof e.projection!=='string'||e.projection.length>512||!e.detail||typeof e.detail!=='object'||Array.isArray(e.detail)||
      !finiteArray(e.sensory,2)||e.sensory.some(v=>Math.abs(v)>1)||
      !Array.isArray(e.glyphs)||e.glyphs.length>132||!e.glyphs.every(v=>integer(v)&&v>=0&&v<88)||
      !Array.isArray(e.factIds)||e.factIds.length>16||!e.factIds.length||
      new Set(e.factIds).size!==e.factIds.length||
      !e.factIds.every(id=>ledger.entries().some(f=>f.id===id&&f.subject===e.subject&&f.source===e.source&&f.validFrom===e.observedAt&&f.recordedAt===e.receivedAt)))throw Error('Invalid encounter or missing source receipts');
    if(e.registrationReceipt!==undefined){
      const f=ledger.entries().find(f=>f.id===e.registrationReceipt);
      if(!f||f.source!=='amos:registration/v1'||f.recordedAt!==e.receivedAt||f.value!==JSON.stringify(COGNITION.registration(e,ledger,JSON.parse(f.value).policy==='amos/registration-v1'?1:2))||!integer(e.acceptedAtCount)||e.acceptedAtCount<0)throw Error('Invalid fact registration');
    }
    if(e.kind==='inference')validateInference(e,ledger);
    if(e.kind==='llm'){const values=Object.fromEntries(e.factIds.map(id=>{const f=ledger.entries().find(f=>f.id===id);return [f.predicate,f.value];}));
      const expectedSource=values.acquisition==='bridge'?`llm:${values.actor}`:values.acquisition==='manual'?'local:llm-registration':`local:llm-transcript:${values.origin||'file'}`;
      if(values.received!==true||typeof values.actor!=='string'||!['bridge','manual','transcript'].includes(values.acquisition)||e.detail.acquisition!==values.acquisition||e.source!==expectedSource||!['request','response','tool-request','tool-result'].includes(values.speech_act)||typeof values.text!=='string')throw Error('Invalid interaction receipt');
    }
    if(e.legacyCompletion!==undefined&&e.legacyCompletion!==true)throw Error('Invalid legacy completion marker');
    if((e.kind==='message'||e.detail.tokens!==undefined)&&(!Array.isArray(e.detail.tokens)||e.detail.tokens.length>128||
      !e.detail.tokens.every(t=>t&&typeof t.word==='string'&&t.word.length<=1000&&integer(t.id)&&t.id>=0&&t.id<88&&['lexicon','orthographic','hash'].includes(t.via))||
      !Array.isArray(e.detail.contentGlyphs)||e.detail.contentGlyphs.length>128||
      !e.detail.contentGlyphs.every(id=>integer(id)&&id>=0&&id<88)||
      (e.kind==='message'&&(typeof e.detail.text!=='string'||e.detail.text.length>1000))))throw Error('Invalid text encounter');
    if(e.detail.contentGlyphs!==undefined&&(!Array.isArray(e.detail.contentGlyphs)||e.detail.contentGlyphs.length>128||
      !e.detail.contentGlyphs.every(id=>integer(id)&&id>=0&&id<88)))throw Error('Invalid content glyphs');
    if(e.detail.semanticPolicy!==undefined&&(![LANGUAGES.policy,LANGUAGES.previousPolicy].includes(e.detail.semanticPolicy)||!LANGUAGES.codes.includes(e.detail.language)))throw Error('Invalid lexical provenance');
    if(e.kind==='quake'&&(!integer(e.detail.sourceUpdatedAt)||!Number.isFinite(e.detail.depth)||
      !(e.detail.magnitude===null||Number.isFinite(e.detail.magnitude))))throw Error('Invalid earthquake encounter');
    if(e.kind==='weather'&&![e.detail.temperature_c,e.detail.wind_kmh,e.detail.precipitation_mm].every(Number.isFinite))throw Error('Invalid weather encounter');
  }
  function interactionFrame(packet) {
    if(!packet||typeof packet.actor!=='string'||!packet.actor.trim()||packet.actor.length>128||
      typeof packet.id!=='string'||!/^[a-zA-Z0-9:_-]{1,128}$/.test(packet.id)||
      !['request','response','tool-request','tool-result'].includes(packet.type)||
      typeof packet.text!=='string'||!packet.text.trim()||packet.text.length>1000||!integer(packet.observedAt)||
      (packet.via!==undefined&&!['bridge','manual','transcript'].includes(packet.via))||
      (packet.origin!==undefined&&(typeof packet.origin!=='string'||packet.origin.length>256))||
      (packet.correlationId!==undefined&&(typeof packet.correlationId!=='string'||packet.correlationId.length>256)))throw Error('Invalid LLM interaction');
    const parsed=VOICE.tokenize(packet.text),point=parsed.ids.length?parsed.ids:ids(['AI','speak']),sensory=[0,0];
    for(const g of point){sensory[0]+=Math.cos(g*2.3999632297)/point.length;sensory[1]+=Math.sin(g*2.3999632297)/point.length;}
    const via=packet.via??'bridge',source=via==='bridge'?`llm:${packet.actor}`:via==='manual'?'local:llm-registration':`local:llm-transcript:${packet.origin??'file'}`;
    return {kind:'llm',key:`${fingerprint(packet.actor)}:${packet.id}`,source,observedAt:packet.observedAt,
      title:`${packet.actor} · ${packet.type}: ${packet.text}`,values:{received:true,actor:packet.actor,message_id:packet.id,speech_act:packet.type,text:packet.text,correlation_id:packet.correlationId??'',acquisition:via,origin:packet.origin??''},
      sensory,projection:'Semantic projection of an observed interaction; text remains attributed to its actor',
      glyphs:ids(['AI','speak','now']).concat(parsed.ids),detail:{tokens:parsed.tokens,contentGlyphs:parsed.ids,language:parsed.language,semanticPolicy:parsed.policy,acquisition:via,origin:packet.origin??null}};
  }
  class WorldLab {
    constructor(seed=17) {
      this.model=new BODY.Amos(seed,1,4);this.ledger=new LALO.FactLedger({capacity:CAPACITY});
      this.voice=new VOICE.GlyphVoice(seed,BODY.H);this.queue=[];this.history=[];this.pending=null;
      this.count=0;this.historyOmitted=0;this.serial=0;this.attention='message';
      this.station={latitude:52.52,longitude:13.405};this.lastWeather=null;
      this.relations=new RELATIONS.RelationField();this.mind=new COGNITION.FactMind(BODY.H);this.sonar=new SONAR.SomaticSonar();this.cognitionBirth=0;
      this.transitions=new TRANSITIONS.TransitionMind(BODY.H);this.transitionBirth=0;
      this.chapter={number:1,fromCount:0,at:null,archive:null,closedReceipts:0};
      this.sourceMemory=[];
    }
    _stage(at) {
      if(!integer(at)||at<latestReceipt(this.ledger))throw Error('Receipt time precedes the accepted world');
      return decode(encode(this.ledger));
    }
    _commit(ledger,events) {
      if(this.queue.length+events.length>MAX_QUEUE)throw Error('Encounter queue full (128); let the pending world reach AMOS first');
      for(const event of events){
        eventValid(event,ledger);event.acceptedAtCount=this.count;
        const id=`amos:registered:${event.id}`;
        ledger.add({id,subject:'agent:amos:registrations',predicate:'registered_event',value:JSON.stringify(COGNITION.registration(event,ledger)),
          source:'amos:registration/v1',validFrom:event.receivedAt,validTo:event.receivedAt+1,recordedAt:event.receivedAt,supersedes:null});
        event.registrationReceipt=id;
      }
      if(ledger.size+ENCOUNTER_RECEIPTS*(this.queue.length+events.length)>CAPACITY)
        throw Error('Journal budget must reserve nine completion receipts for every pending encounter');
      for(const event of events)eventValid(event,ledger);
      const encoded=encode(ledger);
      if(bytes(encoded)+RESERVE_BYTES*(this.queue.length+events.length)>MAX_JOURNAL)throw Error('Journal byte budget must reserve pending encounter receipts');
      this.ledger=ledger;this.queue.push(...events);return events.length;
    }
    // Optional worlds enter through the ordinary fact contract. All projections
    // travel with the receipt, so a saved life can continue without that module.
    ingestWorld(frames,receivedAt,receipts=[]) {
      if(!Array.isArray(frames)||!frames.length||frames.length>32)throw Error('A world batch needs 1–32 encounters');
      const ledger=this._stage(receivedAt),events=[];for(const receipt of receipts)ledger.add(receipt);
      for(const frame of frames){
        if(!frame||!worldKind(frame.kind)||['quake','weather','message'].includes(frame.kind)||
          typeof frame.key!=='string'||!/^[a-zA-Z0-9:_-]{1,160}$/.test(frame.key)||
          typeof frame.source!=='string'||!frame.source||!integer(frame.observedAt)||
          !frame.values||typeof frame.values!=='object'||Array.isArray(frame.values)||
          !Object.keys(frame.values).length||Object.keys(frame.values).length>16||
          !Object.keys(frame.values).every(p=>/^[a-zA-Z][a-zA-Z0-9_]{0,63}$/.test(p)))throw Error('Invalid world receipt');
        // These sources carry the heart's own structured receipts. An external
        // assertion must not be dispatched as an internal evaluation or memory.
        if(frame.source.startsWith('amos:')&&!(frame.kind==='inference'&&frame.source==='amos:inference/v1'))
          throw Error('The amos: source namespace is reserved for internal receipts');
        const subject=`world:${frame.kind}:${frame.key}`;
        const current=currentVersion(ledger,subject,frame.source),remembered=!current.length&&archivedVersion(this,subject,frame.source);
        if(unchanged(current,frame.values,frame.observedAt,frame.observedAt+1)||remembered&&remembered.digest===versionDigest(frame.values,frame.observedAt,frame.observedAt+1))continue;
        const id=`${subject}:r${ledger.size+1}`;
        const all=ledger.entries(),previous=all.filter(f=>f.subject===subject&&f.source===frame.source),replaced=new Set(all.map(f=>f.supersedes)),factIds=[];
        for(const [predicate,value] of Object.entries(frame.values)){
          const old=previous.findLast(f=>f.predicate===predicate&&!replaced.has(f.id));
          const factId=`${id}:${predicate}`;ledger.add({id:factId,subject,predicate,value,source:frame.source,validFrom:frame.observedAt,
            validTo:frame.observedAt+1,recordedAt:receivedAt,supersedes:old?.id??null});factIds.push(factId);
        }
        events.push({id,subject,kind:frame.kind,title:frame.title,source:frame.source,observedAt:frame.observedAt,receivedAt,
          factIds,sensory:clone(frame.sensory),projection:frame.projection,glyphs:clone(frame.glyphs),detail:{...clone(frame.detail??{}),...(remembered?{archivedVersion:clone(remembered)}:{})}});
      }
      return this._commit(ledger,events);
    }
    ingestQuakes(feed,receivedAt) {
      this._stage(receivedAt);
      let skippedUnchanged=0,skippedStale=0,accepted=feed;
      if(this.sourceMemory.some(m=>m.subject.startsWith('usgs:'))){
        // Validate the entire source poll before consulting archived fingerprints.
        const validated=LALO.ingestUSGS(new LALO.FactLedger({capacity:CAPACITY}),feed,{receivedAt,capacity:CAPACITY,maxBytes:MAX_JOURNAL,maxEvents:64}).ledger;
        const features=feed.features.filter(feature=>{
          const subject=`usgs:${feature.id}`,source=`https://earthquake.usgs.gov/earthquakes/eventpage/${feature.id}`,m=archivedVersion(this,subject,source);
          if(!m||currentVersion(this.ledger,subject,source).length)return true;
          if(feature.properties.updated<m.revision){skippedStale++;return false;}
          if(feature.properties.updated===m.revision){
            const rows=validated.entries().filter(f=>f.subject===subject),values=Object.fromEntries(rows.map(f=>[f.predicate,f.value]));
            if(m.digest!==versionDigest(values,rows[0].validFrom,rows[0].validTo))throw Error('USGS changed an event without changing its source version');
            skippedUnchanged++;return false;
          }return true;
        });accepted={...feed,features};
      }
      const old=new Set(this.ledger.entries().map(f=>f.id));
      const {ledger,summary}=LALO.ingestUSGS(this.ledger,accepted,{receivedAt,capacity:CAPACITY,maxBytes:MAX_JOURNAL,maxEvents:64});
      const events=[];
      for(const feature of [...feed.features].sort((a,b)=>a.properties.time-b.properties.time||a.id.localeCompare(b.id))) {
        const p=feature.properties,subject=`usgs:${feature.id}`,id=`${subject}:${p.updated}`;
        if(old.has(`${id}:magnitude`)||!ledger.entries().some(f=>f.id===`${id}:magnitude`))continue;
        const facts=ledger.entries().filter(f=>f.subject===subject&&f.recordedAt===receivedAt&&f.id.startsWith(id+':'));
        const remembered=archivedVersion(this,subject,facts[0].source),revised=!!facts[0].supersedes||!!remembered;
        if(remembered&&!facts[0].supersedes){summary.added--;summary.revised++;}
        const [longitude,latitude,depth]=feature.geometry.coordinates;
        events.push({id,subject,kind:'quake',title:`M ${p.mag===null?'?':p.mag.toFixed(1)} · ${p.place||feature.id}`,
          observedAt:p.time,receivedAt,source:facts[0].source,factIds:facts.map(f=>f.id),
          sensory:[Math.tanh((p.mag??0)/6),Math.tanh(depth/100)],
          projection:'x = tanh(magnitude / 6); y = tanh(depth_km / 100)',
          glyphs:ids(revised?['earth','stone','change','before','now']:['earth','stone','now']),
          detail:{magnitude:p.mag,depth,longitude,latitude,sourceUpdatedAt:p.updated,revised,...(remembered?{archivedVersion:clone(remembered)}:{})}});
      }
      const added=this._commit(ledger,events);return {...summary,events:feed.features.length,unchanged:summary.unchanged+skippedUnchanged,stale:summary.stale+skippedStale,encounters:added};
    }
    ingestWeather(data,receivedAt,source) {
      const ledger=this._stage(receivedAt),c=data?.current;
      if(!c||!integer(c.time)||!Number.isFinite(c.temperature_2m)||!Number.isFinite(c.wind_speed_10m)||
        !Number.isFinite(c.precipitation)||![0,1].includes(c.is_day)||
        !Number.isFinite(data.latitude)||Math.abs(data.latitude)>90||!Number.isFinite(data.longitude)||Math.abs(data.longitude)>180||
        c.wind_speed_10m<0||c.precipitation<0||!integer(c.interval)||c.interval<1||c.interval>86400||
        data.current_units?.temperature_2m!=='°C'||data.current_units?.wind_speed_10m!=='km/h'||
        data.current_units?.precipitation!=='mm'||typeof source!=='string'||!source.startsWith('https://api.open-meteo.com/v1/forecast?'))throw Error('Invalid Open-Meteo current model sample or units');
      const observedAt=c.time*1000,validTo=observedAt+c.interval*1000;
      if(!integer(observedAt)||!integer(validTo))throw Error('Invalid weather time');
      const subject=`weather:${data.latitude.toFixed(4)}:${data.longitude.toFixed(4)}:${c.time}`;
      const values={temperature_c:c.temperature_2m,wind_kmh:c.wind_speed_10m,precipitation_mm:c.precipitation,is_day:c.is_day,latitude:data.latitude,longitude:data.longitude};
      const current=currentVersion(ledger,subject,source),remembered=!current.length&&archivedVersion(this,subject,source);
      if(unchanged(current,values,observedAt,validTo)||remembered&&remembered.digest===versionDigest(values,observedAt,validTo))return 0;
      const id=`${subject}:r${ledger.size+1}`,all=ledger.entries();
      const replaced=new Set(all.map(f=>f.supersedes)),factIds=[];
      for(const [predicate,value] of Object.entries(values)) {
        const previous=all.findLast(f=>f.subject===subject&&f.source===source&&f.predicate===predicate&&!replaced.has(f.id));
        const factId=`${id}:${predicate}`;ledger.add({id:factId,subject,predicate,value,source,
          validFrom:observedAt,validTo,recordedAt:receivedAt,supersedes:previous?.id??null});factIds.push(factId);
      }
      const glyphs=ids(['sky',c.temperature_2m<12?'cold':'light',c.precipitation>0?'water':c.is_day?'light':'dark','now']);
      const e={id,subject,kind:'weather',title:`${c.temperature_2m.toFixed(1)}°C · wind ${c.wind_speed_10m.toFixed(1)} km/h`,observedAt,receivedAt,source,factIds,
        sensory:[Math.tanh(c.temperature_2m/30),-Math.tanh(c.wind_speed_10m/40)],
        projection:'x = tanh(temperature_c / 30); y = −tanh(wind_kmh / 40)',glyphs,
        detail:{...values,interval:c.interval,kind:'Open-Meteo model sample',...(remembered?{archivedVersion:clone(remembered)}:{})}};
      const added=this._commit(ledger,[e]);this.lastWeather=e;return added;
    }
    ingestText(text,receivedAt) {
      if(typeof text!=='string'||!text.trim()||text.length>1000)throw Error('Write between 1 and 1000 characters');
      const ledger=this._stage(receivedAt),serial=this.serial+1;
      const subject=`message:${serial}`,id=`${subject}:${receivedAt}`;
      const parsed=VOICE.tokenize(text),glyphs=ids(['you','write','now']).concat(parsed.ids);
      const point=parsed.ids.length?parsed.ids:ids(['you','write']);
      const sensory=[0,0];let total=0;
      point.forEach((g,i)=>{const weight=1+i/Math.max(1,point.length);const angle=g*2.3999632297;
        sensory[0]+=weight*Math.cos(angle);sensory[1]+=weight*Math.sin(angle);total+=weight;});
      sensory[0]/=total;sensory[1]/=total;
      const values={arrived:true,text,projected_glyphs:parsed.ids.map(g=>VOICE.names[g]).join(' ')};
      const factIds=[];
      for(const [predicate,value] of Object.entries(values)){
        const factId=`${id}:${predicate}`;ledger.add({id:factId,subject,predicate,value,source:'local:human',validFrom:receivedAt,validTo:receivedAt+1,recordedAt:receivedAt,supersedes:null});factIds.push(factId);
      }
      const e={id,subject,kind:'message',title:text,observedAt:receivedAt,receivedAt,source:'local:human',factIds,
        sensory,projection:'Order-weighted mean of the 88 glyph basis vectors: (cos(g·2.39996), sin(g·2.39996))',glyphs,
        detail:{text,tokens:parsed.tokens,contentGlyphs:parsed.ids,language:parsed.language,semanticPolicy:parsed.policy}};
      this._commit(ledger,[e]);this.serial=serial;return e;
    }
    ingestInteraction(packet,receivedAt) {
      const frame=interactionFrame(packet);return this.ingestWorld([frame],receivedAt);
    }
    readingQuery(event) {
      if(event.kind==='inference'){
        const query={...event.detail.derivation.query};
        if(event.detail.derivation.question?.knowledge==='current'||!event.detail.derivation.question){delete query.knownAt;delete query.knownThrough;}
        return query;
      }
      const facts=event.factIds.map(id=>this.ledger.entries().find(f=>f.id===id));
      const fact=facts.find(f=>f.predicate==='magnitude'&&(f.value===null||typeof f.value==='number'))??facts.find(f=>typeof f.value==='boolean');
      return fact?{subject:fact.subject,predicate:fact.predicate,validAt:event.observedAt,rule:fact.predicate==='magnitude'?LALO.MAGNITUDE_RULE:LALO.RULE}:null;
    }
    deriveReading(query,receivedAt) {
      const ledger=this._stage(receivedAt),{knownThrough,...input}=query,boundary=knownThrough??ledger.size,known=prefixLedger(ledger,boundary),args={...input,knownAt:query.knownAt??receivedAt,offset:0,limit:64};
      if(!integer(args.knownAt)||args.knownAt>receivedAt)throw Error('Inference cutoff exceeds its receipt time');
      if(this.chapter.number>1&&args.knownAt<this.chapter.at)throw Error('Earlier knowledge belongs to the archived chapter');
      const toolHost=makeHost(known,this.chapter),first=toolHost.call('lalo_reading',args);
      if(!first.ok)throw Error(first.error.message);
      const measured=inference(args,known),all=ledger.entries(),premises=measured.premises.map(id=>all.findIndex(f=>f.id===id));
      if(premises.length>128)throw Error('A registered inference has at most 128 premises');
      const q={subject:args.subject,predicate:args.predicate,rule:args.rule,validAt:args.validAt};
      if(args.rule===LALO.RULE)q.expected=args.expected??true;else q.threshold=args.threshold??3;
      const question={...q,knowledge:query.knownAt===undefined&&knownThrough===undefined?'current':{at:args.knownAt,through:knownThrough??null}},key=`reading:${fingerprint(JSON.stringify(question))}`,old=this.queue.concat(this.history.map(t=>t.event)).find(e=>e.subject===`world:inference:${key}`);
      if(old&&old.detail.derivation&&JSON.stringify({...old.detail.derivation.query,knownAt:undefined,knownThrough:undefined})!==JSON.stringify(q))throw Error('Inference identity collision');
      const parsed=VOICE.tokenize(`${q.subject} ${q.predicate}`),state=measured.state;
      const states={supported:'agree',contradicted:'not',contested:'conflict',unsettled:'seek'};
      const values={state,rule:q.rule,query_subject:q.subject,query_predicate:q.predicate,premise_indices:JSON.stringify(premises)};
      if(scope(this.chapter))values.knowledge_scope=`chapter:${this.chapter.number}`;
      if(q.expected!==undefined)values.expected=q.expected;if(q.threshold!==undefined)values.threshold=q.threshold;
      const evaluation={id:`agent:amos:evaluation:${ledger.size+1}`,subject:`world:inference:${key}`,predicate:'named_evaluation',
        value:JSON.stringify({policy:'amos/named-evaluation-v1',query:{...q,knownAt:args.knownAt,knownThrough:boundary},premises,state,...(scope(this.chapter)?{scope:scope(this.chapter)}:{})}),
        source:'amos:evaluation/v1',validFrom:receivedAt,validTo:receivedAt+1,recordedAt:receivedAt,supersedes:null};
      return this.ingestWorld([{kind:'inference',key,source:'amos:inference/v1',observedAt:q.validAt,
        title:`${q.predicate}: ${state}${scope(this.chapter)?' · chapter '+this.chapter.number:''}`,values,
        sensory:[(measured.supporting.length-measured.opposing.length)/Math.max(1,premises.length),(measured.unknown?.length??0)/Math.max(1,premises.length)],
        projection:'Named LALO reading: signed support fraction and explicit unknown fraction',
        glyphs:ids(['think','know',states[state]]).concat(parsed.ids.slice(0,125)),
        detail:{derivation:{query:{...q,knownAt:args.knownAt,knownThrough:boundary},question,premises,evaluationReceipt:evaluation.id},contentGlyphs:parsed.ids}}],receivedAt,[evaluation]);
    }
    previewSelection(preferredId) {
      return this.mind.rank(this.queue,this.voice,this.ledger,this.attention,this.count,preferredId,this.sonar.coefficients());
    }
    nextIndex(preferredId) {return this.previewSelection(preferredId)?.selected.index??0;}
    encounter(at,preferredId) {
      if(!this.queue.length)return null;
      const selection=this.previewSelection(preferredId),index=selection.selected.index,event=this.queue[index];
      const receiptAt=Math.max(at,latestReceipt(this.ledger)),ledger=this._stage(receiptAt),knownAt=receiptAt;
      const model=this.model.clone(),s=model.subject,voice=VOICE.GlyphVoice.load(clone(this.voice.dump()));
      const mind=COGNITION.FactMind.load(this.mind.dump(),BODY.H),sonar=SONAR.SomaticSonar.load(this.sonar.dump());
      const transitionMind=TRANSITIONS.TransitionMind.load(this.transitions.dump(),BODY.H),investigation=transitionMind.plan(ledger,knownAt),transitionRecords=[];
      selection.investigation=investigation?clone(investigation):null;
      const sourceIndices=event.factIds.map(id=>ledger.entries().findIndex(f=>f.id===id));
      const relationField=RELATIONS.RelationField.load(this.relations.dump(),ledger);
      const associations=COGNITION.link(event,this.history,voice,ledger),relations=relationField.observe(event,ledger),content=event.detail.contentGlyphs??event.glyphs,resonance=voice.resonance(content);
      if(!Number.isFinite(resonance)||resonance<0||resonance>1)throw Error('Invalid prior resonance');
      const contextual=relations.sensory.map((v,i)=>bounded(v+.12*associations.sensory[i],-1,1));
      const priorGap=this.pending?magnitude(contextual.map((v,k)=>v-this.pending.predicted[k])):0;
      const sonarBefore=sonar.act.slice(),inhaled=sonar.inhale(event.glyphs,{surprise:priorGap,resonance:(resonance+associations.strength)/2,unmatched:associations.unmatched.length/Math.max(1,associations.incoming.length),
        familiarity:relations.familiarity,revision:event.detail.archivedVersion||event.factIds.some(id=>ledger.entries().find(f=>f.id===id).supersedes!==null)?1:0,selfError:mind.lastError});
      const controls=sonar.coefficients(),resonanceGain=.94+.12*resonance;
      const sensory=contextual.map(v=>bounded(v*resonanceGain*controls.perception,-1,1));
      const before=s.h.slice(),oldLoad=model.world.load;
      const trajectory=[{name:'before',h:before.slice()}];
      const errorBefore=this.pending?magnitude(sensory.map((v,k)=>v-this.pending.predicted[k])):0;
      const load=bounded(.85*oldLoad+.15*errorBefore+.005*Math.abs(this.pending?.action||0),0,1);
      const o=[...sensory,load],tick=this.count+1;
      let completed=null;
      if(this.pending) {
        const p=this.pending,delta=o.map((v,k)=>v-p.observation[k]);
        s.regress(p.features,delta,controls.plasticity);s.body.learn(p.observation,o);s.glyph.learn(p.sequence,p.action,delta);
        completed={tick,observation:p.observation,next:o,action:p.action,predicted:p.predicted,influence:p.influence,
          features:p.features,sequence:p.sequence,recognition:p.recognition};
        model.memory.push(completed);if(model.memory.length>128)model.memory.shift();
      }
      const worldTransition=transitionMind.forecast('world',before,o,s.previous_action,associations.strength);
      s.glyph.learning=1;s.observe(o);
      const worldAfter=s.h.slice(),action=s.action(0,controls.exploration),toolHost=makeHost(ledger,this.chapter);
      trajectory.push({name:'world',h:worldAfter.slice()});
      transitionRecords.push(transitionMind.learn(worldTransition,worldAfter,[...new Set(sourceIndices.concat(associations.evidence.map(e=>e[1])))]));
      const scope=mind.readScope(action),selfFact=scope==='self'?ledger.entries().find(f=>f.id===mind.lastSelf):null;
      const tool=investigation?.tool??(action<0?'lalo_history':action>0?'lalo_lineage':'lalo_facts');
      const args=investigation?.arguments??(selfFact?{subject:selfFact.subject,knownAt,limit:32}:
        action<0?{subject:event.subject,knownAt,limit:32}:action>0?{id:event.factIds[0],knownAt,limit:32}
        :{subject:event.subject,validAt:event.observedAt,knownAt,limit:32});
      const selfForecast=mind.forecast(worldAfter,action,load,resonance,relations.familiarity,errorBefore);
      const toolResult=toolHost.call(tool,args);
      if(!toolResult.ok)throw Error(toolResult.error.message);
      const reading=PERCEPTION.read(toolResult,ledger,tool,args,ledger.size);
      const readObservation=[...o.slice(0,2).map((v,i)=>bounded(v+.15*reading.sensory[i]*controls.recall,-1,1)),load];
      const readTransition=transitionMind.forecast('read',worldAfter,readObservation,action,reading.premises.length/32);
      s.previous_action=action;const readTwin=copySubject(s);readTwin.observe(o);s.observe(readObservation);
      const readAfter=s.h.slice(),passes=[],evidenceGlyphs=tool==='lalo_history'?ids(['before','remember']):tool==='lalo_lineage'?ids(['cause','change']):ids(['see','now']);
      trajectory.push({name:'read',h:readAfter.slice()});
      transitionRecords.push(transitionMind.learn(readTransition,readAfter,reading.premises,{observation:o,after:readTwin.h,steps:1}));
      const returnTransition=transitionMind.forecast('return',readAfter,readObservation,action,sonar.gate()),returnTwin=copySubject(s);
      let finalObservation=readObservation.slice(),previousGate=sonar.gate();
      for(let depth=1;depth<=4;depth++){
        const draftVoice=VOICE.GlyphVoice.load(clone(voice.dump())),mix=s.glyph.sequence.slice(-8),c=sonar.coefficients();
        draftVoice.ingest(event.glyphs,s.h,mix,c.plasticity);draftVoice.ingest(evidenceGlyphs,s.h,mix,c.plasticity);draftVoice.ingest(reading.glyphs,s.h,mix,c.plasticity);
        const draft=draftVoice.express(s.h,mix,errorBefore,c.temperature),meta=sonar.reinhale(draft.ids,draftVoice.symbols);
        const hBefore=s.h.slice();finalObservation=[...readObservation.slice(0,2).map((v,i)=>bounded(v+.1*meta.projection[i],-1,1)),load];
        s.observe(finalObservation);
        returnTwin.observe(readObservation);trajectory.push({name:'return-'+depth,h:s.h.slice()});
        passes.push({depth,draft:draft.ids,representations:{base:voice.symbols.length,born:draft.born?.pair??null},after:meta.after,gate:meta.gate,observation:finalObservation.slice(),shift:magnitude(s.h.map((v,i)=>v-hBefore[i]))});
        if(Math.abs(meta.gate-previousGate)<.005)break;previousGate=meta.gate;
      }
      transitionRecords.push(transitionMind.learn(returnTransition,s.h,reading.premises,{observation:readObservation,after:returnTwin.h,steps:passes.length}));
      const selfObserved=COGNITION.measure(worldAfter,s.h,o,finalObservation),selfError=mind.learn(selfForecast,selfObserved,event,errorBefore);
      sonar.settle(inhaled);
      const finalControls=sonar.coefficients(),mixture=s.glyph.sequence.slice(-8),recognition=s.glyph.predict(0)[1];
      voice.ingest(event.glyphs,s.h,mixture,finalControls.plasticity);voice.ingest(evidenceGlyphs,s.h,mixture,finalControls.plasticity);
      voice.ingest(reading.glyphs,s.h,mixture,finalControls.plasticity);
      const utterance=voice.express(s.h,mixture,errorBefore,finalControls.temperature);
      const changed=s.h.map((v,i)=>({i,before:before[i],after:v,delta:v-before[i]})).sort((a,b)=>Math.abs(b.delta)-Math.abs(a.delta));
      const expected=s.predict(action),features=s.features(action),influence=s.influence(),predictedRecognition=s.glyph.predict(action)[1];
      const pending={observation:finalObservation.slice(),action,predicted:expected,features,sequence:s.glyph.sequence.slice(),recognition:predictedRecognition,influence};
      const attention=action<0?'quake':action>0?'weather':'message';
      model.world.pos=finalObservation.slice(0,2);model.world.load=load;model.world.tick=tick;
      const encounterSubject=`agent:amos:encounter:${tick}`,all=ledger.entries(),rawPremises=event.factIds.map(id=>all.findIndex(f=>f.id===id));
      const selfReflection={policy:'amos/self-sonar-v1',forecast:selfForecast,observed:selfObserved,error:selfError,
        returnPolicy:'amos/glyph-return-v1',
        before:sonarBefore,after:sonar.act.slice(),controls,passes,scope:investigation?.scope??(selfFact?'self':'world'),registrationPremise:all.findIndex(f=>f.id===event.registrationReceipt),sourcePremises:rawPremises,associationPremise:all.length+4};
      const additions=[{id:`agent:amos:attention:${tick}`,subject:encounterSubject,predicate:'attention_subject',value:event.subject,
        source:'amos:encounter',validFrom:receiptAt,validTo:receiptAt+1,recordedAt:receiptAt,supersedes:null},
      {id:`agent:amos:relations:${tick}`,subject:encounterSubject,predicate:'encounter_relations',value:JSON.stringify(relations),
        source:'amos:relations/v1',validFrom:receiptAt,validTo:receiptAt+1,recordedAt:receiptAt,supersedes:null},
      {id:`agent:amos:read:${tick}`,subject:encounterSubject,predicate:'tool_reading',value:JSON.stringify(reading),
        source:'amos:tool-read/v1',validFrom:receiptAt,validTo:receiptAt+1,recordedAt:receiptAt,supersedes:null},
      {id:`agent:amos:selection:${tick}`,subject:encounterSubject,predicate:'fact_selection',value:JSON.stringify(selection),
        source:'amos:attention/v1',validFrom:receiptAt,validTo:receiptAt+1,recordedAt:receiptAt,supersedes:null},
      {id:`agent:amos:links:${tick}`,subject:encounterSubject,predicate:'encounter_links',value:JSON.stringify(associations),
        source:'amos:links/v1',validFrom:receiptAt,validTo:receiptAt+1,recordedAt:receiptAt,supersedes:null},
      {id:`agent:amos:self:${tick}`,subject:encounterSubject,predicate:'self_reflection',value:JSON.stringify(selfReflection),
        source:'amos:self/v1',validFrom:receiptAt,validTo:receiptAt+1,recordedAt:receiptAt,supersedes:null}];
      for(const record of transitionRecords)additions.push({id:`agent:amos:transition:${tick}:${record.phase}`,subject:encounterSubject,predicate:`transition_${record.phase}`,
        value:JSON.stringify(record),source:'amos:transition/v1',validFrom:receiptAt,validTo:receiptAt+1,recordedAt:receiptAt,supersedes:null});
      let transitionReceipts=additions.slice(6).map(f=>f.id);
      let completedLedger=ledger,relationReceipt=additions[1].id,readReceipt=additions[2].id,selectionReceipt=additions[3].id,linkReceipt=additions[4].id,selfReceipt=additions[5].id,receiptState='journal';
      try{const candidate=decode(encode(ledger));for(const f of additions)candidate.add(f);encode(candidate);completedLedger=candidate;mind.lastSelf=selfReceipt;}
      catch(error){
        const budget=/capacity|byte budget/.test(error.message);
        if(!event.legacyCompletion||!budget)throw error;
        relationReceipt=null;readReceipt=null;selectionReceipt=null;linkReceipt=null;selfReceipt=null;receiptState='legacy-full-journal';
        transitionReceipts=[null,null,null];
      }
      if(receiptState==='journal')transitionMind.remember(transitionRecords,transitionReceipts,tick,completedLedger,investigation);
      else{transitionMind.last=[];if(investigation)transitionMind.lastProbe=transitionMind.heads.world.updates;}
      const trace={tick,policy:'amos/reflective-facts-v2',encounterAt:receiptAt,event:clone(event),before,worldAfter,readAfter,after:s.h.slice(),changed:changed.slice(0,6),mixture,
        relations,relationReceipt,readReceipt,selectionReceipt,linkReceipt,selfReceipt,receiptState,reading,associations,readObservation,finalObservation,resonanceGain,
        selection,selfReflection,transitions:transitionRecords,transitionReceipts,trajectory,investigation,prototypeCount:s.glyph.prototypes.length,symbolCount:voice.symbols.length,
        load,surprise:errorBefore,resonance,recognition:clone(recognition),action,nextAttention:attention,
        tool:{name:tool,arguments:args,result:toolResult},utterance,
        previousForecast:completed?.predicted??null,observed:o,prediction:expected,resolvedFromTick:completed?tick-1:null};
      this.queue.splice(index,1);this.ledger=completedLedger;this.relations=relationField;this.model=model;this.voice=voice;this.mind=mind;this.sonar=sonar;
      this.transitions=transitionMind;
      this.pending=pending;this.attention=attention;this.count=tick;this.history.push(trace);
      if(this.history.length>MAX_HISTORY){this.history.shift();this.historyOmitted++;}
      return trace;
    }
    continueWithExperience(at) {
      if(!integer(at)||at<latestReceipt(this.ledger))throw Error('Chapter time precedes its recorded history');
      if(this.queue.length)throw Error('Encounter the waiting facts before closing this chapter');
      if(this.count===this.chapter.fromCount)throw Error('This chapter has no acquired encounters to carry');
      const archive=this.dump(),next=WorldLab.load(archive),chapter={number:this.chapter.number+1,fromCount:this.count,at,
        archive:fingerprint(archive),closedReceipts:this.chapter.closedReceipts+this.ledger.size};
      const ledger=new LALO.FactLedger({capacity:CAPACITY});
      ledger.add({id:`agent:amos:chapter:${chapter.number}`,subject:'agent:amos',predicate:'experience_boundary',value:JSON.stringify(chapter),
        source:'amos:experience/v1',validFrom:at,validTo:null,recordedAt:at,supersedes:null});
      const self=this.ledger.entries().find(f=>f.id===this.mind.lastSelf);
      if(self){const previous=JSON.parse(self.value),id=`agent:amos:chapter:${chapter.number}:self`;
        ledger.add({id,subject:'agent:amos:experience',predicate:'self_memory',value:JSON.stringify({policy:'amos/carried-self-v1',fromFact:self.id,
          archive:chapter.archive,error:previous.error,observed:previous.observed}),source:'amos:experience/v1',validFrom:at,validTo:null,recordedAt:at,supersedes:null});
        next.mind.lastSelf=id;
      }
      next.ledger=ledger;next.chapter=chapter;next.history=[];next.historyOmitted=this.count;next.lastWeather=null;
      next.sourceMemory=sourceMemories(this,chapter.archive);
      next.relations.recent=[];next.relations.recentBirth=next.relations.seen;
      // Targets in the sealed journal stay there; forecasts, weights and errors travel.
      next.transitions.last=[];
      return {archive,life:WorldLab.load(next.dump())};
    }
    dump() {
      const text=JSON.stringify({format:'amos-2/world',version:7,semanticPolicy:LANGUAGES.policy,chapter:this.chapter,sourceMemory:this.sourceMemory,model:this.model.dumps(),journal:encode(this.ledger),voice:this.voice.dump(),
        queue:this.queue,history:this.history,pending:this.pending,count:this.count,serial:this.serial,historyOmitted:this.historyOmitted,
        attention:this.attention,station:this.station,lastWeather:this.lastWeather,relations:this.relations.dump(),mind:this.mind.dump(),sonar:this.sonar.dump(),cognitionBirth:this.cognitionBirth,
        transitions:this.transitions.dump(),transitionBirth:this.transitionBirth,reservedReceiptSlots:ENCOUNTER_RECEIPTS});
      if(bytes(text)>MAX_SNAPSHOT)throw Error('Complete life exceeds the 24 MB snapshot budget');return text;
    }
    static load(text) {
      if(typeof text!=='string'||bytes(text)>MAX_SNAPSHOT)throw Error('Snapshot exceeds 24 MB');
      const d=JSON.parse(text);
      if(d?.format!=='amos-2/world'||![1,2,3,4,5,6,7].includes(d.version))throw Error('Unsupported AMOS 2 life');
      if(d.version>=5&&d.semanticPolicy!==(d.version>=7?LANGUAGES.policy:LANGUAGES.previousPolicy))throw Error('Unsupported semantic membrane');
      if(d.version>=2&&(!d.relations||![2,3,5,6,9].includes(d.reservedReceiptSlots)))throw Error('Missing acquired relation organ or completion reserve');
      if(d.version>=4&&![5,6,9].includes(d.reservedReceiptSlots))throw Error('Missing tool-read completion reserve');
      if(d.version>=6&&d.reservedReceiptSlots!==9)throw Error('Missing transition completion reserve');
      const width=JSON.parse(d.model)?.amos?.subject?.h?.length;
      if(d.version>=4&&width!==BODY.H)throw Error('Invalid current neural width');
      if(d.voice?.neural?.[0]?.length!==width)throw Error('Voice and body neural widths disagree');
      const life=new WorldLab();life.model=growModel(d.model);life.ledger=decode(d.journal);
      if(d.version===7){
        const c=d.chapter;
        if(!c||!integer(c.number)||c.number<1||!integer(c.fromCount)||c.fromCount<0||c.fromCount>d.count||c.fromCount>d.historyOmitted||
          !integer(c.closedReceipts)||c.closedReceipts<0||
          (c.number===1?(c.fromCount!==0||c.at!==null||c.archive!==null||c.closedReceipts!==0):
            (!integer(c.at)||!c.fromCount||typeof c.archive!=='string'||!/^[0-9a-f]{1,16}$/.test(c.archive)||c.closedReceipts<c.number-1||
              !life.ledger.entries().some(f=>f.id===`agent:amos:chapter:${c.number}`&&f.source==='amos:experience/v1'&&f.predicate==='experience_boundary'&&f.recordedAt===c.at&&f.value===JSON.stringify(c)))))throw Error('Invalid acquired chapter boundary');
        life.chapter=clone(c);
        const memory=d.sourceMemory??[];
        if(!Array.isArray(memory)||memory.length>128||new Set(memory.map(m=>JSON.stringify([m?.subject,m?.source]))).size!==memory.length||
          !memory.every(m=>m&&typeof m.subject==='string'&&m.subject.length>0&&m.subject.length<=512&&typeof m.source==='string'&&m.source.length>0&&m.source.length<=4096&&
            typeof m.fromFact==='string'&&m.fromFact.length>0&&m.fromFact.length<=512&&typeof m.digest==='string'&&/^[0-9a-f]{1,16}$/.test(m.digest)&&
            typeof m.archive==='string'&&/^[0-9a-f]{1,16}$/.test(m.archive)&&(m.revision===null||integer(m.revision))&&
            (!m.subject.startsWith('usgs:')||integer(m.revision))))throw Error('Invalid remembered source versions');
        life.sourceMemory=clone(memory);
      }
      life.voice=VOICE.GlyphVoice.load(d.voice).grow(BODY.H);
      for(const f of life.ledger.entries()){
        if(f.source==='amos:evaluation/v1'){const evaluation=validateEvaluation(f,life.ledger);
          if(JSON.stringify(evaluation.scope??null)!==JSON.stringify(scope(life.chapter)))throw Error('Evaluation differs from its chapter scope');}
        if(f.source==='amos:experience/v1'&&f.predicate==='self_memory'){
          const m=JSON.parse(f.value);
          if(life.chapter.number===1||m.policy!=='amos/carried-self-v1'||m.archive!==life.chapter.archive||typeof m.fromFact!=='string'||!m.fromFact||
            !Number.isFinite(m.error)||m.error<0||!finiteArray(m.observed,4)||f.recordedAt!==life.chapter.at||f.validFrom!==life.chapter.at||f.validTo!==null)
            throw Error('Invalid carried self memory');
        }
      }
      if(width!==BODY.H&&d.pending?.features?.length===2*width+6)d.pending.features=growFeatures(d.pending.features,width);
      if(d.version<3&&Array.isArray(d.relations?.recent))for(const c of d.relations.recent){
        if(c.source===undefined)c.source=d.history?.find(t=>t.event.id===c.id)?.event.source;
      }
      life.relations=d.relations?RELATIONS.RelationField.load(d.relations,life.ledger):new RELATIONS.RelationField();
      if(!integer(d.count)||d.count<0||d.count!==life.model.world.tick||!integer(d.serial)||d.serial<0||
        !integer(d.historyOmitted)||d.historyOmitted<0||!['quake','weather','message'].includes(d.attention)||
        !Array.isArray(d.queue)||d.queue.length>MAX_QUEUE||new Set(d.queue.map(e=>e.id)).size!==d.queue.length||
        !Array.isArray(d.history)||d.history.length>MAX_HISTORY||d.history.length+d.historyOmitted!==d.count||
        !d.station||!Number.isFinite(d.station.latitude)||Math.abs(d.station.latitude)>90||!Number.isFinite(d.station.longitude)||Math.abs(d.station.longitude)>180)throw Error('Invalid life history');
      for(const event of d.queue)eventValid(event,life.ledger);
      let tick=d.historyOmitted;
      if(d.reservedReceiptSlots!==undefined&&![2,3,5,6,9].includes(d.reservedReceiptSlots))throw Error('Unsupported encounter reserve');
      const needsLegacyCompletion=d.reservedReceiptSlots!==ENCOUNTER_RECEIPTS&&
        (life.ledger.size+ENCOUNTER_RECEIPTS*d.queue.length>CAPACITY||bytes(d.journal)+RESERVE_BYTES*d.queue.length>MAX_JOURNAL);
      if(needsLegacyCompletion)for(const event of d.queue)event.legacyCompletion=true;
      if(d.queue.some(e=>!e.legacyCompletion)&&(life.ledger.size+ENCOUNTER_RECEIPTS*d.queue.length>CAPACITY||bytes(d.journal)+RESERVE_BYTES*d.queue.length>MAX_JOURNAL))throw Error('Pending encounters have no completion reserve');
      for(const t of d.history) {
        eventValid(t.event,life.ledger);
        if(JSON.stringify(t.tool?.result?.data?.scope??null)!==JSON.stringify(scope(life.chapter)))throw Error('Reading differs from its chapter scope');
        if(t.relations){const receipt=life.ledger.entries().find(f=>f.id===t.relationReceipt);
          const legacy=t.receiptState==='legacy-full-journal'&&t.event.legacyCompletion===true&&t.relationReceipt===null;
          if((!legacy&&(!receipt||receipt.source!=='amos:relations/v1'||receipt.value!==JSON.stringify(t.relations)))||
            !Array.isArray(t.relations.evidence)||!t.relations.evidence.every(id=>life.ledger.entries().some(f=>f.id===id&&f.recordedAt<=(receipt?.recordedAt??latestReceipt(life.ledger)))))throw Error('Invalid relation evidence');}
        if(t.tick!==++tick||!finiteArray(t.before,t.after?.length)||![24,28,40].includes(t.after?.length)||!finiteArray(t.after,t.before?.length)||!finiteArray(t.observed,3)||
          !finiteArray(t.mixture,8)||!finiteArray(t.prediction,3)||!Number.isFinite(t.surprise)||!Number.isFinite(t.load)||
          !Number.isFinite(t.resonance)||t.load<0||t.load>1||t.resonance<0||t.resonance>1||
          !Array.isArray(t.changed)||t.changed.length>6||!t.changed.every(n=>n&&integer(n.i)&&n.i>=0&&n.i<t.after.length&&[n.before,n.after,n.delta].every(Number.isFinite))||
          !t.recognition||!['similarity','support','uncertainty','ignorance','noise'].every(k=>Number.isFinite(t.recognition[k])&&t.recognition[k]>=0)||
          !t.tool?.result?.ok||!['lalo_facts','lalo_history','lalo_lineage'].includes(t.tool.name)||!Array.isArray(t.tool.result.data?.items)||
          !Array.isArray(t.utterance?.ids)||t.utterance.ids.length!==5||
          !t.utterance.ids.every(id=>integer(id)&&id>=0&&id<88+life.voice.symbols.length)||
          !Array.isArray(t.utterance.contributions)||t.utterance.contributions.length!==5||
          !t.utterance.contributions.every(c=>c&&integer(c.id)&&c.id>=0&&c.id<88+life.voice.symbols.length&&[c.association,c.recognition,c.succession].every(Number.isFinite))||
          !['quake','weather','message'].includes(t.nextAttention)||![-1,0,1].includes(t.action)||
          (t.prototypeCount!==undefined&&(!integer(t.prototypeCount)||t.prototypeCount<1||t.prototypeCount>8))||
          (t.symbolCount!==undefined&&(!integer(t.symbolCount)||t.symbolCount<0||t.symbolCount>64)))throw Error('Invalid encounter history');
        const born=t.utterance.born;
        if(born&&(!integer(born.id)||born.id<88||born.id>=88+life.voice.symbols.length||!integer(born.support)||born.support<14||typeof born.name!=='string'))throw Error('Invalid symbol birth');
      }
      for(const t of d.history)if(['amos/world-read-v1','amos/reflective-facts-v1','amos/reflective-facts-v2'].includes(t.policy)){
        const receipt=life.ledger.entries().find(f=>f.id===t.readReceipt);
        const legacy=t.receiptState==='legacy-full-journal'&&t.event.legacyCompletion===true&&t.readReceipt===null;
        if(!finiteArray(t.worldAfter,t.after.length)||!finiteArray(t.readObservation,3)||t.resonanceGain!==.94+.12*t.resonance||
          !['amos/read-indices-v1','amos/read-indices-v2','amos/read-indices-v3'].includes(t.reading?.policy)||
          !sameReading(PERCEPTION.read(t.tool.result,life.ledger,t.tool.name,t.tool.arguments,t.reading?.knownThrough,Number(t.reading?.policy?.slice(-1))),t.reading)||
          (!legacy&&(!receipt||receipt.source!=='amos:tool-read/v1'||receipt.value!==JSON.stringify(t.reading))))throw Error('Invalid acquired tool reading');
      }
      if(d.version>=4){
        life.mind=COGNITION.FactMind.load(d.mind,BODY.H);life.sonar=SONAR.SomaticSonar.load(d.sonar);life.cognitionBirth=d.cognitionBirth;
        if(!integer(life.cognitionBirth)||life.cognitionBirth<0||life.mind.updates!==d.count-life.cognitionBirth||life.sonar.turns!==life.mind.updates||
          (life.mind.lastSelf!==null&&!life.ledger.entries().some(f=>f.id===life.mind.lastSelf&&(f.source==='amos:self/v1'||f.source==='amos:experience/v1'&&f.predicate==='self_memory'))))throw Error('Self history disagrees with this life');
      }else life.cognitionBirth=d.count;
      for(const t of d.history)if(['amos/reflective-facts-v1','amos/reflective-facts-v2'].includes(t.policy))validateReflection(t,life.ledger,life.voice);
      for(const t of d.history)if(t.transitions)TRANSITIONS.validate(t,life.ledger,BODY.H,d.version>=6?d.transitionBirth:undefined);
      if(d.version>=6){life.transitions=TRANSITIONS.TransitionMind.load(d.transitions,BODY.H);life.transitionBirth=d.transitionBirth;
        if(!integer(life.transitionBirth)||life.transitionBirth<0||!TRANSITIONS.phases.every(p=>life.transitions.heads[p].updates===d.count-life.transitionBirth)||
          d.history.some(t=>t.tick>life.transitionBirth&&!t.transitions)||
          !life.transitions.last.every(r=>{const f=life.ledger.entries()[r.premise],record=f&&JSON.parse(f.value);return f&&r.tick===d.count&&f.id===r.id&&f.subject===`agent:amos:encounter:${r.tick}`&&f.source==='amos:transition/v1'&&record.phase===r.phase&&record.error===r.error&&(record.premises[0]??null)===r.sourcePremise;}))throw Error('Transition learning disagrees with this life');
      }else life.transitionBirth=d.count;
      if(d.pending&&(!finiteArray(d.pending.observation,3)||!finiteArray(d.pending.predicted,3)||!finiteArray(d.pending.features,BODY.F)||
        !finiteArray(d.pending.sequence,32)||!finiteArray(d.pending.influence,2)||![-1,0,1].includes(d.pending.action)||
        !d.pending.recognition||!Object.values(d.pending.recognition).every(v=>Number.isFinite(v)&&v>=0)))throw Error('Invalid pending forecast');
      if(!!d.pending!==(d.count>0))throw Error('Missing pending forecast');
      if(life.model.subject.updates!==Math.max(0,d.count-1)||life.voice.utterances!==d.count)throw Error('Acquired state and biography disagree');
      if(life.relations.seen>d.count)throw Error('Relation history exceeds this life');
      for(const c of life.relations.recent){const t=d.history.find(t=>t.event.id===c.id);
        const expected=t?RELATIONS.context(t.event,life.ledger):null;
        if(!expected||Object.keys(c).length!==Object.keys(expected).length||Object.keys(expected).some(k=>JSON.stringify(c[k])!==JSON.stringify(expected[k])))throw Error('Relation context differs from its source receipts');}
      if(d.lastWeather){eventValid(d.lastWeather,life.ledger);if(d.lastWeather.kind!=='weather')throw Error('Invalid last weather sample');}
      Object.assign(life,{queue:d.queue,history:d.history,pending:d.pending,count:d.count,serial:d.serial,historyOmitted:d.historyOmitted,
        attention:d.attention,station:d.station,lastWeather:d.lastWeather});return life;
    }
  }
  async function fetchJSON(url,{signal,maxBytes=1_000_000}={}) {
    const response=await fetch(url,{signal,credentials:'omit',referrerPolicy:'no-referrer'});
    if(!response.ok)throw Error(`Source returned HTTP ${response.status}`);
    const reader=response.body?.getReader();let text='';
    if(reader){const chunks=[];let total=0;for(;;){const {value,done}=await reader.read();if(done)break;total+=value.byteLength;
      if(total>maxBytes){await reader.cancel();throw Error('Source exceeds the 1 MB input budget');}chunks.push(value);}
      const buffer=new Uint8Array(total);let offset=0;for(const chunk of chunks){buffer.set(chunk,offset);offset+=chunk.length;}text=new TextDecoder().decode(buffer);
    }else{text=await response.text();if(bytes(text)>maxBytes)throw Error('Source exceeds input budget');}
    return JSON.parse(text);
  }
  function compareLives(kept,current,text,at) {
    const a=WorldLab.load(kept),b=WorldLab.load(current);
    if(a.model.birth!==b.model.birth)throw Error('Choose two histories from the same birth for this experiment');
    const before=[a.count,b.count];
    const ea=a.ingestText(text,at),eb=b.ingestText(text,at);
    const left=a.encounter(at,ea.id),right=b.encounter(at,eb.id);
    return {before,left,right,activationGap:magnitude(left.after.map((v,i)=>v-right.after[i])),
      forecastGap:magnitude(left.prediction.map((v,i)=>v-right.prediction[i]))};
  }
  return {WorldLab,compareLives,fetchJSON,CAPACITY,MAX_QUEUE,MAX_HISTORY,MAX_SNAPSHOT,ENCOUNTER_RECEIPTS,MAX_JOURNAL,interactionFrame,WIDTH:BODY.H,FEATURES:BODY.F,magnitude};
})();


